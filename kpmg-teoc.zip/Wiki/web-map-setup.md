# Web Interface Setup Guide

Complete guide for setting up the TEOC Operations interactive web interface with Mapbox mapping and Microsoft Teams integration.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [SharePoint Configuration](#sharepoint-configuration)
3. [Mapbox Setup](#mapbox-setup)
4. [Entra ID App Registration](#entra-id-app-registration)
5. [Azure Function Configuration](#azure-function-configuration)
6. [Teams Integration](#teams-integration)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

- Azure subscription with Azure Functions deployed
- SharePoint site with TEOC assessment list
- Microsoft 365 tenant with Teams
- Admin access to Entra ID (Azure AD)
- Mapbox account (free tier available)

## SharePoint Configuration

### Add Coordinate Fields

The web interface requires two new decimal fields in your SharePoint list:

1. Go to your SharePoint list
2. Click **Settings** (gear icon) > **List settings**
3. Under **Columns**, click **Create column**

**Add Latitude field**:
- Column name: `latitude`
- Type: **Number**
- Require that this column contains information: No
- Number of decimal places: 6
- Click **OK**

**Add Longitude field**:
- Column name: `longitude`
- Type: **Number**
- Require that this column contains information: No
- Number of decimal places: 6
- Click **OK**

### Verify Existing Fields

Ensure these fields exist (created during initial setup):
- Title (Single line of text)
- ContactName (Single line of text)
- ContactPhoneNumber (Single line of text)
- EventCausedDamage (Choice or text)
- ImmediateNeedsRequired (Yes/No)
- Status (Choice: New, Pending, In Progress, Completed)
- MoreInformation (Multiple lines of text)

## Mapbox Setup

Mapbox provides the interactive map interface with geocoding and visualization.

### Create Mapbox Account

1. Go to [mapbox.com](https://www.mapbox.com/)
2. Click **Sign Up** (free tier includes 50,000 map loads/month)
3. Verify your email address

### Get Access Token

1. Go to [account.mapbox.com](https://account.mapbox.com/)
2. Under **Access tokens**, find your **Default public token**
3. Or click **Create a token** for a new one
4. Copy the token (starts with `pk.`)

**Token Scopes** (for new tokens):
- ✅ `styles:read` - Read map styles
- ✅ `fonts:read` - Load map fonts
- ✅ `datasets:read` - Access datasets

### Token Security

- Use the **public token** (starts with `pk.`) in your client-side code
- Restrict token usage to your domains:
  - Add your Azure Function domain: `your-app.azurewebsites.net`
  - Add localhost for testing: `localhost`
  - Go to **Account > Tokens > [Your token] > URL restrictions**

## Entra ID App Registration

Configure authentication for the web interface.

### Create App Registration

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to **Entra ID** (Azure Active Directory)
3. Click **App registrations** > **New registration**

**Registration details**:
- Name: `TEOC Operations Web Interface`
- Supported account types: **Accounts in this organizational directory only**
- Redirect URI: 
  - Platform: **Single-page application (SPA)**
  - URI: `https://your-function-app.azurewebsites.net/api/web/`
- Click **Register**

### Configure Authentication

After registration, go to **Authentication**:

1. Under **Platform configurations** > **Single-page application**:
   - Add redirect URI: `https://your-function-app.azurewebsites.net/api/web/`
   - Add (for local testing): `http://localhost:7071/api/web/`
   - Add (for Teams): `https://token.botframework.com/.auth/web/redirect`

2. Under **Implicit grant and hybrid flows**:
   - ✅ **ID tokens** (recommended for hybrid flows)

3. Under **Supported account types**:
   - Select **Accounts in this organizational directory only**

4. Click **Save**

### Configure API Permissions

1. Go to **API permissions**
2. Click **Add a permission**

**Add Microsoft Graph permissions**:
- **Microsoft Graph** > **Delegated permissions**
- Select:
  - `User.Read` - Sign in and read user profile
  - `Sites.ReadWrite.All` - Read and write items in all site collections
- Click **Add permissions**

3. Click **Grant admin consent for [Your Organization]**
4. Click **Yes** to confirm

### Expose an API (for Teams SSO)

Only required if using Teams integration:

1. Go to **Expose an API**
2. Click **Set** next to Application ID URI
3. Enter: `api://your-default-domain.azurewebsites.net/YOUR_CLIENT_ID` (your function apps default domain)
   - Note: For use in teams, use above Application ID URI. For use in web window, use api://your-function-app-name.azurewebsites.net/YOUR_CLIENT_ID
5. Click **Save**

6. Click **Add a scope**:
   - Scope name: `access_as_user`
   - Who can consent: **Admins and users**
   - Admin consent display name: `Access TEOC Operations`
   - Admin consent description: `Allows the app to access TEOC Operations on behalf of the signed-in user`
   - User consent display name: `Access TEOC Operations`
   - User consent description: `Allows the app to access TEOC Operations on your behalf`
   - State: **Enabled**
   - Click **Add scope**

### Copy Configuration Values

From the **Overview** page, copy:
- **Application (client) ID**: Save as `ENTRA_CLIENT_ID`
- **Directory (tenant) ID**: Save as `ENTRA_TENANT_ID`

## Azure Function Configuration

### Update Application Settings

1. Go to your Azure Function App in Azure Portal
2. Navigate to **Configuration** > **Application settings**
3. Add the following settings:

**Required Settings**:
```
MAPBOX_API_KEY = pk.your_mapbox_token_here
ENTRA_CLIENT_ID = your-entra-client-id-here
ENTRA_TENANT_ID = your-tenant-id-here
FUNCTION_BASE_URL = https://your-function-app.azurewebsites.net/api
```

**Optional Settings** (for customization):
```
DEFAULT_MAP_LAT = 39.8283
DEFAULT_MAP_LNG = -98.5795
DEFAULT_MAP_ZOOM = 4
```

4. Click **Save**
5. Restart the function app

### Configure CORS

Allow the web interface to call Azure Function APIs:

1. In Azure Function App, go to **CORS**
2. Add allowed origins:
   - `https://your-function-app.azurewebsites.net`
   - `http://localhost:7071` (for local testing)
3. For Teams:
   - `https://teams.microsoft.com`
   - `https://*.teams.microsoft.com`
4. Click **Save**

### Local Testing Configuration

For local development, create `local.settings.json`:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "node",
    "SHAREPOINT_SITE_URL": "https://yourtenant.sharepoint.com/sites/yoursite",
    "SHAREPOINT_LIST_ID": "your-list-guid",
    "SHAREPOINT_CLIENT_ID": "your-sp-app-client-id",
    "SHAREPOINT_CLIENT_SECRET": "your-sp-app-secret",
    "SHAREPOINT_TENANT_ID": "your-tenant-id",
    "MAPBOX_API_KEY": "pk.your_mapbox_token",
    "ENTRA_CLIENT_ID": "your-entra-client-id",
    "ENTRA_TENANT_ID": "your-tenant-id",
    "FUNCTION_BASE_URL": "http://localhost:7071/api",
    "DEFAULT_MAP_LAT": "39.8283",
    "DEFAULT_MAP_LNG": "-98.5795",
    "DEFAULT_MAP_ZOOM": "4"
  },
  "Host": {
    "CORS": "*"
  }
}
```

## Teams Integration

Install TEOC Operations as a native Microsoft Teams tab.

### Package the Teams App

1. Navigate to `deployment/appPackage/` directory
2. Edit `manifest.json`:
   - Replace `YOUR_APP_ID_HERE` with a new GUID
   - Replace `YOUR_DOMAIN_HERE` with your function domain
   - Replace `YOUR_FUNCTION_URL_HERE` with your function URL
   - Replace `YOUR_ENTRA_CLIENT_ID_HERE` with your Entra client ID
   - Change configurationURL to "https://your-default-domain.net/web/config.html"
Description replacements:
   - short: "Interactive map for emergency operations management"
   - full: "TEOC Operations provides a real-time, interactive map interface for creating, viewing, and managing emergency assessment items. Features include location-based item creation, visual status indicators, and seamless SharePoint integration."

3. Create PNG icons (see `teams-app/ICONS.md`):
   - `color.png` (192x192px)
   - `outline.png` (32x32px)

4. Create ZIP package:
```bash
cd teams-app
zip teoc-app.zip manifest.json color-icon.png outline-icon.png
```

### Upload to Teams

**For Testing**:
1. Open Microsoft Teams
2. Go to **Apps** > **Manage your apps**
3. Click **Upload an app** > **Upload a custom app**
4. Select `teoc-app.zip`
5. Click **Add**

**For Organization**:
1. Go to [Teams Admin Center](https://admin.teams.microsoft.com)
2. Navigate to **Teams apps** > **Manage apps**
3. Click **Upload** and select `teoc-app.zip`
4. Approve the app for your organization

### Add as Tab

**Personal Tab** (individual use):
- After installation, find "TEOC Operations" in your Teams app bar
- Click to open the map interface

**Channel Tab** (team collaboration):
1. Go to any Teams channel
2. Click **+** to add a tab
3. Search for "TEOC Operations"
4. Configure default map settings
5. Click **Save**

See detailed instructions: [teams-app/README.md](../teams-app/README.md)

## Testing

### Browser Testing

1. Navigate to: `https://your-function-app.azurewebsites.net/api/web/`
2. Click **Sign In with Microsoft**
3. Authenticate with your Microsoft account
4. Verify:
   - Map loads and displays
   - Existing items appear as markers
   - Click '+' to create new item
   - Form opens and location can be selected
   - Submit creates item successfully
   - New item appears on map

### Teams Testing

1. Open Teams app (desktop or web)
2. Click on TEOC Operations tab
3. Verify:
   - No sign-in prompt (SSO authentication)
   - Map loads within Teams interface
   - All functionality works as in browser
   - No external browser windows open

### Mobile Testing

1. Open Teams mobile app
2. Access TEOC Operations tab
3. Verify:
   - Responsive layout adapts to screen
   - Touch interactions work (tap, drag)
   - Forms are usable on mobile
   - Performance is acceptable

## Troubleshooting

### Map Doesn't Load

**Issue**: Blank map or error messages

**Solutions**:
- Verify `MAPBOX_API_KEY` is set correctly
- Check browser console for errors
- Ensure Mapbox token is active and not expired
- Verify URL restrictions on Mapbox token include your domain

### Authentication Fails

**Issue**: "Unauthorized" or "Authentication failed"

**Solutions**:
- Verify `ENTRA_CLIENT_ID` and `ENTRA_TENANT_ID` are correct
- Check redirect URIs in Entra app registration
- Ensure API permissions are granted with admin consent
- Clear browser cache and cookies

### Items Don't Load

**Issue**: Map loads but no items appear

**Solutions**:
- Verify SharePoint list has items with latitude/longitude
- Check `SHAREPOINT_` configuration settings
- Review Azure Function logs for errors
- Test `getItems` API endpoint directly: `/api/getItems`

### Can't Create Items

**Issue**: Create form doesn't submit or fails

**Solutions**:
- Verify SharePoint list has `latitude` and `longitude` fields
- Check required fields are filled in form
- Review browser console for JavaScript errors
- Verify API permissions include `Sites.ReadWrite.All`

### Teams Tab Won't Load

**Issue**: Tab shows error or blank page in Teams

**Solutions**:
- Verify `manifest.json` URLs are correct
- Check that Teams JavaScript SDK is loading
- Ensure `webApplicationInfo` section matches Entra app config
- Test in browser first before Teams
- Clear Teams cache (Settings > General > Clear cache)

### CORS Errors

**Issue**: Browser shows CORS policy errors

**Solutions**:
- Add your domain to Azure Function CORS settings
- Add `https://teams.microsoft.com` for Teams integration
- For local testing, add `http://localhost:7071`
- Restart function app after CORS changes

## Next Steps

After successful setup:

1. **Customize Icons**: Create branded Teams app icons (see `teams-app/ICONS.md`)
2. **Train Users**: Share user guide and demo videos
3. **Monitor Usage**: Set up Application Insights for analytics
4. **Gather Feedback**: Collect user feedback for improvements
5. **Iterate**: Add custom fields or features based on needs

## Support

For additional help:
- Check [Troubleshooting Guide](../reference/troubleshooting.md)
- Review [API Reference](../reference/api-reference.md)
- Open issue on [GitHub](https://github.com/richardthorek/teoc-card-function/issues)

---

**Last Updated**: January 2025  
**Version**: 1.0.0
