# Assessment Map Tab - Current Issue Investigation Log

**Status:** ❌ **ISSUE NOT RESOLVED - STILL BROKEN**  
**Last Updated:** February 2026  
**Current Symptom:** Blank white screen when clicking Assessment Map tab

---

## ⚠️ IMPORTANT: Current State

**THE ASSESSMENT MAP TAB IS STILL NOT WORKING**

When you click the Assessment Map tab in the General channel of an incident team, you see:
- ❌ Blank white screen
- ❌ No error messages visible to user
- ❌ Tab appears to load but shows nothing

If 

This document chronicles what has been attempted so far and provides guidance for the next developer to continue troubleshooting.

---


## The Problem

### Current Behavior
When creating an incident and clicking the "Assessment Map" tab in the General channel:
1. Tab loads (shows loading indicator briefly)
2. Screen goes blank/white
3. No map is displayed
4. No error message shown to user
5. Console may show errors (check DevTools)

### Expected Behavior
The tab should:
1. Load the Map App immediately
2. Display a map interface
3. Show assessment locations for the current incident
4. Allow interaction with the map

### User Impact
- Cannot view assessment locations on a map
- Must manually track assessments via list view only
- Reduces situational awareness during incidents

---

## Intended Behavior

### Architecture Goal
The Assessment Map should work as follows:

**Each incident has its own SharePoint site:**
```
Incident 127 → https://tenant.sharepoint.com/sites/KTEOC_127
Incident 128 → https://tenant.sharepoint.com/sites/KTEOC_128
```

**Each site has its own assessment list:**
- List name: `TEOC-Assessments`
- Contains assessment records with location data

**Map App should:**
1. Be launched as a Teams tab in the General channel
2. Receive parameters via URL: `incidentId`, `siteUrl`, `listName`
3. Query the SharePoint site's assessment list via Microsoft Graph API
4. Display assessment locations on a map
5. Filter automatically by site (only show assessments for that incident)

### URL Format (Intended)
```
https://[map-app-host]/index.html#/assessmentmap?incidentId=127&siteUrl=https%3A%2F%2Ftenant.sharepoint.com%2Fsites%2FKTEOC_127&listName=TEOC-Assessments
```

The `#/assessmentmap` hash route is critical because the app uses React's HashRouter.

---

## What Was Attempted

Below is a chronological log of troubleshooting attempts. **None of these resolved the issue.**

### Attempt 1: Fix URL Parameter Parsing
**Problem Identified:** Parameters were not being extracted from the URL

**Theory:** The app uses HashRouter, so parameters are in the hash fragment (`#/route?params`), but code was reading from `window.location.search` which is empty for hash-based routes.

**Change Made:**
```typescript
// BEFORE (in AssessmentMapTab.tsx)
const params = new URLSearchParams(window.location.search);

// AFTER
const hash = window.location.hash;
const queryString = hash.includes('?') ? hash.split('?')[1] : '';
const params = new URLSearchParams(queryString);
```

**File:** `EOC-TeamsFx/tabs/src/components/AssessmentMapTab.tsx` (lines 46-50)

**Result:** ❌ Did not fix the blank screen issue

**Why it might not have worked:**
- The tab may not be loading at all, so parameter parsing code never executes
- There might be an earlier error preventing the component from mounting

---

### Attempt 2: Fix Graph API Endpoint Format
**Problem Identified:** SharePoint site endpoint was malformed

**Theory:** Microsoft Graph API requires site endpoints in format `/sites/{hostname}:{sitePath}`, not just `/sites/{siteName}`.

**Change Made:**
```typescript
// BEFORE (in AssessmentMapViewer.tsx)
const sitePath = urlObject.pathname;
const siteEndpoint = `${graphConfig.spSiteGraphEndpoint}${sitePath.replace(/^\/sites\//, '')}`;
// Result: /sites/KTEOC_127

// AFTER
const urlObject = new URL(decodedSiteUrl);
const hostname = urlObject.hostname;
const sitePath = urlObject.pathname;
const siteEndpoint = `${graphConfig.spSiteGraphEndpoint}${hostname}:${sitePath}`;
// Result: /sites/kteocdemo.sharepoint.com:/sites/KTEOC_127
```

**File:** `EOC-TeamsFx/tabs/src/components/AssessmentMapViewer.tsx` (lines 64-77)

**Result:** ❌ Did not fix the blank screen issue

**Why it might not have worked:**
- The component may not be reaching the point where it makes Graph API calls
- There's likely an error earlier in the component lifecycle

---

### Attempt 3: Fix Missing API Version
**Problem Identified:** Graph API URLs were missing `/v1.0` version

**Theory:** Manually constructing full URLs bypassed the SDK's automatic version injection.

**Change Made:**
```typescript
// BEFORE
const siteEndpoint = `${this.props.graphBaseUrl}${graphConfig.spSiteGraphEndpoint}${hostname}:${sitePath}`;
// Result: https://graph.microsoft.com/sites/... (missing /v1.0)

// AFTER
const siteEndpoint = `${graphConfig.spSiteGraphEndpoint}${hostname}:${sitePath}`;
// SDK adds: https://graph.microsoft.com/v1.0/sites/...
```

**File:** `EOC-TeamsFx/tabs/src/components/AssessmentMapViewer.tsx` (lines 77, 85)

**Result:** ❌ Did not fix the blank screen issue

**Why it might not have worked:**
- Again, if the component isn't loading, this code never executes
- The blank screen suggests a more fundamental problem

---

### Attempt 4: Fix List Name Mismatch
**Problem Identified:** Code was using wrong list name

**Theory:** List is created as "TEOC-Assessments" but code was trying to access "Ground Assessments".

**Change Made:**
```typescript
// BEFORE
const encodedListName = encodeURIComponent(constants.GroundAssessments); // "Ground Assessments"

// AFTER
const encodedListName = encodeURIComponent(siteConfig.assessmentsList); // "TEOC-Assessments"
```

**Files:**
- `EOC-TeamsFx/tabs/src/common/CommonService.ts` (line 812)
- `EOC-TeamsFx/tabs/src/components/AssessmentMapTab.tsx` (line 54)

**Result:** ❌ Did not fix the blank screen issue

**Why it might not have worked:**
- This would only affect data retrieval, not initial tab rendering
- Blank screen appears before data is fetched

---

### Attempt 5: Switch to Registered Map App
**Problem Identified:** Using wrong Teams app

**Theory:** User wants to use their separately registered Map App, not the embedded TEOC viewer.

**Change Made:**
```typescript
// BEFORE
const teocAppId = await this.getGraphData(
    graphContextURL + graphConfig.appCatalogsTEOCAppEndpoint, 
    graph
);

// AFTER
const mapAppId = await this.getGraphData(
    graphContextURL + graphConfig.appCatalogsMapAppEndpoint, 
    graph
);
```

**File:** `EOC-TeamsFx/tabs/src/common/CommonService.ts` (line 788)

**Result:** ❌ Did not fix the blank screen issue

**Why it might not have worked:**
- If the Map App external ID is not configured correctly, the app won't be found
- The Map App might not be properly registered or installed
- **This is a likely culprit - see "What to Investigate Next"**

---

### Attempt 6: Fix ContentUrl to Point to Map App
**Problem Identified:** ContentUrl was pointing to SharePoint site instead of Map App

**Theory:** When the tab loads, Teams needs to know where the Map App is hosted.

**Change Made:**
```typescript
// BEFORE
const mapAppUrl = `${teamSiteUrl}?incidentId=${encodedIncidentId}&listName=${encodedListName}`;
// Result: https://kteocdemo.sharepoint.com/sites/KTEOC_127?...

// AFTER
const mapAppBaseUrl = process.env.REACT_APP_MAP_APP_URL || 
                      process.env.REACT_APP_TEAMSFX_ENDPOINT || 
                      `https://${window.location.hostname}`;
const mapAppUrl = `${mapAppBaseUrl}/index.html?incidentId=${encodedIncidentId}&siteUrl=${encodedSiteUrl}&listName=${encodedListName}`;
```

**File:** `EOC-TeamsFx/tabs/src/common/CommonService.ts` (lines 818-821)

**Result:** ❌ Did not fix the blank screen issue (but getting closer)

**Why it might not have worked:**
- Still missing the hash route segment
- See Attempt 7

---

### Attempt 7: Add Hash Route to URL
**Problem Identified:** URL was missing `#/assessmentmap` hash route segment

**Theory:** React HashRouter needs the route in the hash fragment to know which component to load.

**Change Made:**
```typescript
// BEFORE
const mapAppUrl = `${mapAppBaseUrl}/index.html?incidentId=${encodedIncidentId}&siteUrl=${encodedSiteUrl}&listName=${encodedListName}`;
// Result: https://host/index.html?incidentId=127&...

// AFTER
const mapAppUrl = `${mapAppBaseUrl}/index.html#/assessmentmap?incidentId=${encodedIncidentId}&siteUrl=${encodedSiteUrl}&listName=${encodedListName}`;
// Result: https://host/index.html#/assessmentmap?incidentId=127&...
```

**File:** `EOC-TeamsFx/tabs/src/common/CommonService.ts` (line 822)

**Result:** ❌ **STILL SHOWS BLANK SCREEN**

**Why it might not have worked:**
- **This is the current mystery!**
- The URL format looks correct now
- But the tab still shows blank
- See "What to Investigate Next" for next steps

---

## Current Diagnostic Information

### What to Check First
When debugging, check these in order:

1. **DevTools Console** (Critical)
   - Open browser DevTools (F12)
   - Look for JavaScript errors
   - Look for 404 errors
   - Look for authentication errors
   - **Document what you find here!**

2. **Network Tab** (Critical)
   - Check what URLs are being requested
   - Look for failed requests (red)
   - Check response codes (404, 403, 401, etc.)
   - **Document what you find here!**

3. **React DevTools** (If available)
   - Check if components are mounting
   - Check component props
   - Check state values

4. **Teams App Configuration**
   - Verify Map App is registered in Azure AD
   - Verify Map App is in Teams app catalog
   - Verify external ID matches `graphConfig.ts`

### Current URL Being Generated
Based on the code changes, the URL should be:
```
https://[REACT_APP_TEAMSFX_ENDPOINT]/index.html#/assessmentmap?incidentId=127&siteUrl=https%3A%2F%2Fkteocdemo.sharepoint.com%2Fsites%2FKTEOC_127&listName=TEOC-Assessments
```

Where `REACT_APP_TEAMSFX_ENDPOINT` comes from `.env.teamsfx.dev`

### Environment Variables to Check
```env
REACT_APP_TEAMSFX_ENDPOINT=https://mifteocdev9b6e85simpleauth.azurewebsites.net
REACT_APP_CLIENT_ID=01c6f283-9695-4c8c-bbb7-3b81c48c6657
```

---

## What to Investigate Next

### Priority 1: Authentication Issues
Check if there are authentication problems:

1. **Does the user have permissions?**
   - Graph API requires `Sites.Read.All` or similar
   - Check in Azure AD app registration

2. **Is authentication working?**
   - Check DevTools console for auth errors
   - Look for 401/403 responses in Network tab

### Priority 2: Component Mounting Issues
The blank screen might mean the React component isn't mounting:

1. **Add console.log statements**
   - In `AssessmentMapTab.tsx` constructor
   - In `componentDidMount` method
   - Check if these appear in console

2. **Check for React errors**
   - React error boundaries might be catching errors silently
   - Check for error boundary implementations

3. **Verify route exists**
   - File: `EOC-TeamsFx/tabs/src/components/App.tsx` line 33
   - Should have: `<Route exact path="/assessmentmap">`
   - Verify this route exists and is not commented out

### Priority 3: Environment Variable Issues
The Map App hosting URL might be wrong:

1. **Check `.env.teamsfx.dev` file**
   - Verify `REACT_APP_TEAMSFX_ENDPOINT` is set
   - Verify it points to a valid, running server

2. **Try accessing the URL manually**
   - Open the generated URL in a browser
   - See if the page loads at all
   - Try: `https://[ENDPOINT]/index.html#/assessmentmap`

## Code Changes Made

### Files Modified

1. **AssessmentMapTab.tsx** (lines 46-54)
   - Parse URL parameters from hash instead of search string
   - Use `siteConfig.assessmentsList` as fallback

2. **AssessmentMapViewer.tsx** (lines 64-90)
   - Extract hostname and sitePath from SharePoint URL
   - Use relative paths for Graph API calls
   - Fixed list endpoint construction

3. **CommonService.ts** (lines 788, 812, 818-822)
   - Switch from TEOC app endpoint to Map App endpoint
   - Use `siteConfig.assessmentsList` for list name
   - Build proper URL with hash route and fallbacks

4. **graphConfig.ts** (lines 30-37)
   - Added documentation comments
   - External ID placeholder: `'bef61400-db9b-41d4-a617-403deb7bbf54'`

### View Current Changes
```bash
cd EOC-TeamsFx/tabs/src
git diff HEAD~10 components/AssessmentMapTab.tsx
git diff HEAD~10 components/AssessmentMapViewer.tsx
git diff HEAD~10 common/CommonService.ts
git diff HEAD~10 common/graphConfig.ts
```

---

## Known Facts

### What We Know Works
- ✅ Creating incidents works
- ✅ Assessment channel and list creation works
- ✅ Assessment Map tab gets created in General channel
- ✅ Tab appears in the channel list

### What Doesn't Work
- ❌ Clicking the Assessment Map tab shows blank screen
- ❌ No map is displayed
- ❌ No error message shown to user (check console for hidden errors)

---


