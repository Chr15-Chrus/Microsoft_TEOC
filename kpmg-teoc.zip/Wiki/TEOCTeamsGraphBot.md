## TEOC Teams Graph API - Delegated Auth End-to-end setup

**Purpose**: This document describes the complete, production-ready process to post messages to Microsoft Teams channels using Microsoft Graph delegated permissions, backed by a service account, MSAL device code slow, and Azure Functions. 

**Bot purpose**: Our aim for the bot is to replace legacy incoming webhook logic for teams posting. For incoming webhooks, each incoming webhook needed to be manually created for each incident. GraphAPI enables posting to teams/channels without any prior manual setup.


## Phase 1: Create Service Account in Microsoft Entra ##

### Step 1: Create User Account in Intune Admin Centre

1.1 Within the Azure portal navigate to the Intune Admin Centre Using the search bar. \
1.2 Go to **Users** -> **All users** -> **Create new Users**. \
1.3 Fill in the following details
- User principal name: kteoc-bot@kteocdemo.onmicrosoft.com
- Display Name: TEOC Service Account
- Password: Generate strong password
- Useage Location: Same as tenant's "Country/Region" (Azure Portal -> Microsoft Entra ID -> Properties -> Tenant Country/Region)


### Step 2: Assign Micrsoft 365 License
2.1 Select the newly created user from the list of users. \
2.2 On the inner left hand panel, select licenses


### Step 3: Add Service To Existing Teams/Channels
3.1 Open Microsoft Teams \
3.2 Navigate to the Team (e.g., *Emergency operations*) \
3.3 Navigate: **Manage team** -> **Members** -> **+ Add member** \
3.4 Add: kteoc-bot@kteocdemo.onmicrosoft.com \
3.5 Role: Member (Or Owner if required)

## Phase 2: Give the function app permission to be able to use bot service to send messgaes via the Microsoft Graph API

### Step 4: Configure Authentication
Choosing the authentication for the function app to use when accessing the service account.

4.1 In the Azure Portal, navigate: 
```
(Search -> Microsoft Entra ID -> Manage -> App Registrations -> All applications -> TEOC Web Map)
```
4.2 On the left hand panel navigate: ` Manager -> Authentication `. Select ***Add a platform -> Mobile Desktop Applications***. Select advanced settings and select **Yes** for **Allow public client flows**
4.3 Save


### Step 5: Add API permissions - Now the function app has delegated permissions for Microsft Graph

Still in the Web App App Registrations navigate to **API permissions** on the left hand panel.
5.1 Select **Add a permission -> Microsoft Graph -> Delegated Permissions**
5.2 Search and add:
- `User.read`
- `ChannelMessage.Send`
- `Group.ReadWrite.All`
5.3 Grant admin consent for [Your org]
- Click the button
- Confirm in popup
- **Verify green checkmarks** appear next to all permisions.

Under Microsoft Graph you should see something like this


|Permission |Type |Status|
|-----------|-----|------|
|User.Read  |Delegated|✅ Granted for [Your Org] |
|ChannelMessage.Send |Delegated |✅ Granted for [Your Org]|
|Group.ReadWrite.All |Delegated |✅ Granted for [Your Org]|


## Phase 3:
One time interactive login

### Step 6:
6.1 Open a cloud shell within the Azure Portal and choose **bash** once its loaded.

6.2 Create and enter the following directory
```bash
mkdir -p ~/msal-login
cd ~/msal-login
```
6.3 Set the following environment variables:
```bash
export ENTRA_CLIENT_ID=""
export entra_tenant_id=""
```
To sanity check this, you can use the echo program.

6.4 Install a node project.
```
nano init -y
```
6.5 Install MSAL for Node.
```
npm install @azure/msal-node
```

6.6 using the nano text editor within bash create the following .js script file:
`nano generate_msal_cache.js`

```
// generate_msal_cache.js
// One-time interactive login to produce msal_cache.json for delegated Graph access
const fs = require("fs");
const path = require("path");
const msal = require("@azure/msal-node");

const CACHE_PATH = path.join(__dirname, "msal_cache.json");

// Use your Entra app credentials
const CLIENT_ID = process.env.ENTRA_CLIENT_ID;
const TENANT_ID = process.env.ENTRA_TENANT_ID;
const AUTHORITY = `https://login.microsoftonline.com/${TENANT_ID}`;

if (!CLIENT_ID || !TENANT_ID) {
  console.error("Missing ENTRA_CLIENT_ID or ENTRA_TENANT_ID env vars");
  process.exit(1);
}

const cachePlugin = {
  beforeCacheAccess: async (cacheContext) => {
    if (fs.existsSync(CACHE_PATH)) {
      cacheContext.tokenCache.deserialize(fs.readFileSync(CACHE_PATH, "utf-8"));
    }
  },
  afterCacheAccess: async (cacheContext) => {
    if (cacheContext.cacheHasChanged) {
      fs.writeFileSync(CACHE_PATH, cacheContext.tokenCache.serialize(), "utf-8");
    }
  },
};

const pca = new msal.PublicClientApplication({
  auth: { clientId: CLIENT_ID, authority: AUTHORITY },
  cache: { cachePlugin },
});

async function main() {
  const scopes = [
    "User.Read",
    "ChannelMessage.Send",
    "Group.ReadWrite.All",
  ];

  const deviceCodeRequest = {
    scopes,
    deviceCodeCallback: (response) => {
      console.log("\n=== DEVICE CODE LOGIN ===");
      console.log(response.message);
      console.log("=========================\n");
    },
  };

  const result = await pca.acquireTokenByDeviceCode(deviceCodeRequest);
  console.log("✅ Login success. Access token acquired for:", result.account?.username);
  console.log("✅ Cache written to:", CACHE_PATH);
}

main().catch((e) => {
  console.error("❌ Failed:", e?.message || e);
  process.exit(1);
});

```

6.6 Run the script `node generate_msal_cache.js`. The expected output should be:
```
=== DEVICE CODE LOGIN ===
To sign in, use a web browser to open the page https://microsoft.com/devicelogin 
and enter the code [AB12-CD34] to authenticate.
=========================
```

### Step 7: Complete Device Code Flow

7.1 In a browser, open the link from the script output: https://microsoft.com/devicelogin

7.2 Enter the code generated from the script output (Our dummy example): AB12-CD34

7.3 Sign in wit th service account credentials:

- Username: kteoc-bot@kteocdemo.onmicrosoft.com
- Password:(you created form Step 1.3)

7.4 Consent prompt appears -> Review Perimissions:
- User.Read
- ChannelMessageSend
- Group.ReadWrite.All

### Step 8: Verify Cache File
8.1 In the bash input
```
cat msal_cache.json
```
The expected output should be a JSON array 

```
[
  {
    "type": "Account",
    "entries": {
      "homeAccountId-env": {
        "username": "teoc-service@yourdomain.onmicrosoft.com",
        "localAccountId": "...",
        "realm": "...",
        "...": "..."
      }
    }
  },
  {
    "type": "AccessToken",
    "entries": {
      "...": "..."
    }
  },
  {
    "type": "RefreshToken",
    "entries": {
      "homeAccountId-env-...-...": {
        "secret": "0.AXEA...",
        "...": "..."
      }
    }
  },
  {
    "type": "IdToken",
    "entries": {
      "...": "..."
    }
  },
  {
    "type": "AppMetadata",
    "entries": {
      "...": "..."
    }
  }
]
```

Critically, ***Refresh Token*** section **must exist**.


...


## Phase 4: Upload Cache to Azure Blob Storage

### Step 9: Create Blob Container in Azure Storage
9.1  Navigate to Storage accounts in the Azure Portal home page
(Search -> Storage accounts -> Resources -> Create). We already had a storage account provision - "teocnotifysa001".
9.2 Select your storage account and navigate the left hand panel to Data storage -> Containers
9.3 Select "Add container" and input the following
- Name: msal-cache
- Anonymous access level: Private
- Select Create
9.4 Select your msal-cache container and upload your msal_cache.json from your local machine.

### Step 10: Verification
14.1 Using the following command in Azure Cloud Shells Bash:

``` 
az storage blob list \
  --account-name <your-storage-account-name> \
  --container-name msal-cache \
  --connection-string "<your-connection-string>" 
  ```

Where:
- Storage Account Name: Your current storage account
- Connection-String: Navigate the left hand panel (Security + Network -> Access Keys).

The successful creation of the blob storage will output a JSON array.


## Phase 5: Implement Graph Auth Utility
### Step 11: Create graphAuth.js
11.1 Create the file `EOC-Functions/utils/graphAuth.js`
(This already exists within the directory)

## Phase 6: Configure Azure Function App

### Step 12: Add Application Settings

12.1 In the Azure Portal navitage to the function app
12.2 Navigate: Configure -> Application settings -> New Application Setting
12.3 Fill in the following

| Name | Value |
|------|-------|
|ENTRA_CLIENT_ID | your-app-client-id |
|ENTRA_TENANT_ID | your-tenant-id |
|MSAL_CACHE_BLOB_CONTAINER| msal-cache|
|MSAL_CACHE_BLOB_NAME| msal_cache.json |
|AzureWebJobsStorage| already exists|

## Phase 7: Implemnt Teams Graph Poster
### Step 13: Create teamsGraphPosters.js
13.1 Create the file `EOC-Functions/utils/teasmGraphPoster.js`. (This already exists within the directory)

## Phase 8: Modify Webhook Gateway

### Step 14: Update webhookGateway.js
14.1 Add import statement
```
const { postMessageToTeamsChannel } = require('../utils/teamsGraphPoster');
```


## Maintainance

### Understanding Token Lifecycle

#### Access Token:
- Lifetime: ~1 hour
- Handled automatically: `getGraphAccessToken()` caches in memory for 55 min

#### Refresh Token:
- Lifetime: ~90 days (can be extended with Conditional Access policies)
- **Automatically refreshed** by MSAL when access token expires
- **Persisted back to blob** via `afterCasheAccess` plugin

#### Account Session:
- Can expire after inactivity or password change
- Requires re-running `generate_msal_cache.js`





## Other Considerations

Micrsoft provides multiple frameworks to implement bots and agents using the Bot Service in Azure - these can then be further added to teams. 

Attempts were made to try and utilise the [Microsoft Bot Framework SDK](https://learn.microsoft.com/en-us/azure/bot-service/index-bf-sdk?view=azure-bot-service-4.0) to create a simple echo bot locally, and then to be deployed to Azure. The inability to access specific tools within the deployment documentation meant this was abandoned. Additionally, as of December 31, 2025, the SDK and the Bot Emulator were archived on github. Microsoft recommends the [Microsoft 365 Agents SDK](https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/agents-sdk-overview?tabs=csharp) to build bots and agents. 



## Permissions:
Adith who developed the solution maintained the following permissions in the resoruce groups and in Intune

Adith:
- Resource Group (Function App + Web App) = Contributor
- Entra Admin Centre = Global Administrator
- Intune Assigned Roles: 1 (Global Administrator)
- Intune Assigned Licenses: 2 (Power Automate, M365 F1)
- Intune Group Memberships: 22
- Intune Applications: 7

Important Application Access: 
KTEOC - Demo, TEOC Web Map need to have SourceAdmin
 
Important Intune Assigned Licences:
Need to be global Admin to assign M365 F1

Will who helped document the process maintained the following permissions in the resource groups and in Intune

Screenshots:
[Adith's Global Administrator](./Images/AdithPermissions1.png)
[Adith's Assigned Licenses](./Images/AdithPermissions2.png)
[Adith's Assigned Applications](./Images/AdithPermissions3.png)

Will: 
- Resource Group (Function App + Web App) = Contributor
- Entra Admin CEntre = no assigned roles
- Intune Assigned Roles: 0
- Intune Assigned Licenses: 0
- Intune Assigned Memberships: 1
- Intune Applications: 1