import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import React from "react";
import CommonService, { IListItem } from '../common/CommonService';
import * as constants from '../common/Constants';
import * as atlas from 'azure-maps-control';
import * as graphConfig from '../common/graphConfig';
import "azure-maps-control/dist/atlas.min.css";
import { Client } from '@microsoft/microsoft-graph-client';

export interface IAssessmentMapViewerProps {
    incidentId: string;
    siteUrl: string;
    listName: string;
    azureMapKey: string;
    showMessageBar(message: string, type: string): void;
    userPrincipalName: any;
    localeStrings: any;
    appInsights: ApplicationInsights;
    graphBaseUrl: string;
    graph: Client;
}

export interface IAssessmentMapViewerState {
    assessmentData: any[];
    isLoading: boolean;
    errorMessage: string;
}

export class AssessmentMapViewer extends React.Component<IAssessmentMapViewerProps, IAssessmentMapViewerState> {
    constructor(props: IAssessmentMapViewerProps) {
        super(props);
        this.state = {
            assessmentData: [],
            isLoading: true,
            errorMessage: ''
        }
    }

    private dataService = new CommonService();

    //On component Load get the assessments data and generate map
    public async componentDidMount() {
        await this.loadAssessments();
    }

    //Load assessments from SharePoint list
    private loadAssessments = async () => {
        try {
            this.setState({ isLoading: true, errorMessage: '' });

            //Validate siteUrl parameter
            if (!this.props.siteUrl || this.props.siteUrl.trim() === '') {
                throw new Error("Site URL is missing. Please ensure the Assessment Map is configured correctly with a valid SharePoint site URL.");
            }

            //Get the site ID from the site URL - decode and validate
            let decodedSiteUrl: string;
            try {
                decodedSiteUrl = decodeURIComponent(this.props.siteUrl);
            } catch (decodeError) {
                throw new Error("Invalid site URL configuration. Please check the Assessment Map settings.");
            }
            
            //Parse the SharePoint site URL to extract hostname and site path
            let hostname: string;
            let sitePath: string;
            try {
                const urlObject = new URL(decodedSiteUrl);
                hostname = urlObject.hostname;
                sitePath = urlObject.pathname;
            } catch (urlError) {
                throw new Error("Invalid site URL format. Please ensure a valid SharePoint site URL is configured.");
            }
            
            //Get site details using the correct Graph API format: /sites/{hostname}:{sitePath}
            //Use relative path - the Graph SDK client will automatically add the base URL and version
            const siteEndpoint = `${graphConfig.spSiteGraphEndpoint}${hostname}:${sitePath}`;
            const siteData = await this.dataService.getGraphData(siteEndpoint, this.props.graph);
            
            if (!siteData || !siteData.id) {
                throw new Error("Could not retrieve site information");
            }

            //Get assessments from the Ground Assessments list
            const listEndpoint = `${graphConfig.spSiteGraphEndpoint}${siteData.id}/lists/${encodeURIComponent(this.props.listName)}/items?$expand=fields&$top=5000`;
            const assessmentItems = await this.dataService.getGraphData(listEndpoint, this.props.graph);

            if (assessmentItems && assessmentItems.value) {
                this.setState({ 
                    assessmentData: assessmentItems.value,
                    isLoading: false 
                }, () => {
                    this.initMap(assessmentItems.value);
                });
            } else {
                this.setState({ 
                    assessmentData: [],
                    isLoading: false 
                });
                this.initMap([]);
            }
        } catch (error: any) {
            console.error(constants.errorLogPrefix + "_AssessmentMapViewer_loadAssessments", error);
            const errorMsg = error?.message || "Failed to load assessment data";
            this.setState({ 
                isLoading: false, 
                errorMessage: errorMsg 
            });
            this.props.showMessageBar(
                `${this.props.localeStrings.genericErrorMessage}: ${errorMsg}`, 
                constants.messageBarType.error
            );
            this.dataService.trackException(
                this.props.appInsights, 
                error, 
                constants.componentNames.MapViewer, 
                'LoadAssessments', 
                this.props.userPrincipalName
            );
        }
    }

    //Generate map and pin points for assessments
    private initMap(assessmentsData: any[]) {
        try {
            //Check if Azure Maps key is configured
            if (!this.props.azureMapKey || this.props.azureMapKey.trim() === '') {
                this.setState({ 
                    errorMessage: 'Azure Maps key is not configured. Please contact your administrator to configure the Azure Maps key in the Admin Settings.' 
                });
                return;
            }

            //For GCCH Tenant
            if (this.props.graphBaseUrl !== constants.defaultGraphBaseURL) {
                atlas.setDomain('atlas.azure.us');
            }

            //Create azure map control with the Azure Maps subscription key
            const assessmentMap = new atlas.Map('azureMapControl', {           
                center: [0, 0],
                zoom: 1,
                language: 'en-US',
                view: 'Auto',
                authOptions: {
                    authType: atlas.AuthenticationType.subscriptionKey,
                    subscriptionKey: this.props.azureMapKey
                }
            });

            //Filter assessments with valid location data
            const validAssessments = assessmentsData.filter((item: any) => {
                if (!item.fields || !item.fields.Location) return false;
                
                try {
                    const location = JSON.parse(item.fields.Location);
                    return location && 
                           location.Coordinates && 
                           location.Coordinates.Latitude && 
                           location.Coordinates.Longitude &&
                           location.EntityType !== "Custom";
                } catch (error) {
                    console.error(constants.errorLogPrefix + "_Error parsing assessment location:", error);
                    return false;
                }
            });

            // If no valid assessments, show message
            if (validAssessments.length === 0) {
                this.setState({ 
                    errorMessage: 'No assessment locations found to display on the map.' 
                });
                console.log(constants.infoLogPrefix + "No valid assessment locations found to display on map");
                return;
            }

            const assessmentLocations: Array<[number, number]> = [];

            //Generate pins for each assessment and add it to the map
            validAssessments.forEach((item: any) => {
                try {
                    const location = JSON.parse(item.fields.Location);
                    const coordinates = location.Coordinates;
                    const latitude = coordinates.Latitude;
                    const longitude = coordinates.Longitude;
                    
                    assessmentLocations.push([longitude, latitude]);

                    //Determine pin color based on assessment status
                    let pinColor: string = 'blue'; // Default color for assessments
                    const status = item.fields.Status;
                    if (status) {
                        switch (status.toLowerCase()) {
                            case 'completed':
                            case 'closed':
                                pinColor = 'green';
                                break;
                            case 'in progress':
                            case 'active':
                                pinColor = 'orange';
                                break;
                            case 'pending':
                            case 'new':
                                pinColor = 'blue';
                                break;
                            default:
                                pinColor = 'blue';
                                break;
                        }
                    }

                    //Build popup content
                    const title = item.fields.Title || 'Assessment';
                    const displayName = location.DisplayName || location.Address?.City || 'Location';
                    const contact = item.fields.Contact_x0020_Name || '';
                    const phone = item.fields.ContactPhoneNumber || '';
                    const eventType = item.fields.EventCausedDamage || '';
                    
                    let popupContent = `<div style="padding:10px;color:grey">`;
                    popupContent += `<strong>${title}</strong><br>`;
                    popupContent += `${this.props.localeStrings.location}: ${displayName}<br>`;
                    if (status) popupContent += `${this.props.localeStrings.status}: ${status}<br>`;
                    if (eventType) popupContent += `${this.props.localeStrings.eventType || 'Event Type'}: ${eventType}<br>`;
                    if (contact) popupContent += `${this.props.localeStrings.contactName || 'Contact'}: ${contact}<br>`;
                    if (phone) popupContent += `${this.props.localeStrings.phoneNumber || 'Phone'}: ${phone}<br>`;
                    popupContent += `</div>`;

                    //Create an HTML marker for the assessment pin
                    const pinMarker = new atlas.HtmlMarker({
                        color: pinColor,
                        text: item.fields.ID?.toString() || '',
                        position: [longitude, latitude],
                        popup: new atlas.Popup({
                            content: popupContent,
                            pixelOffset: [0, -30]
                        })
                    });

                    //Add the marker to the map
                    assessmentMap.markers.add(pinMarker);

                    //Add mouse events to show/hide the popup
                    assessmentMap.events.add('mouseenter', pinMarker, () => {
                        pinMarker.togglePopup();
                    });
                    
                    assessmentMap.events.add('mouseleave', pinMarker, () => {
                        pinMarker.togglePopup();
                    });
                }
                catch (error) {
                    console.error(constants.errorLogPrefix + "_Error creating assessment marker:", error);
                }
            });

            //Center the map on the first assessment and zoom in
            if (assessmentLocations.length > 0) {
                const firstLocation = assessmentLocations[0];
                assessmentMap.setCamera({ center: firstLocation, zoom: 10 });
            }

        } catch (error) {
            console.error(
                constants.errorLogPrefix + "_AssessmentMapViewer_initMap \n",
                JSON.stringify(error)
            );
            this.props.showMessageBar(
                this.props.localeStrings.genericErrorMessage + ", " + "Failed to initialize map", 
                constants.messageBarType.error
            );
            this.dataService.trackException(
                this.props.appInsights, 
                error, 
                constants.componentNames.MapViewer, 
                'InitMap', 
                this.props.userPrincipalName
            );
        }
    }

    //render method to return map control
    public render(): JSX.Element {
        return (
            <div className="assessment-map-viewer-component" style={{ width: "100%", height: "100vh" }}>
                {this.state.isLoading && (
                    <div style={{ padding: "20px", textAlign: "center" }}>
                        Loading assessment locations...
                    </div>
                )}
                {this.state.errorMessage && !this.state.isLoading && (
                    <div style={{ padding: "20px", color: "red", textAlign: "center" }}>
                        {this.state.errorMessage}
                    </div>
                )}
                <div id="azureMapControl" style={{ width: "100%", height: "100%" }}></div>
            </div>
        );
    }
}
