import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import React from "react";
import CommonService, { IListItem } from '../common/CommonService';
import * as constants from '../common/Constants';
import * as atlas from 'azure-maps-control';
import "azure-maps-control/dist/atlas.min.css";

export interface IMapViewerProps {
    incidentData: IListItem;
    azureMapKey: { value: string };
    showMessageBar(message: string, type: string): void;
    userPrincipalName: any;
    localeStrings: any;
    appInsights: ApplicationInsights;
    graphBaseUrl: any;
}
export interface IMapViewerState {
    mapViewerData: any[];
    tabContext?: {
        userId?: string | null;
        tenantId?: string | null;
        userPrincipalName?: string | null;
        groupId?: string | null;
        theme?: string | null;
    } | null;
}

export class MapViewer extends React.Component<IMapViewerProps, IMapViewerState> {
    constructor(props: IMapViewerProps) {
        super(props);
        this.state = {
            mapViewerData: [],
            tabContext: null
        }
    }

    //On component Load get the incidents data and generate map
    public async componentDidMount() {
        // Parse Teams placeholders passed in the tab URL (if any) before initializing map
        await this.extractAndLogTabParameters();
        this.initMap(this.props.incidentData);
    }

    private dataService = new CommonService();

    //Get incidents data, generate map and pin points as per the icnidents data
    private initMap(incidentsData: any) {
        try {
            //Get the Azure map key configured by the user in Config Settings screen
            var azureMapKey = this.props.azureMapKey.value;
            
            //For GCCH Tenant
            if (this.props.graphBaseUrl !== constants.defaultGraphBaseURL) {
                atlas.setDomain('atlas.azure.us');
            }

            //Create azure map control with the Azure Maps subscription key
            const incidentsMap = new atlas.Map('azureMapControl', {           
                center: [0, 0],
                zoom: 0,
                language: 'en-US',
                view: 'Auto',
                authOptions: {
                    authType: atlas.AuthenticationType.subscriptionKey,
                    subscriptionKey: azureMapKey
                }
            });

            //Exclude the list of incidents which have Custom location 
            const filteredData = incidentsData.filter((e: any) => {
                let location;
                try {
                    location = JSON.parse(e.location);
                } catch (error) {
                    console.error(constants.errorLogPrefix + "_Error parsing location:", error);
                    return false;
                }
                return location && location.EntityType !== "Custom";
            });

            // Determine current user id from tab context (Teams will substitute placeholders when opened in Teams)
            const currentUserId = this.state?.tabContext?.userId || null;

            // Collect related incidents (for highlighting)
            const relatedLocations: Array<[number, number]> = [];

            //Generate pins for each incident and add it to the map with colors depending on the incident status
            filteredData.forEach((item: any) => {
                let pinColor: string;
                switch (item.incidentStatusObj.status) {
                    case constants.planning:
                        pinColor = 'gray';
                        break;
                    case constants.active:
                        pinColor = 'orange';
                        break;
                    case constants.closed:
                        pinColor = 'green';
                        break;
                    default:
                        pinColor = 'gray';
                        break;
                }

                try {
                    const coordinates = JSON.parse(item.location).Coordinates;
                    // Determine if this incident is related to the current user (commander, created by, or role assignments)
                    let isRelated = false;
                    try {
                        const createdById = item.createdById ? item.createdById.toString() : "";
                        const incidentCommander = item.incidentCommanderObj ? item.incidentCommanderObj.toString() : "";
                        const roleAssignmentsStr = item.roleAssignments ? item.roleAssignments.toString() : item.roleAssignmentsObj ? JSON.stringify(item.roleAssignmentsObj) : "";
                        if (currentUserId && (createdById === currentUserId || incidentCommander.indexOf(currentUserId) !== -1 || roleAssignmentsStr.indexOf(currentUserId) !== -1)) {
                            isRelated = true;
                        }
                    } catch (e) {
                        // ignore parse errors
                    }
                    if (isRelated) {
                        pinColor = 'red';
                        relatedLocations.push([coordinates.Longitude, coordinates.Latitude]);
                    }
                    //Create an HTML marker for the pins and add it to the map.
                    var pinMarker = new atlas.HtmlMarker({
                        color: pinColor,
                        text: item.incidentId,
                        position: [coordinates.Longitude, coordinates.Latitude],
                        popup: new atlas.Popup({
                            content: '<div style="padding:10px;color:grey"><a href="' + item.teamWebURL + '" target="_blank">' + item.incidentId + ': ' + item.incidentName + '</a> <br> ' + this.props.localeStrings.status + ': ' + item.incidentStatusObj.status + '<br>' + this.props.localeStrings.location + ': ' + JSON.parse(item.location).DisplayName + '<br>' + item.incidentCommander + "</div>",
                            pixelOffset: [0, -30]
                        })
                    });

                    //add the markers to thwe map
                    incidentsMap.markers.add(pinMarker);

                    //Add on mouse enter event to toggle the popup.
                    incidentsMap.events.add('mouseenter', pinMarker, () => {
                        pinMarker.togglePopup();
                    });
                }
                catch (error) {
                    console.error(constants.errorLogPrefix + "_Error parsing coordinates:", error);
                }
            });

            // If any related incidents were found, center the map on the first related one and zoom in
            if (relatedLocations.length > 0) {
                const first = relatedLocations[0];
                incidentsMap.setCamera({ center: first, zoom: 6 });
            }

        } catch (error) {
            console.error(
                constants.errorLogPrefix + "_MapViewer_initMap \n",
                JSON.stringify(error)
            );
            this.props.showMessageBar(this.props.localeStrings.genericErrorMessage + ", " + this.props.localeStrings.formatIncidentsDataFailedErrMsg, constants.messageBarType.error);
            // Log Exception in App insights
            this.dataService.trackException(this.props.appInsights, error, constants.componentNames.MapViewer, 'InitMap', this.props.userPrincipalName);
        }
    }

    // Extract URL parameters passed from Teams tab with dynamic placeholders
    private extractAndLogTabParameters = async () => {
        try {
            if (typeof window === 'undefined' || !window.location) return;
            const params = new URLSearchParams(window.location.search);
            const userId = params.get('userId');
            const tenantId = params.get('tid');
            const userPrincipalName = params.get('upn');
            const groupId = params.get('groupId');
            const theme = params.get('theme');

            const tabContext = {
                userId: userId,
                tenantId: tenantId,
                userPrincipalName: userPrincipalName,
                groupId: groupId,
                theme: theme
            };

            // Save tab context into component state so map rendering can use it
            this.setState({ tabContext: tabContext });

            console.log(constants.infoLogPrefix + "MapViewer Tab Context Parameters:", JSON.stringify(tabContext));
        } catch (error) {
            console.error(
                constants.errorLogPrefix + "_MapViewer_extractAndLogTabParameters \n",
                JSON.stringify(error)
            );
        }
    }

    //render method to return map control
    public render(): JSX.Element {
        return (
            <div className="map-viewer-component">
                <div id="azureMapControl" style={{ "width": "100%", "height": "100%" }} ></div>
            </div>
        );
    }
}