import React from "react";
import { AssessmentMapViewer } from "./AssessmentMapViewer";
import { TeamsFxProvider } from "@microsoft/mgt-teamsfx-provider";
import { TeamsUserCredential } from "@microsoft/teamsfx";
import * as graphConfig from "../common/graphConfig";
import * as constants from "../common/Constants";
import siteConfig from "../config/siteConfig.json";
import CommonService from "../common/CommonService";
import { ApplicationInsights } from "@microsoft/applicationinsights-web";
import LocalizedStrings from "react-localization";
import { localizedStrings } from "../locale/LocaleStrings";
import { Client } from "@microsoft/microsoft-graph-client";
import { MessageBar, MessageBarType } from "@fluentui/react";

interface IAssessmentMapTabProps {
    teamsUserCredential: TeamsUserCredential;
}

interface IAssessmentMapTabState {
    incidentId: string;
    siteUrl: string;
    listName: string;
    azureMapKey: string;
    showErrorMessage: boolean;
    errorMessage: string;
    showSuccessMessage: boolean;
    successMessage: string;
    isInitialized: boolean;
    graph: Client | null;
    userPrincipalName: string;
    graphBaseUrl: string;
    locale: string;
}

let localeStrings = new LocalizedStrings(localizedStrings);
let appInsights: ApplicationInsights;

export default class AssessmentMapTab extends React.Component<IAssessmentMapTabProps, IAssessmentMapTabState> {
    private credential: TeamsUserCredential = this.props?.teamsUserCredential;
    private scope = graphConfig.scope;
    private dataService = new CommonService();

    constructor(props: IAssessmentMapTabProps) {
        super(props);
        
        //Extract URL parameters - parse from hash since we use HashRouter
        //URL format: index.html#/assessmentmap?incidentId=...&siteUrl=...&listName=...
        const hash = window.location.hash;
        const queryString = hash.includes('?') ? hash.split('?')[1] : '';
        const params = new URLSearchParams(queryString);

        const incidentId = params.get('incidentId') || '';
        const siteUrl = params.get('siteUrl') || '';
        const listName = params.get('listName') || siteConfig.assessmentsList;

        //Validate required parameters
        let errorMessage = '';
        if (!siteUrl || siteUrl.trim() === '') {
            errorMessage = 'Site URL is missing. Please ensure the Assessment Map is configured correctly with a valid SharePoint site URL.';
        }

        this.state = {
            incidentId: incidentId,
            siteUrl: siteUrl,
            listName: listName,
            azureMapKey: '',
            showErrorMessage: errorMessage !== '',
            errorMessage: errorMessage,
            showSuccessMessage: false,
            successMessage: '',
            isInitialized: false,
            graph: null,
            userPrincipalName: '',
            graphBaseUrl: constants.defaultGraphBaseURL,
            locale: 'en-US'
        };
    }

    public async componentDidMount() {
        await this.initializeApp();
    }

    //Initialize app and load required data
    private initializeApp = async () => {
        try {
            //Initialize Graph client
            const graphBaseURL = process.env.REACT_APP_GRAPH_BASE_URL?.toString().replace(/\s+/g, '');
            const baseURL = graphBaseURL || constants.defaultGraphBaseURL;

            const authProvider = new TeamsFxProvider(this.credential, this.scope);
            const graphClient: Client = Client.initWithMiddleware({
                authProvider: authProvider,
                baseUrl: baseURL
            });

            const userDetails = await graphClient.api(graphConfig.meGraphEndpoint).get();

            //Get locale
            const locale = userDetails.preferredLanguage?.substring(0, 2).toLowerCase() || "en";
            localeStrings.setLanguage(locale);

            //Initialize Application Insights
            if (!appInsights) {
                appInsights = new ApplicationInsights({
                    config: {
                        instrumentationKey: process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY ? process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY : ''
                    }
                });
                appInsights.loadAppInsights();
            }

            //Get Azure Maps key from config
            let siteName = process.env.REACT_APP_SHAREPOINT_SITE_NAME?.toString().replace(/\s+/g, '');
            const rootSite = await this.dataService.getTenantDetails(graphConfig.rootSiteGraphEndpoint, graphClient);
            const tenantName = rootSite.siteCollection.hostname;
            const graphContextURL = rootSite["@odata.context"].split("$")[0];
            const urlForSiteId = graphConfig.spSiteGraphEndpoint + tenantName + ":/sites/" + siteName + "?$select=id";
            const siteDetails = await this.dataService.getGraphData(urlForSiteId, graphClient);
            
            if (siteDetails && siteDetails.id) {
                const configEndpoint = `${graphConfig.spSiteGraphEndpoint}${siteDetails.id}/lists/${siteConfig.configurationList}/items?$expand=fields&$Top=5000`;
                const configData = await this.dataService.getConfigData(configEndpoint, graphClient, [constants.azureMapsKey]);
                const azureMapItem = configData.filter((item: any) => item.title === constants.azureMapsKey);
                
                const azureMapKey = azureMapItem.length > 0 ? azureMapItem[0].value : '';

                this.setState({
                    azureMapKey: azureMapKey,
                    graph: graphClient,
                    userPrincipalName: userDetails.userPrincipalName,
                    graphBaseUrl: baseURL,
                    locale: locale,
                    isInitialized: true
                });
            } else {
                throw new Error("Could not load application configuration");
            }
        } catch (error: any) {
            console.error(constants.errorLogPrefix + "_AssessmentMapTab_initializeApp", error);
            this.setState({
                showErrorMessage: true,
                errorMessage: "Failed to initialize assessment map: " + (error?.message || "Unknown error"),
                isInitialized: false
            });
            this.dataService.trackException(appInsights, error, "AssessmentMapTab", "InitializeApp", "");
        }
    }

    //Show message bar
    private showMessageBar = (message: string, type: string) => {
        if (type === constants.messageBarType.error) {
            this.setState({
                showErrorMessage: true,
                errorMessage: message
            });
        } else {
            this.setState({
                showSuccessMessage: true,
                successMessage: message
            });
        }

        //Hide message bar after 5 seconds
        setTimeout(() => {
            this.setState({
                showErrorMessage: false,
                showSuccessMessage: false
            });
        }, 5000);
    }

    public render(): JSX.Element {
        return (
            <div style={{ width: "100%", height: "100vh" }}>
                {this.state.showErrorMessage && (
                    <MessageBar 
                        messageBarType={MessageBarType.error}
                        onDismiss={() => this.setState({ showErrorMessage: false })}
                    >
                        {this.state.errorMessage}
                    </MessageBar>
                )}
                {this.state.showSuccessMessage && (
                    <MessageBar 
                        messageBarType={MessageBarType.success}
                        onDismiss={() => this.setState({ showSuccessMessage: false })}
                    >
                        {this.state.successMessage}
                    </MessageBar>
                )}
                {!this.state.isInitialized && !this.state.showErrorMessage && (
                    <div style={{ padding: "20px", textAlign: "center" }}>
                        Initializing assessment map...
                    </div>
                )}
                {this.state.isInitialized && this.state.graph && this.state.siteUrl && (
                    <AssessmentMapViewer
                        incidentId={this.state.incidentId}
                        siteUrl={this.state.siteUrl}
                        listName={this.state.listName}
                        azureMapKey={this.state.azureMapKey}
                        showMessageBar={this.showMessageBar}
                        userPrincipalName={this.state.userPrincipalName}
                        localeStrings={localeStrings}
                        appInsights={appInsights}
                        graphBaseUrl={this.state.graphBaseUrl}
                        graph={this.state.graph}
                    />
                )}
            </div>
        );
    }
}
