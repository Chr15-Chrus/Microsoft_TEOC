// Admin interface for managing data sources
(function() {
    'use strict';
    
    // Configuration
    const API_BASE = window.location.origin;
    
    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', init);
    
    async function init() {
        await initAdminAuth();
        setupBackToMapButton();
        setupAuthUI();
        setupTabNavigation();
        setupSourceTypeSelector();
        setupSharePointURLParser();
        setupFormSubmission();
        loadSources();
    }
    
    // Initialize authentication using the shared auth module
    async function initAdminAuth() {
        // Check if auth module is loaded
        if (typeof initAuth === 'undefined') {
            console.warn('Auth module not loaded');
            return;
        }
        
        try {
            // Get config first
            const configResponse = await fetch(`${API_BASE}/config`);
            if (!configResponse.ok) {
                throw new Error(`Failed to load config (${configResponse.status})`);
            }
            const config = await configResponse.json();
            
            // Initialize API module
            if (typeof initAPI !== 'undefined') {
                initAPI(API_BASE);
            }
            
            // Initialize auth with config
            const token = await initAuth(config);
            
            // Set token for API calls if available
            if (token && typeof setAPIToken !== 'undefined') {
                setAPIToken(token);
            }
            
            // Update auth UI to show logged-in state
            if (typeof updateAuthUI !== 'undefined') {
                updateAuthUI();
            }
        } catch (error) {
            console.error('Failed to initialize auth:', error);
        }
    }
    
    // Setup authentication UI handlers
    function setupAuthUI() {
        const loginBtn = document.getElementById('login-btn');
        const userBtn = document.getElementById('user-btn');
        const userMenu = document.getElementById('user-menu');
        const userSignout = document.getElementById('user-signout');
        
        if (loginBtn) {
            loginBtn.addEventListener('click', async () => {
                try {
                    if (typeof signIn !== 'undefined') {
                        await signIn();
                    }
                } catch (e) {
                    console.error('Sign in failed:', e);
                }
            });
        }
        
        if (userBtn && userMenu) {
            userBtn.addEventListener('click', () => {
                const isOpen = userMenu.getAttribute('aria-hidden') === 'false';
                userMenu.setAttribute('aria-hidden', isOpen ? 'true' : 'false');
                userBtn.setAttribute('aria-expanded', !isOpen);
            });
        }
        
        if (userSignout) {
            userSignout.addEventListener('click', async () => {
                try {
                    await signOut();
                } catch (e) {
                    console.error(e);
                }
            });
        }
    }
    
    // Setup back to map button
    function setupBackToMapButton() {
        const backBtn = document.getElementById('back-to-map');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.location.href = '/web/';
            });
        }
    }
    
    // Tab navigation
    function setupTabNavigation() {
        const tabs = document.querySelectorAll('.nav-tab');
        const contents = document.querySelectorAll('.tab-content');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const targetId = tab.dataset.tab;
                
                // Update active states
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                
                tab.classList.add('active');
                document.getElementById(targetId).classList.add('active');
                
                // Load sources when switching to manage tab
                if (targetId === 'manage-sources') {
                    loadSources();
                }
            });
        });
    }
    
    // Source type selector
    function setupSourceTypeSelector() {
        const sourceType = document.getElementById('source-type');
        const sharePointFields = document.getElementById('sharepoint-fields');
        const dynamicsFields = document.getElementById('dynamics-fields');
        const customFields = document.getElementById('custom-fields');
        const commonFields = document.getElementById('common-fields');
        
        sourceType.addEventListener('change', (e) => {
            // Hide all source-specific fields
            sharePointFields.style.display = 'none';
            dynamicsFields.style.display = 'none';
            customFields.style.display = 'none';
            commonFields.style.display = 'none';
            
            // Show relevant fields based on selection
            const type = e.target.value;
            if (type === 'sharepoint') {
                sharePointFields.style.display = 'block';
                commonFields.style.display = 'block';
            } else if (type === 'dynamics') {
                dynamicsFields.style.display = 'block';
                commonFields.style.display = 'block';
            } else if (type === 'custom') {
                customFields.style.display = 'block';
                commonFields.style.display = 'block';
            }
        });
    }
    
    // SharePoint URL parser
    function setupSharePointURLParser() {
        const urlInput = document.getElementById('sharepoint-url');
        const siteInput = document.getElementById('sharepoint-site');
        
        urlInput.addEventListener('blur', async () => {
            const url = urlInput.value.trim();
            if (!url) return;
            
            try {
                const parsed = new URL(url);
                const pathParts = parsed.pathname.split('/');
                
                // Extract site URL (everything up to /Lists/ or /Shared Documents/)
                const sitePath = pathParts.slice(0, pathParts.indexOf('Lists') || pathParts.indexOf('Shared')).join('/');
                const siteUrl = `${parsed.protocol}//${parsed.host}${sitePath}`;
                
                siteInput.value = siteUrl;
                
                // Auto-populate source name if empty
                const sourceNameInput = document.getElementById('source-name');
                if (!sourceNameInput.value) {
                    const listName = pathParts[pathParts.length - 1] || 'SharePoint List';
                    sourceNameInput.value = listName.replace(/%20/g, ' ');
                }
            } catch (err) {
                console.error('Invalid URL:', err);
                showAlert('add-source-alert', 'Please enter a valid SharePoint list URL', 'error');
            }
        });
    }
    
    // Form submission
    function setupFormSubmission() {
        const form = document.getElementById('add-source-form');
        const cancelBtn = document.getElementById('cancel-btn');
        
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            await registerSource();
        });
        
        cancelBtn.addEventListener('click', () => {
            form.reset();
            document.getElementById('source-type').value = '';
            document.querySelectorAll('.source-fields').forEach(el => el.style.display = 'none');
            document.getElementById('common-fields').style.display = 'none';
        });
    }
    
    // Register new data source
    async function registerSource() {
        const submitBtn = document.querySelector('button[type="submit"]');
        const submitText = document.getElementById('submit-text');
        const submitLoading = document.getElementById('submit-loading');
        
        // Disable button and show loading
        submitBtn.disabled = true;
        submitText.style.display = 'none';
        submitLoading.style.display = 'inline';
        
        try {
            const sourceType = document.getElementById('source-type').value;
            const sourceName = document.getElementById('source-name').value;
            const sourceDescription = document.getElementById('source-description').value;
            const autoConfigure = document.getElementById('auto-configure').checked;
            
            let sourceData = {
                type: sourceType,
                name: sourceName,
                description: sourceDescription,
                autoConfigure: autoConfigure
            };
            
            // Add source-specific data
            if (sourceType === 'sharepoint') {
                sourceData.sharepoint = {
                    listUrl: document.getElementById('sharepoint-url').value,
                    siteUrl: document.getElementById('sharepoint-site').value,
                    listId: document.getElementById('sharepoint-list-id').value
                };
            } else if (sourceType === 'dynamics') {
                sourceData.dynamics = {
                    instanceUrl: document.getElementById('dynamics-url').value,
                    entity: document.getElementById('dynamics-entity').value
                };
            } else if (sourceType === 'custom') {
                sourceData.custom = {
                    webhookUrl: document.getElementById('custom-url').value,
                    format: document.getElementById('custom-format').value
                };
            }
            
            // Call API to register source
            const result = await apiRequest('/registerSource', {
                method: 'POST',
                body: JSON.stringify(sourceData)
            });
            
            // Show success message
            showAlert('add-source-alert', 
                `✅ Source registered successfully! ${autoConfigure ? 'Webhook and Event Grid connection configured automatically.' : ''}`,
                'success'
            );
            
            // Display connection details
            if (result.webhook) {
                const details = `
                    <div style="margin-top: 16px; padding: 12px; background: #f9fafb; border-radius: 6px; font-family: monospace; font-size: 12px;">
                        <strong>Webhook Details:</strong><br>
                        URL: ${result.webhook.url}<br>
                        ${result.webhook.clientState ? `Validation Token: ${result.webhook.clientState}<br>` : ''}
                        ${result.webhook.expirationDate ? `Expires: ${result.webhook.expirationDate}` : ''}
                    </div>
                `;
                document.getElementById('add-source-alert').innerHTML += details;
            }
            
            // Reset form after 3 seconds
            setTimeout(() => {
                document.getElementById('add-source-form').reset();
                document.getElementById('source-type').value = '';
                document.querySelectorAll('.source-fields').forEach(el => el.style.display = 'none');
                document.getElementById('common-fields').style.display = 'none';
                document.getElementById('add-source-alert').innerHTML = '';
            }, 5000);
            
        } catch (error) {
            console.error('Error registering source:', error);
            showAlert('add-source-alert', 
                `❌ Error: ${error.message}. Please check your configuration and try again.`,
                'error'
            );
        } finally {
            // Re-enable button
            submitBtn.disabled = false;
            submitText.style.display = 'inline';
            submitLoading.style.display = 'none';
        }
    }
    
    // Load existing sources
    async function loadSources() {
        const loading = document.getElementById('sources-loading');
        const content = document.getElementById('sources-content');
        const list = document.getElementById('sources-list');
        
        loading.style.display = 'block';
        content.style.display = 'none';
        
        try {
            const sources = await apiRequest('/getSources');
            
            if (!Array.isArray(sources) || sources.length === 0) {
                list.innerHTML = '<li style="text-align: center; padding: 40px; color: #6b7280;">No data sources configured yet. Add your first source above!</li>';
            } else {
                list.innerHTML = sources.map(source => createSourceItem(source)).join('');
                
                // Attach event listeners to action buttons
                attachSourceActionListeners();
            }
            
        } catch (error) {
            console.error('Error loading sources:', error);
            list.innerHTML = '<li style="text-align: center; padding: 40px; color: #ef4444;">Failed to load sources. Please try again.</li>';
        } finally {
            loading.style.display = 'none';
            content.style.display = 'block';
        }
    }
    
    // Create source list item HTML
    function createSourceItem(source) {
        const statusClass = source.active ? 'status-active' : 'status-inactive';
        const statusText = source.active ? 'Active' : 'Inactive';
        
        return `
            <li class="source-item">
                <div class="source-info">
                    <div class="source-name">
                        ${source.name}
                        <span class="source-status ${statusClass}">${statusText}</span>
                    </div>
                    <div class="source-type">
                        ${getSourceTypeDisplay(source.type)} • 
                        ${source.description || 'No description'} • 
                        Added ${new Date(source.createdDate).toLocaleDateString()}
                    </div>
                </div>
                <div class="source-actions">
                    <button class="btn btn-secondary btn-small" data-action="view" data-id="${source.id}">
                        View Details
                    </button>
                    <button class="btn btn-secondary btn-small" data-action="toggle" data-id="${source.id}">
                        ${source.active ? 'Disable' : 'Enable'}
                    </button>
                    <button class="btn btn-danger btn-small" data-action="delete" data-id="${source.id}">
                        Delete
                    </button>
                </div>
            </li>
        `;
    }
    
    // Get display name for source type
    function getSourceTypeDisplay(type) {
        const types = {
            'sharepoint': '📋 SharePoint List',
            'dynamics': '🔷 Dynamics 365',
            'custom': '🔗 Custom API'
        };
        return types[type] || type;
    }
    
    // Attach event listeners to source action buttons
    function attachSourceActionListeners() {
        document.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const action = e.target.dataset.action;
                const sourceId = e.target.dataset.id;
                
                if (action === 'view') {
                    await viewSourceDetails(sourceId);
                } else if (action === 'toggle') {
                    await toggleSource(sourceId);
                } else if (action === 'delete') {
                    await deleteSource(sourceId);
                }
            });
        });
    }
    
    // View source details
    async function viewSourceDetails(sourceId) {
        try {
            const source = await apiRequest(`/getSource?id=${encodeURIComponent(sourceId)}`);
            
            // Show details in a better format
            const detailsHtml = `
                <div style="background: #f9fafb; padding: 16px; border-radius: 8px; margin-top: 12px;">
                    <h3 style="margin-top: 0;">Source Details</h3>
                    <p><strong>Name:</strong> ${source.name}</p>
                    <p><strong>Type:</strong> ${source.type}</p>
                    <p><strong>Status:</strong> ${source.active ? 'Active' : 'Inactive'}</p>
                    ${source.webhookUrl ? `<p><strong>Webhook:</strong> ${source.webhookUrl}</p>` : ''}
                    ${source.webhookExpiration ? `<p><strong>Expires:</strong> ${new Date(source.webhookExpiration).toLocaleDateString()}</p>` : ''}
                </div>
            `;
            showAlert('sources-alert', detailsHtml, 'info');
        } catch (error) {
            showAlert('sources-alert', 'Failed to load source details', 'error');
        }
    }
    
    // Show alert in sources section
    function showSourcesAlert(message, type = 'info') {
        const container = document.getElementById('sources-content');
        const alertClass = `alert-${type}`;
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert ${alertClass}`;
        alertDiv.id = 'sources-alert';
        alertDiv.innerHTML = message;
        container.insertBefore(alertDiv, container.firstChild);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
    
    // Toggle source active state
    async function toggleSource(sourceId) {
        if (!confirm('Are you sure you want to change the status of this source?')) {
            return;
        }
        
        try {
            await apiRequest('/toggleSource', {
                method: 'POST',
                body: JSON.stringify({ id: sourceId })
            });
            await loadSources();
            showSourcesAlert('Source status updated successfully', 'success');
        } catch (error) {
            showSourcesAlert('Error toggling source', 'error');
        }
    }
    
    // Delete source
    async function deleteSource(sourceId) {
        if (!confirm('Are you sure you want to delete this source? This will also remove the webhook registration.')) {
            return;
        }
        
        try {
            await apiRequest('/deleteSource', {
                method: 'DELETE',
                body: JSON.stringify({ id: sourceId })
            });
            await loadSources();
            showSourcesAlert('Source deleted successfully', 'success');
        } catch (error) {
            const message = error && error.message ? error.message : 'Error deleting source';
            showSourcesAlert(message, 'error');
        }
    }
    
    // Show alert message
    function showAlert(containerId, message, type = 'info') {
        const container = document.getElementById(containerId);
        const alertClass = `alert-${type}`;
        container.innerHTML = `<div class="alert ${alertClass}">${message}</div>`;
        
        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                container.innerHTML = '';
            }, 5000);
        }
    }
})();
