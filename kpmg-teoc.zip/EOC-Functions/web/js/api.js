/**
 * API module for interacting with Azure Functions backend
 * Simplified to work with same-origin requests from Functions host
 */

let apiBaseUrl = '';
let apiToken = null;
let serverApiScope = null;
let apiAudience = null;
let tokenRefreshInFlight = null;

function decodeJwtPayload(token) {
    if (!token || typeof token !== 'string') return null;
    const parts = token.split('.');
    if (parts.length < 2) return null;
    try {
        const normalized = parts[1].replace(/-/g, '+').replace(/_/g, '/');
        const padded = normalized + '==='.slice((normalized.length + 3) % 4);
        const json = atob(padded);
        return JSON.parse(json);
    } catch (err) {
        console.warn('decodeJwtPayload failed:', err && err.message);
        return null;
    }
}

function isFunctionAudienceToken(token) {
    const payload = decodeJwtPayload(token);
    if (!payload) return false;
    const audience = payload.aud || payload.audience || '';
    const scopes = typeof payload.scp === 'string' ? payload.scp.split(' ') : [];
    const hasAccessScope = scopes.includes('access_as_user');
    const matchesAudience = apiAudience ? audience === apiAudience : audience.startsWith('api://');
    return matchesAudience && hasAccessScope;
}

/**
 * Initialize API module
 * @param {string} baseUrl - Base URL for API endpoints
 */
function initAPI(baseUrl) {
    // Use provided base URL, or default to the Functions host root.
    // Local Functions in this project expose functions at the root
    // (e.g. `http://localhost:7071/config`), not under `/api`.
    apiBaseUrl = baseUrl ? baseUrl.replace(/\/$/, '') : window.location.origin.replace(/\/$/, '');
    // Try to fetch server config once to learn the apiScope for diagnostics
    try {
        fetch('/config').then(r => r.json()).then(cfg => {
            if (cfg && cfg.apiScope) {
                serverApiScope = cfg.apiScope;
                apiAudience = cfg.apiScope.replace(/\/?access_as_user$/i, '');
                console.log('initAPI: server apiScope:', serverApiScope);
            } else if (cfg && cfg.identifierUri) {
                apiAudience = cfg.identifierUri;
            }
        }).catch(() => {});
    } catch (e) {}
}

/**
 * Set authentication token
 * @param {string} token - Access token
 */
function setAPIToken(token) {
    if (token && !isFunctionAudienceToken(token)) {
        try {
            console.warn('setAPIToken ignored token with mismatched audience');
        } catch (e) {}
        return;
    }

    apiToken = token;
    try {
        console.log('setAPIToken called; token present:', !!token);
    } catch (e) {
        // no-op
    }
}

async function ensureApiToken(forceRefresh = false) {
    if (typeof window === 'undefined' || typeof window.getAccessToken !== 'function') {
        return apiToken;
    }

    if (!forceRefresh && apiToken) {
        return apiToken;
    }

    if (tokenRefreshInFlight) {
        return tokenRefreshInFlight;
    }

    tokenRefreshInFlight = (async () => {
        try {
            const fresh = await window.getAccessToken();
            if (fresh) {
                setAPIToken(fresh);
                window.apiToken = fresh;
                return fresh;
            }
        } catch (err) {
            console.warn('ensureApiToken failed:', err && err.message ? err.message : err);
        } finally {
            tokenRefreshInFlight = null;
        }
        return apiToken;
    })();

    return tokenRefreshInFlight;
}

/**
 * Make authenticated API request
 * @param {string} endpoint - API endpoint path (should start with /)
 * @param {Object} options - Fetch options
 */
async function apiRequest(endpoint, options = {}) {
    // Ensure we have a base URL
    if (!apiBaseUrl) {
        apiBaseUrl = window.location.origin;
    }
    
    const url = `${apiBaseUrl}${endpoint}`;
    
    const maxAttempts = 2;
    let attempt = 0;
    let lastError = null;

    while (attempt < maxAttempts) {
        // Refresh token on first attempt (ensures admin endpoints use access_as_user token)
        await ensureApiToken(attempt > 0);

        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        if (apiToken) {
            headers['Authorization'] = `Bearer ${apiToken}`;
        }

        try {
            console.log('apiRequest:', url, 'Authorization present:', !!headers['Authorization'], 'Auth length:', headers['Authorization'] ? headers['Authorization'].length : 0, 'serverApiScope:', serverApiScope || '(unknown)');
        } catch (e) {}

        try {
            const response = await fetch(url, {
                ...options,
                headers
            });

            if (response.ok) {
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    return await response.json();
                }
                return await response.text();
            }

            // Attempt one forced refresh on 401 to capture newly-elevated roles
            if (response.status === 401 && attempt === 0) {
                console.warn('apiRequest received 401; forcing token refresh and retry');
                attempt++;
                continue;
            }

            const errorText = await response.text();
            throw new Error(`API error: ${response.status} - ${errorText}`);
        } catch (error) {
            lastError = error;
            // Only retry once when explicitly forced above
            if (attempt >= maxAttempts - 1) {
                console.error('API request failed:', error);
                throw error;
            }
            attempt++;
        }
    }

    if (lastError) {
        throw lastError;
    }
}

/**
 * Fetch all items from all data sources
 * @param {Object} filters - Optional filter parameters for assessment mode
 * @param {string} filters.incidentId - Filter by incident ID
 * @param {string} filters.siteUrl - SharePoint site URL for dynamic source
 * @param {string} filters.listName - SharePoint list name for dynamic source
 * @param {string} filters.dataSource - Data source type (e.g., 'assessments')
 * @returns {Promise<Object>} Object with items array and sources array
 */
async function fetchItems(filters = {}) {
    try {
        // Ensure we have a fresh access token before calling protected API.
        try {
            if (typeof window.getAccessToken === 'function') {
                const fresh = await window.getAccessToken();
                if (fresh) {
                    setAPIToken(fresh);
                    window.apiToken = fresh;
                }
            }
        } catch (e) {
            console.warn('Failed to refresh access token before fetchItems:', e && e.message);
        }

        // Build query string from filters
        let endpoint = '/getItems';
        if (filters && Object.keys(filters).length > 0) {
            const params = new URLSearchParams();
            // Use explicit null/undefined checks to allow falsy values like "0"
            if (filters.incidentId !== null && filters.incidentId !== undefined) {
                params.append('incidentId', filters.incidentId);
            }
            if (filters.siteUrl !== null && filters.siteUrl !== undefined) {
                params.append('siteUrl', filters.siteUrl);
            }
            if (filters.listName !== null && filters.listName !== undefined) {
                params.append('listName', filters.listName);
            }
            if (filters.dataSource !== null && filters.dataSource !== undefined) {
                params.append('dataSource', filters.dataSource);
            }
            
            const queryString = params.toString();
            if (queryString) {
                endpoint += '?' + queryString;
            }
        }

        const data = await apiRequest(endpoint);
        
        // Return full response with items and sources
        return {
            items: data.items || [],
            sources: data.sources || [],
            count: data.count || (data.items || []).length
        };
    } catch (error) {
        console.error('Failed to fetch items:', error);
        showToast('Failed to load items: ' + error.message, 'error');
        return { items: [], sources: [], count: 0 };
    }
}

/**
 * Create a new item
 * @param {Object} itemData - Item data to create
 * @returns {Promise<Object>} Created item
 */
async function createItem(itemData) {
    try {
        const result = await apiRequest('/createItem', {
            method: 'POST',
            body: JSON.stringify(itemData)
        });
        
        showToast('Item created successfully', 'success');
        return result;
    } catch (error) {
        console.error('Failed to create item:', error);
        showToast('Failed to create item: ' + error.message, 'error');
        throw error;
    }
}

/**
 * Update an existing item
 * @param {string} itemId - Item ID
 * @param {Object} itemData - Updated item data
 * @returns {Promise<Object>} Updated item
 */
async function updateItem(itemId, itemData) {
    try {
        const result = await apiRequest(`/updateItem/${itemId}`, {
            method: 'PATCH',
            body: JSON.stringify(itemData)
        });
        
        showToast('Item updated successfully', 'success');
        return result;
    } catch (error) {
        console.error('Failed to update item:', error);
        showToast('Failed to update item: ' + error.message, 'error');
        throw error;
    }
}

/**
 * Delete an item
 * @param {string} itemId - Item ID
 * @returns {Promise<void>}
 */
async function deleteItem(itemId) {
    try {
        await apiRequest(`/deleteItem/${itemId}`, {
            method: 'DELETE'
        });
        
        showToast('Item deleted successfully', 'success');
    } catch (error) {
        console.error('Failed to delete item:', error);
        showToast('Failed to delete item: ' + error.message, 'error');
        throw error;
    }
}

/**
 * Geocode an address to coordinates
 * @param {string} address - Address to geocode
 * @returns {Promise<Object>} Coordinates object with lat/lon
 */
async function geocodeAddress(address) {
    try {
        const result = await apiRequest('/geocode', {
            method: 'POST',
            body: JSON.stringify({ address })
        });
        
        return result;
    } catch (error) {
        console.error('Geocoding failed:', error);
        return null;
    }
}

/**
 * Reverse geocode coordinates to address
 * @param {number} latitude - Latitude
 * @param {number} longitude - Longitude
 * @returns {Promise<Object>} Address object
 */
async function reverseGeocode(latitude, longitude) {
    try {
        const result = await apiRequest('/reverseGeocode', {
            method: 'POST',
            body: JSON.stringify({ latitude, longitude })
        });
        
        return result;
    } catch (error) {
        console.error('Reverse geocoding failed:', error);
        return null;
    }
}

/**
 * Get application configuration
 * @returns {Promise<Object>} Configuration object
 */
async function getConfig() {
    try {
        const config = await apiRequest('/config');
        return config;
    } catch (error) {
        console.error('Failed to get config:', error);
        // Return default config instead of throwing
        return {
            functionBaseUrl: window.location.origin,
            mapboxToken: '',
            entraClientId: '',
            entraTenantId: '',
            defaultMapCenter: [133.7751, -25.2744],
            defaultMapZoom: 4
        };
    }
}