/**
 * Notification Card Stack Manager
 * Manages the display of adaptive card notifications in the web UI
 */

// Import adaptive cards library (loaded via script tag)
// AdaptiveCards library and AdaptiveCardTemplates are global

let cardQueue = [];
let displayedCards = new Map(); // itemId -> card element
let autoDismissTime = 30000; // Default 30 seconds
let isInitialized = false;

/**
 * Initialize the notification card system
 * @param {Object} config - Configuration options
 */
async function initNotificationCards(config = {}) {
    if (isInitialized) {
        console.log('[NotificationCards] Already initialized');
        return;
    }

    console.log('[NotificationCards] Initializing...');

    // Load auto-dismiss configuration from app config or passed config
    if (config.notificationAutoDismiss !== undefined && config.notificationAutoDismiss > 0) {
        autoDismissTime = config.notificationAutoDismiss * 1000; // Convert seconds to ms
        console.log(`[NotificationCards] Auto-dismiss set to ${config.notificationAutoDismiss}s`);
    } else if (window.config && window.config.notificationAutoDismiss) {
        autoDismissTime = window.config.notificationAutoDismiss * 1000;
        console.log(`[NotificationCards] Auto-dismiss set to ${window.config.notificationAutoDismiss}s from global config`);
    }

    // Create notification container if it doesn't exist
    createNotificationContainer();

    // Listen for SignalR events
    if (typeof onSignalREvent === 'function') {
        onSignalREvent('newItem', handleNewItemEvent);
        console.log('[NotificationCards] Registered for newItem events');
    } else {
        console.warn('[NotificationCards] SignalR not available');
    }

    isInitialized = true;
    console.log('[NotificationCards] ✓ Initialized successfully');
}

/**
 * Create the notification container in the DOM
 */
function createNotificationContainer() {
    let container = document.getElementById('notification-card-stack');
    
    if (!container) {
        container = document.createElement('div');
        container.id = 'notification-card-stack';
        container.className = 'notification-card-stack';
        document.body.appendChild(container);
        console.log('[NotificationCards] Created notification container');
    }

    return container;
}

/**
 * Fetch auto-dismiss configuration from admin API
 * @returns {Promise<Object>} Configuration object with value in seconds
 */
async function fetchAutoDismissConfig() {
    try {
        const response = await fetch(`${apiBaseUrl}/getConfig?key=notificationAutoDismiss`);
        if (response.ok) {
            const data = await response.json();
            return data;
        }
    } catch (error) {
        console.warn('[NotificationCards] Failed to fetch auto-dismiss config:', error);
    }
    return null;
}

/**
 * Handle new item event from SignalR
 * @param {Object} item - Item data
 */
function handleNewItemEvent(item) {
    console.log('[NotificationCards] New item received:', item);
    
    // Check if this card is already displayed
    if (displayedCards.has(item.itemId)) {
        console.log('[NotificationCards] Card already displayed for item:', item.itemId);
        return;
    }

    // Create and display the card
    displayNotificationCard(item);
}

/**
 * Display a notification card for an item
 * @param {Object} itemData - Item data in CloudEvents or TEOC normalized format
 */
function displayNotificationCard(itemData) {
    try {
        // Always generate adaptive card JSON from CloudEvents data
        // This ensures consistency and allows the card to be customized based on client preferences
        const cardJson = window.AdaptiveCardTemplates.createEventNotificationCard(itemData, {
            includeActions: true,
            compact: false
        });

        // Create adaptive card instance
        const adaptiveCard = new AdaptiveCards.AdaptiveCard();
        
        // Set host config for styling
        adaptiveCard.hostConfig = new AdaptiveCards.HostConfig({
            fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif"
        });

        // Handle card actions
        adaptiveCard.onExecuteAction = (action) => {
            handleCardAction(action, itemData);
        };

        // Parse and render the card
        adaptiveCard.parse(cardJson);
        const renderedCard = adaptiveCard.render();

        if (!renderedCard) {
            console.error('[NotificationCards] Failed to render adaptive card');
            return;
        }

        // Create card wrapper with animations
        const cardWrapper = document.createElement('div');
        cardWrapper.className = 'notification-card-wrapper';
        cardWrapper.dataset.itemId = itemData.itemId || itemData.id;
        
        // Add rendered card
        cardWrapper.appendChild(renderedCard);

        // Add to container with slide-in animation
        const container = createNotificationContainer();
        container.appendChild(cardWrapper);

        // Trigger slide-in animation
        setTimeout(() => {
            cardWrapper.classList.add('show');
        }, 10);

        // Track displayed card
        displayedCards.set(itemData.itemId || itemData.id, cardWrapper);

        // Set auto-dismiss timer if configured
        if (autoDismissTime > 0) {
            setTimeout(() => {
                dismissCard(itemData.itemId || itemData.id);
            }, autoDismissTime);
        }

        console.log('[NotificationCards] Card displayed for item:', itemData.itemId);

    } catch (error) {
        console.error('[NotificationCards] Error displaying card:', error);
    }
}

/**
 * Handle card action (Show Location, Dismiss, etc.)
 * @param {Object} action - Adaptive card action
 * @param {Object} itemData - Item data
 */
function handleCardAction(action, itemData) {
    console.log('[NotificationCards] Card action:', action.data);

    const actionData = action.data || {};

    switch (actionData.action) {
        case 'showLocation':
            handleShowLocation(actionData, itemData);
            break;
        case 'dismiss':
            dismissCard(actionData.itemId);
            break;
        default:
            console.warn('[NotificationCards] Unknown action:', actionData.action);
    }
}

/**
 * Handle show location action - pan map and highlight item
 * @param {Object} actionData - Action data with coordinates
 * @param {Object} itemData - Full item data
 */
function handleShowLocation(actionData, itemData) {
    console.log('[NotificationCards] Show location:', actionData);

    // Dismiss the card
    dismissCard(actionData.itemId);

    // Pan map to location if map exists
    if (typeof flyToLocation === 'function' && actionData.coordinates) {
        flyToLocation(actionData.coordinates.lat, actionData.coordinates.lon);
        console.log('[NotificationCards] Map panned to location');
    } else if (typeof map !== 'undefined' && actionData.coordinates) {
        // Fallback: use map directly
        map.flyTo({
            center: [actionData.coordinates.lon, actionData.coordinates.lat],
            zoom: 15,
            duration: 1500
        });
        console.log('[NotificationCards] Map panned to location (fallback)');
    }

    // Highlight item in list if function exists
    if (typeof highlightItemInList === 'function') {
        highlightItemInList(actionData.itemId);
    }

    // Show toast confirmation
    if (typeof showToast === 'function') {
        showToast('Location shown on map', 'success');
    }
}

/**
 * Dismiss a notification card
 * @param {string} itemId - Item ID
 */
function dismissCard(itemId) {
    const cardWrapper = displayedCards.get(itemId);
    
    if (!cardWrapper) {
        console.warn('[NotificationCards] Card not found for dismissal:', itemId);
        return;
    }

    // Slide out animation
    cardWrapper.classList.remove('show');
    cardWrapper.classList.add('hiding');

    // Remove from DOM after animation
    setTimeout(() => {
        if (cardWrapper.parentNode) {
            cardWrapper.parentNode.removeChild(cardWrapper);
        }
        displayedCards.delete(itemId);
        console.log('[NotificationCards] Card dismissed:', itemId);
    }, 300);
}

/**
 * Dismiss all notification cards
 */
function dismissAllCards() {
    const itemIds = Array.from(displayedCards.keys());
    itemIds.forEach(itemId => dismissCard(itemId));
    console.log('[NotificationCards] All cards dismissed');
}

/**
 * Update auto-dismiss time
 * @param {number} seconds - Auto-dismiss time in seconds (0 = disabled)
 */
function setAutoDismissTime(seconds) {
    autoDismissTime = seconds * 1000;
    console.log(`[NotificationCards] Auto-dismiss time set to ${seconds}s`);
}

/**
 * Get current auto-dismiss time
 * @returns {number} Auto-dismiss time in seconds
 */
function getAutoDismissTime() {
    return autoDismissTime / 1000;
}

// Export functions for global use
window.initNotificationCards = initNotificationCards;
window.displayNotificationCard = displayNotificationCard;
window.dismissCard = dismissCard;
window.dismissAllCards = dismissAllCards;
window.setAutoDismissTime = setAutoDismissTime;
window.getAutoDismissTime = getAutoDismissTime;
