/**
 * Authentication module using MSAL.js
 * Handles both browser and Teams contexts
 */

// Provide a no-op toast fallback when the shared UI helpers are not loaded (e.g., admin page).
if (typeof window !== 'undefined' && typeof window.showToast !== 'function') {
    window.showToast = (message, type = 'info') => {
        const prefix = `[toast:${type}]`;
        if (type === 'error') {
            console.error(prefix, message);
        } else if (type === 'warn' || type === 'warning') {
            console.warn(prefix, message);
        } else {
            console.log(prefix, message);
        }
    };
}

// Detect iOS devices
function isIOSDevice() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
}

// Detect if running in iOS Safari (not in-app browser or Chrome iOS)
function isIOSSafari() {
    const ua = navigator.userAgent;
    const iOS = /iPad|iPhone|iPod/.test(ua) && !window.MSStream;
    const webkit = /WebKit/.test(ua);
    const iOSSafari = iOS && webkit && !/(CriOS|FxiOS|OPiOS|mercury|UCBrowser|SamsungBrowser)/.test(ua);
    return iOSSafari;
}

// Detect if the current browsing context enforces COOP/COEP (cross-origin
// isolation). In these environments, popup-based auth flows are unreliable
// because the opener cannot observe window.close(), so prefer redirects.
function isCrossOriginIsolatedContext() {
    if (typeof window === 'undefined') return false;
    if (window.crossOriginIsolated) return true;
    try {
        const coopMeta = document.querySelector("meta[http-equiv='Cross-Origin-Opener-Policy']");
        const coepMeta = document.querySelector("meta[http-equiv='Cross-Origin-Embedder-Policy']");
        const coop = coopMeta?.content?.toLowerCase() || '';
        const coep = coepMeta?.content?.toLowerCase() || '';
        return coop.includes('same-origin') && coep.includes('require-corp');
    } catch (e) {
        return false;
    }
}

const AUTH_FLOW_POPUP = 'popup';
const AUTH_FLOW_REDIRECT = 'redirect';
const FORCE_REDIRECT_AUTH = true; // Set to false only if you explicitly trust popup flows
let cachedAuthFlowPreference = null;

function supportsPopupAuth() {
    if (FORCE_REDIRECT_AUTH) return false;
    if (typeof window === 'undefined') return false;
    if (isIOSDevice() || isIOSSafari()) return false;
    if (isCrossOriginIsolatedContext()) return false;
    const host = window.location.hostname || '';
    const insecureContext = !window.isSecureContext && !(host.includes('localhost') || host.includes('127.'));
    if (insecureContext) return false;
    const ua = navigator.userAgent.toLowerCase();
    if (ua.includes('trident') || ua.includes('msie') || ua.includes('firefox/')) return false;
    return true;
}

function getAuthFlowPreference() {
    if (cachedAuthFlowPreference) {
        return cachedAuthFlowPreference;
    }
    try {
        const forcedRedirect = typeof window !== 'undefined' && window.localStorage && window.localStorage.getItem('teoc_force_redirect_auth');
        if (forcedRedirect === '1') {
            cachedAuthFlowPreference = AUTH_FLOW_REDIRECT;
            return cachedAuthFlowPreference;
        }
    } catch (e) {
        // ignore storage errors
    }
    cachedAuthFlowPreference = supportsPopupAuth() ? AUTH_FLOW_POPUP : AUTH_FLOW_REDIRECT;
    return cachedAuthFlowPreference;
}

// MSAL configuration with iOS-optimized settings
const msalConfig = {
    auth: {
        clientId: '', // Will be loaded from config
        authority: '', // Will be loaded from config
        // Use a stable redirect URI that maps to the web UI root. This helps
        // avoid mismatches and prevents MSAL popup/redirect confusion when
        // the current URL contains query/hash fragments.
        redirectUri: window.location.origin + '/web/',
        // Keep the user on the current page once the redirect flow completes;
        // MSAL caches state so there's no need for an extra navigation hop.
        navigateToLoginRequestUrl: false
    },
    cache: {
        // Persist auth cache across browser sessions so users don't need
        // to re-login on every page load. This stores tokens in localStorage.
        // For iOS Safari with ITP (Intelligent Tracking Prevention), also
        // store critical state in cookies with proper SameSite attributes.
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: true,
        // iOS Safari requires explicit cookie configuration
        secureCookies: true
    },
    system: {
        // iOS-specific timeout and retry settings
        tokenRenewalOffsetSeconds: 300, // Refresh tokens 5 minutes before expiry
        iframeHashTimeout: 10000, // Increase timeout for slower iOS devices
        // Enable legacy cookie handling for iOS Safari
        allowRedirectInIframe: false,
        // Add support for iOS Private Browsing mode
        loggerOptions: {
            logLevel: isIOSDevice() ? 'Warning' : 'Error',
            piiLoggingEnabled: false
        }
    }
};

// Development mode flag. Set to `true` only if you explicitly want the
// authentication bypass. For local live-auth testing we keep this false
// so MSAL runs normally even on localhost.
const DEV_MODE = false;

// Login request scopes
const loginRequest = {
    scopes: ['User.Read', 'Sites.ReadWrite.All']
};

/**
 * Build API scope for the function app (access_as_user) when possible.
 * Example: api://your-function-app.azurewebsites.net/<client-id>/access_as_user
 */
function buildApiScope(functionBaseUrl, clientId) {
    if (!functionBaseUrl || !clientId) return null;
    // Use application ID URI format recommended in docs: api://<host>/<clientId>
    try {
        const url = new URL(functionBaseUrl);
        const host = url.hostname;
        // Prefer the common application ID URI without host when possible
        // (apps often expose scopes as api://<clientId>/access_as_user).
        if (clientId) return `api://${clientId}/access_as_user`;
        return `api://${host}/${clientId}/access_as_user`;
    } catch (e) {
        // Fallback to client-only application ID URI
        return `api://${clientId}/access_as_user`;
    }
}

let msalInstance = null;
let currentUser = null;
let isTeamsContext = false;
let apiScopeValue = null;
let tokenRefreshTimer = null;
// Auth persistence helpers - keep minimal state for 24 hours as a fallback
const AUTH_PERSIST_MS = 24 * 60 * 60 * 1000;
const AUTH_COOKIE_NAME = 'teoc_auth_state_v1';
let msalEventCallbackId = null;

function publishDebugAuthState() {
    if (typeof window === 'undefined') {
        return;
    }
    window.__teocAuth = window.__teocAuth || {};
    window.__teocAuth.msalInstance = msalInstance;
    window.__teocAuth.currentUser = currentUser;
    window.__teocAuth.apiScope = apiScopeValue;
}

function persistAuthState() {
    try {
        localStorage.setItem('teoc_auth_ts', String(Date.now()));
        // Also write a cookie so iOS WebViews can check existence
        document.cookie = `${AUTH_COOKIE_NAME}=1; max-age=${Math.floor(AUTH_PERSIST_MS/1000)}; path=/`;
    } catch (e) {
        console.warn('[persistAuthState] failed to persist auth state:', e && e.message);
    }
}

function clearPersistedAuthState() {
    try { localStorage.removeItem('teoc_auth_ts'); } catch (e) {}
    try { document.cookie = `${AUTH_COOKIE_NAME}=; max-age=0; path=/`; } catch (e) {}
}

async function finalizeAuthenticatedState(accessToken) {
    updateAuthUI();
    publishDebugAuthState();
    try { persistAuthState(); } catch (e) {}
    setupTokenRefresh();
    if (accessToken) {
        try {
            setAPIToken(accessToken);
        } catch (e) {
            console.warn('Failed to cache API token after auth event:', e?.message || e);
        }
    }
}

function registerMsalEventListeners() {
    if (!msalInstance || !msal || typeof msal.EventType === 'undefined') {
        return;
    }
    if (msalEventCallbackId !== null) {
        return;
    }
    msalEventCallbackId = msalInstance.addEventCallback(async (event) => {
        if (!event) return;
        if (event.eventType === msal.EventType.LOGIN_SUCCESS) {
            const account = event?.payload?.account || (Array.isArray(event?.payload?.accounts) ? event.payload.accounts[0] : null);
            if (account) {
                currentUser = account;
                try { msalInstance.setActiveAccount(account); } catch (e) {}
                updateAuthUI();
            }
        } else if (event.eventType === msal.EventType.ACQUIRE_TOKEN_SUCCESS) {
            const account = event?.payload?.account || (Array.isArray(event?.payload?.accounts) ? event.payload.accounts[0] : null);
            if (account) {
                currentUser = account;
                try { msalInstance.setActiveAccount(account); } catch (e) {}
            }
            const token = event?.payload?.accessToken || null;
            if (token) {
                try {
                    await finalizeAuthenticatedState(token);
                } catch (err) {
                    console.error('Failed to finalize auth state from MSAL acquire token event:', err);
                }
            }
        } else if (event.eventType === msal.EventType.LOGIN_FAILURE || event.eventType === msal.EventType.ACQUIRE_TOKEN_FAILURE) {
            console.warn('[auth] MSAL event failure:', event.error?.message || event.error);
        }
    });
}

/**
 * Setup automatic token refresh before expiration
 * This is especially important for iOS where background tabs may not execute timers reliably
 */
function setupTokenRefresh() {
    // Clear any existing timer
    if (tokenRefreshTimer) {
        clearInterval(tokenRefreshTimer);
        tokenRefreshTimer = null;
    }
    
    // For iOS, check token validity more frequently (every 5 minutes)
    // For other browsers, check every 10 minutes
    const checkInterval = isIOSDevice() ? 5 * 60 * 1000 : 10 * 60 * 1000;
    
    tokenRefreshTimer = setInterval(async () => {
        try {
            if (msalInstance && currentUser) {
                // Try to refresh token silently
                const tokenRequest = {
                    account: currentUser,
                    scopes: apiScopeValue ? [apiScopeValue] : loginRequest.scopes
                };
                
                const response = await msalInstance.acquireTokenSilent(tokenRequest);
                if (response && response.accessToken) {
                    setAPIToken(response.accessToken);
                    console.log('Token refreshed successfully (auto-refresh)');
                }
            }
        } catch (error) {
            console.warn('Auto token refresh failed:', error.message);
            // Don't force re-authentication automatically, just log the error
        }
    }, checkInterval);
    
    console.log(`Token auto-refresh enabled (check interval: ${checkInterval / 1000 / 60} minutes)`);
}

/**
 * Stop automatic token refresh
 */
function stopTokenRefresh() {
    if (tokenRefreshTimer) {
        clearInterval(tokenRefreshTimer);
        tokenRefreshTimer = null;
        console.log('Token auto-refresh disabled');
    }
}

/**
 * Initialize authentication
 * @param {Object} config - Configuration object with clientId and tenantId
 */
// Add this function to handle Teams SSO authentication
async function initTeamsSSOAuth() {
    try {
        console.log('Attempting Teams SSO authentication...');
        
        // Request auth token from Teams
        const token = await microsoftTeams.authentication.getAuthToken({
            silent: false,
            failIfSilent: false
        });
        
        if (token) {
            console. log('✓ Teams SSO token received');
            
            // Decode the token to get user info
            const tokenParts = token.split('.');
            const payload = JSON.parse(atob(tokenParts[1]));
            
            currentUser = {
                username: payload.preferred_username || payload.upn,
                name: payload.name,
                email: payload.email || payload.preferred_username
            };
            
            // Set the token for API calls
            setAPIToken(token);
            updateAuthUI();
            publishDebugAuthState();
            
            return token;
        }
    } catch (error) {
        console.error('Teams SSO failed:', error);
        
        // If SSO fails, fall back to popup authentication
        return initTeamsPopupAuth();
    }
    
    return null;
}

// Update your initAuth function to prioritize Teams SSO
async function initAuth(config) {
    // Update MSAL config with provided values
    msalConfig.auth. clientId = config.entraClientId || config.clientId;
    msalConfig.auth.authority = `https://login.microsoftonline.com/${config.entraTenantId || config.tenantId}`;
    
    // Check if we have valid config
    if (!msalConfig. auth.clientId || !config.entraTenantId) {
        console.warn('⚠️ Entra ID not configured.  Running without authentication.');
        return null;
    }
    
    // Build API scope
    try {
        if (config.apiScope && typeof config.apiScope === 'string' && config.apiScope.length > 0) {
            if (!/api: \/\/localhost\//i.test(config.apiScope)) {
                apiScopeValue = config.apiScope;
                loginRequest.scopes = ['User.Read'];
                console.log('Using server-provided API scope for backend requests:', apiScopeValue);
            }
        } else {
            const apiScope = buildApiScope(config.functionBaseUrl || window.location.origin, msalConfig.auth.clientId);
            if (apiScope) {
                apiScopeValue = apiScope;
                loginRequest.scopes = ['User.Read'];
                console. log('API scope set for backend requests (built):', apiScopeValue);
            }
        }
    } catch (e) {
        // ignore failures building scope
    }
    publishDebugAuthState();

    // Check if running in Teams - PRIORITIZE TEAMS SSO
    if (window.microsoftTeams) {
        try {
            await window.microsoftTeams.app.initialize();
            const context = await window.microsoftTeams.app.getContext();
            isTeamsContext = true;
            console.log('Running in Teams context', context);
            
            // Use Teams SSO (not popup auth)
            return await initTeamsSSOAuth();
        } catch (err) {
            console.log('Not in Teams context, using browser auth');
        }
    }
    
    // Browser context - use MSAL
    return initBrowserAuth();
}

async function runInteractiveLogin(loginRequest) {
    if (!msalInstance) {
        throw new Error('MSAL instance not initialized');
    }
    console.log('Using MSAL redirect auth flow');
    try {
        await msalInstance.loginRedirect(loginRequest);
    } catch (redirectError) {
        if (redirectError?.errorCode === 'interaction_in_progress') {
            console.warn('Redirect already in progress; awaiting completion.');
            return;
        }
        throw redirectError;
    }
}

/**
 * Initialize authentication for browser context
 */
async function initBrowserAuth() {
    try {
        // Check if MSAL library is available
        if (typeof msal === 'undefined') {
            console.error('MSAL library not loaded. Authentication will not be available.');
            console.log('Check browser console for script loading errors.');
            showToast('Authentication is unavailable. Check your network connection.', 'error');
            return null;
        }
        
        msalInstance = new msal.PublicClientApplication(msalConfig);
        await msalInstance.initialize();
        publishDebugAuthState();
        registerMsalEventListeners();
        
        // Handle redirect response
        const response = await msalInstance.handleRedirectPromise();
        if (response) {
            console.log('handleRedirectPromise returned a response:', response && !!response.account);
            currentUser = response.account;
            try { msalInstance.setActiveAccount(response.account); } catch (e) {}
            await finalizeAuthenticatedState(response.accessToken);
            return response.accessToken;
        }
        
        // Check if user is already signed in
        const accounts = msalInstance.getAllAccounts();
        if (accounts.length > 0) {
            currentUser = accounts[0];
            try { msalInstance.setActiveAccount(currentUser); } catch (e) {}
            updateAuthUI();
            publishDebugAuthState();
            try { persistAuthState(); } catch (e) {}
            
            try {
                const tokenResponse = await msalInstance.acquireTokenSilent({
                    ...loginRequest,
                    account: currentUser
                });
                console.log('acquireTokenSilent succeeded for account:', currentUser && (currentUser.username || currentUser.homeAccountId));
                if (isIOSDevice()) {
                    console.log('iOS detected - token will auto-refresh to maintain session');
                }
                await finalizeAuthenticatedState(tokenResponse.accessToken);
                return tokenResponse.accessToken;
            } catch (error) {
                console.log('Silent token acquisition failed, will not force interactive login during init:', error && error.message);
                if (isIOSSafari() && error.errorCode === 'interaction_required') {
                    console.warn('iOS Safari: User interaction required. Please sign in again.');
                }
                return null;
            }
        }
        
        return null;
    } catch (error) {
        console.error('Auth initialization error:', error);
        
        // Provide iOS-specific error guidance
        if (isIOSDevice()) {
            console.error('iOS authentication error. Check Safari settings: Settings > Safari > Privacy & Security');
            showToast('Authentication failed. Please check Safari privacy settings.', 'error');
        } else {
            showToast('Authentication initialization failed', 'error');
        }
        
        return null;
    }
}

async function exchangeTeamsTokenForAPIToken(teamsToken) {
    try {
        // Call your backend to exchange the Teams token for an API token
        const response = await fetch('/api/auth/exchange', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${teamsToken}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            return data.accessToken;
        }
    } catch (error) {
        console.error('Token exchange failed:', error);
    }
    
    return teamsToken;
}
/**
 * Initialize authentication for Teams context
 */
async function initTeamsAuth(context) {
    try {
        // Try to get SSO token from Teams
        const token = await window.microsoftTeams.authentication.getAuthToken({
            resources: [msalConfig.auth.clientId],
            silent: false
        });
        
        if (token) {
            // Decode token to get user info (basic JWT decode)
            const tokenParts = token.split('.');
            const payload = JSON.parse(atob(tokenParts[1]));
            currentUser = {
                username: payload.preferred_username || payload.upn,
                name: payload.name
            };
            updateAuthUI();
            publishDebugAuthState();
            try { persistAuthState(); } catch (e) {}
            return token;
        }
    } catch (error) {
        console.error('Teams SSO failed:', error);
        // Fallback to popup authentication
        return initTeamsPopupAuth();
    }
    
    return null;
}

/**
 * Fallback authentication using Teams popup
 */
async function initTeamsPopupAuth() {
    try {
        const result = await new Promise((resolve, reject) => {
            window.microsoftTeams.authentication.authenticate({
                url: window.location.origin + '/web/auth-start.html',
                width: 600,
                height: 535
            }).then(result => {
                resolve(result);
            }).catch(error => {
                reject(error);
            });
        });
        
        if (result) {
            // Parse the authentication result
            currentUser = {
                username: result.username || result.upn,
                name: result.name
            };
            updateAuthUI();
            publishDebugAuthState();
            return result.accessToken;
        }
    } catch (error) {
        console.error('Teams popup auth failed:', error);
    }
    
    return null;
}

/**
 * Sign in user
 */
async function signIn() {
    if (DEV_MODE) {
        showToast('Already signed in (dev mode)', 'info');
        return;
    }
    
    if (isTeamsContext) {
        return initTeamsPopupAuth();
    }
    
    try {
        if (!msalInstance) {
            await initBrowserAuth();
            if (!msalInstance) {
                console.error('MSAL is not available; cannot perform login.');
                showToast('Authentication is unavailable.', 'error');
                return;
            }
        }

        const loginReq = {
            scopes: ['User.Read'],
            redirectStartPage: window.location.href
        };
        if (apiScopeValue) {
            loginReq.extraScopesToConsent = [apiScopeValue];
        }

        try { document.getElementById('login-btn').disabled = true; } catch (e) {}
        await runInteractiveLogin(loginReq);
        try { document.getElementById('login-btn').disabled = false; } catch (e) {}
    } catch (error) {
        console.error('Sign in error:', error);
        showToast('Sign in failed: ' + (error && error.message ? error.message : 'Unknown error'), 'error');
        try { document.getElementById('login-btn').disabled = false; } catch (e) {}
    }
}

/**
 * Sign out user
 */
async function signOut() {
    // Stop automatic token refresh
    stopTokenRefresh();
    
    if (isTeamsContext) {
        // In Teams, just clear local state
        currentUser = null;
        updateAuthUI();
        publishDebugAuthState();
        showToast('Signed out successfully', 'success');
        return;
    }
    
    try {
        if (msalInstance && currentUser) {
            await msalInstance.logoutRedirect({
                account: currentUser
            });
        }
    } catch (error) {
        console.error('Sign out error:', error);
        showToast('Sign out failed: ' + error.message, 'error');
    }
    // Clear persisted auth state
    try { clearPersistedAuthState(); } catch (e) {}
    publishDebugAuthState();
}

/**
 * Get current access token
 */
async function getAccessToken() {
    if (isTeamsContext) {
        return initTeamsAuth();
    }
    
    if (!msalInstance || !currentUser) {
        return null;
    }
    
    try {
        const tokenRequest = {
            account: currentUser,
            scopes: apiScopeValue ? [apiScopeValue] : loginRequest.scopes
        };
        const response = await msalInstance.acquireTokenSilent(tokenRequest);
        return response.accessToken;
    } catch (error) {
        console.error('Token acquisition error:', error);
        // Do not force an interactive redirect here. Return null and let
        // the caller decide whether to prompt the user. Forcing a
        // redirect here can create unexpected navigation and race
        // conditions during initialization.
        return null;
    }
    
    return null;
}

/**
 * Update authentication UI
 */
function updateAuthUI() {
    const userInfo = document.getElementById('user-info');
    const signInContainer = document.getElementById('sign-in-container');
    const userBtn = document.getElementById('user-btn');
    const userImage = document.getElementById('user-image');
    const userMenuName = document.getElementById('user-menu-name');
    
    if (currentUser) {
        // Prefer full name, fallback to username
        const name = currentUser.name || currentUser.username || 'User';
        // Fill image or initials
        if (userImage) {
            try {
                if (currentUser.imageUrl) {
                    userImage.innerHTML = `<img src="${currentUser.imageUrl}" alt="${name}">`;
                } else {
                    const initials = name.split(' ').map(n => n[0]).slice(0,2).join('').toUpperCase();
                    userImage.textContent = initials;
                }
            } catch (e) { /* ignore */ }
        }

        if (userMenuName) {
            try { userMenuName.textContent = name; } catch (e) { /* ignore */ }
        }

        if (userInfo) {
            try { userInfo.style.removeProperty('display'); } catch (e) {}
            userInfo.style.display = 'flex';
        }
        // Defensive: ensure user menu items are visible (help debug styling issues)
        try {
            const userMenu = document.getElementById('user-menu');
            if (userMenu) {
                const items = Array.from(userMenu.querySelectorAll('.user-menu-item'));
                console.log('[auth] user-menu item count:', items.length, items.map(i => i.id || i.textContent.trim()));
                items.forEach(it => {
                    try {
                        it.style.removeProperty('display');
                        it.style.display = 'block';
                        it.style.visibility = 'visible';
                        if (it.hasAttribute('hidden')) it.removeAttribute('hidden');
                    } catch (e) { /* ignore per-item errors */ }
                });
                // Also ensure menu container is visible
                try { userMenu.style.removeProperty('display'); } catch (e) {}
            }
        } catch (e) { console.warn('[auth] failed to force menu visibility', e); }
        if (signInContainer) {
            try { signInContainer.style.removeProperty('display'); } catch (e) {}
            signInContainer.style.display = 'none';
        }
    } else {
        if (userInfo) {
            try { userInfo.style.removeProperty('display'); } catch (e) {}
            userInfo.style.display = 'none';
        }
        if (signInContainer) {
            try { signInContainer.style.removeProperty('display'); } catch (e) {}
            signInContainer.style.display = 'block';
        }
    }
}

/**
 * Check if user is authenticated
 */
function isAuthenticated() {
    return currentUser !== null;
}

/**
 * Get current user info
 */
function getCurrentUser() {
    return currentUser;
}

/**
 * Check if running in Teams
 */
function isInTeams() {
    return isTeamsContext;
}

/**
 * Handle page visibility changes to refresh tokens on iOS
 * iOS Safari may suspend background tabs, so we refresh when user returns
 */
if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', async () => {
        // Only handle visibility change for iOS devices
        if (!isIOSDevice() || !msalInstance || !currentUser) {
            return;
        }
        
        if (document.visibilityState === 'visible') {
            console.log('iOS: Page became visible, checking token validity...');
            
            try {
                // Try to get a fresh token silently
                const tokenRequest = {
                    account: currentUser,
                    scopes: apiScopeValue ? [apiScopeValue] : loginRequest.scopes,
                    forceRefresh: false // Use cache if still valid
                };
                
                const response = await msalInstance.acquireTokenSilent(tokenRequest);
                if (response && response.accessToken) {
                    setAPIToken(response.accessToken);
                    console.log('iOS: Token refreshed after page became visible');
                }
            } catch (error) {
                // If token refresh fails, user may need to sign in again
                console.warn('iOS: Failed to refresh token on visibility change:', error.message);
                
                // Check if this is an interaction_required error
                if (error.errorCode === 'interaction_required' || 
                    error.errorCode === 'login_required' ||
                    error.errorCode === 'consent_required') {
                    console.log('iOS: User interaction required - session may have expired');
                    // Don't automatically prompt - let user click sign in if needed
                    showToast('Please sign in again to continue', 'info');
                }
            }
        }
    });
}