/**
 * Map module for Mapbox GL JS integration
 */

let map = null;
let currentMarker = null;
let geocoder = null;
let mapboxToken = '';
let autoPanEnabled = true;
// Auto-pan scheduling and throttling
let _autoPanTimeoutId = null;
let _lastAutoPanAt = 0;
const AUTO_PAN_COOLDOWN_MS = 15000; // 15s cooldown between auto-pans
const ITEMS_SOURCE_ID = 'items-source';
const CLUSTERS_LAYER = 'clusters';
const CLUSTER_COUNT_LAYER = 'cluster-count';
const UNCLUSTERED_LAYER = 'unclustered-point';
const INFERRED_STROKE_COLOR = '#a855f7';
let lastFeatures = [];
let clusterSetupPending = false;
// Default style and fallback Mapbox token
// Use Mapbox Streets as the default style per request
const CUSTOM_STYLE = 'mapbox://styles/mapbox/streets-v12';
const DEFAULT_MAPBOX_TOKEN = 'pk.eyJ1IjoicmljaGFyZGJ0IiwiYSI6ImNtMWxkdDV3MzA3djgyaXB2OXJjM2hzaHoifQ.SJNYB6CFHCzfqZOKtdiUPg';

/**
 * Extract coordinates from an item record. Supports multiple shapes used
 * by the backend: `Location.coordinates`, `GeoLoc`, or flat `latitude`/`Longitude` fields.
 * Returns { lat, lng } or null when coordinates are not available.
 */
function getItemCoordinates(item) {
    if (!item) return null;

    // 1) Location.coordinates (object with latitude/longitude)
    try {
        const loc = item.Location && item.Location.coordinates;
        if (loc && loc.latitude != null && loc.longitude != null) {
            const latNum = Number(loc.latitude);
            const lngNum = Number(loc.longitude);
            if (Number.isFinite(latNum) && Number.isFinite(lngNum)) {
                return { lat: latNum, lng: lngNum };
            }
        }
    } catch (e) {}

    // 2) GeoLoc object
    try {
        const g = item.GeoLoc;
        if (g && g.latitude != null && g.longitude != null) {
            const latNum = Number(g.latitude);
            const lngNum = Number(g.longitude);
            if (Number.isFinite(latNum) && Number.isFinite(lngNum)) {
                return { lat: latNum, lng: lngNum };
            }
        }
    } catch (e) {}

    // 3) Top-level latitude/Longitude or Latitude/longitude fields
    try {
        const lat = item.latitude || item.Latitude || item.lat || item.Lat;
        const lng = item.longitude || item.Longitude || item.lng || item.Lng;
        const latNum = lat !== undefined && lat !== null ? Number(lat) : NaN;
        const lngNum = lng !== undefined && lng !== null ? Number(lng) : NaN;
        if (Number.isFinite(latNum) && Number.isFinite(lngNum)) {
            return { lat: latNum, lng: lngNum };
        }
    } catch (e) {}

    return null;
}

/**
 * Initialize the map
 * @param {string} token - Mapbox access token
 * @param {Object} options - Map options
 */
function initMap(token, options = {}) {
    // If no token passed, fall back to bundled default token
    if (!token) {
        console.warn('Mapbox token not provided to initMap; using built-in default token');
        token = DEFAULT_MAPBOX_TOKEN;
    }

    // Check if mapboxgl is available
    if (typeof mapboxgl === 'undefined') {
        console.error('Mapbox GL JS library not loaded');
        throw new Error('Mapbox GL JS library failed to load');
    }

    mapboxToken = token;
    mapboxgl.accessToken = token || DEFAULT_MAPBOX_TOKEN;

    console.log('🗺️ Initializing map with Mapbox GL JS...');

    const defaultOptions = {
        container: 'map',
        // Use the custom style by default but allow override via options
        style: options.style || CUSTOM_STYLE,
        center: [133.7751, -25.2744], // Center of Australia
        zoom: 4
    };

    try {
        map = new mapboxgl.Map({
            ...defaultOptions,
            ...options
        });

        // Add native Mapbox controls (left side)
        map.addControl(new mapboxgl.NavigationControl(), 'top-left');
        map.addControl(new mapboxgl.FullscreenControl(), 'top-left');
        map.addControl(new mapboxgl.ScaleControl({ maxWidth: 100, unit: 'metric' }), 'bottom-left');

        // Add geolocate control
        const geolocate = new mapboxgl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            trackUserLocation: true,
            showUserHeading: true
        });
        map.addControl(geolocate, 'top-left');

        // Add style control into the native controls area to make it feel native
        // We place it on the left to integrate with Mapbox native controls for a cohesive UX
        map.addControl(new StyleControl(), 'top-left');

        // Right-side helper controls (auto-pan and 3D toggle) will be rendered into
        // a compact container that visually matches native controls and sits above the side panel
        map.addControl(new RightControls(), 'top-right');

        // Initialize geocoder for location search
        initGeocoder();

        // Add click handler for placing markers
        map.on('click', handleMapClick);

        // Auto-pan toggle is provided in the right-side controls

        // Wait for map to load before enabling interactions and add 3D/terrain
        map.on('load', () => {
            console.log('✓ Map loaded successfully');
            // Ensure cluster source/layers exist for the current style
            ensureClusterSourceAndLayers();
            // Ensure terrain and 3D buildings are enabled
            ensureTerrainAnd3DBuildings(map);
        });

        // When style changes, re-add our dynamic sources/layers and 3D/terrain
        map.on('style.load', () => {
            console.log('[map] style.load event - reapplying custom layers/sources');
            ensureClusterSourceAndLayers();
            ensureTerrainAnd3DBuildings(map);
        });

        // Handle map errors
        map.on('error', (e) => {
            console.error('Map error:', e.error);
        });

        console.log('✓ Map initialization complete');

        return map;
    } catch (error) {
        console.error('Failed to create map:', error);
        throw error;
    }
}

/**
 * Custom control to switch map styles (native Mapbox control)
 */
function StyleControl() {}
StyleControl.prototype.onAdd = function(mapInst) {
    this._map = mapInst;
    const container = document.createElement('div');
    container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group style-control';

    // Render a compact segmented button group (visually matches Mapbox native controls)
    const btnGroup = document.createElement('div');
    btnGroup.className = 'style-btn-group';

    const styles = [
        { id: 'streets', name: 'Streets', url: 'mapbox://styles/mapbox/streets-v12', title: 'Streets (default)' },
        { id: 'satellite', name: 'Satellite', url: 'mapbox://styles/mapbox/satellite-v9', title: 'Satellite imagery' },
        { id: 'dark', name: 'Dark', url: 'mapbox://styles/mapbox/dark-v11', title: 'Dark mode' }
    ];

    // Create a button for each style using icons (sun = streets, globe = satellite, moon = dark)
    styles.forEach(s => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'style-btn';
        btn.setAttribute('data-style-url', s.url);
        btn.title = s.title || s.name;
        btn.setAttribute('aria-pressed', s.id === 'streets' ? 'true' : 'false');

        // Inline SVG icons
        let svg = '';
        if (s.id === 'streets') {
            // Sun icon for light/streets
            svg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="4" fill="#f59e0b"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" stroke="#f59e0b" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        } else if (s.id === 'satellite') {
            // Globe icon for satellite
            svg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a10 10 0 100 20 10 10 0 000-20z" stroke="#374151" stroke-width="1.2" fill="#10b981" opacity="0.95"/><path d="M2 12h20M12 2c2.5 3 2.5 7 0 10M12 22c-2.5-3-2.5-7 0-10" stroke="#ffffff" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
        } else if (s.id === 'dark') {
            // Moon icon for dark
            svg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" fill="#111827"/></svg>`;
        }

        // Put icon inside a visually-hidden text container for screen readers
        const iconWrap = document.createElement('span');
        iconWrap.className = 'style-btn-icon';
        iconWrap.innerHTML = svg;

        // Accessible label for screen readers
        const sr = document.createElement('span');
        sr.className = 'sr-only';
        sr.textContent = s.name;

        btn.appendChild(iconWrap);
        btn.appendChild(sr);

        // Mark Streets as active by default
        if (s.id === 'streets') btn.classList.add('active');

        btn.addEventListener('click', (ev) => {
            const styleUrl = ev.currentTarget.getAttribute('data-style-url');
            try {
                const siblings = btnGroup.querySelectorAll('.style-btn');
                siblings.forEach(x => {
                    x.classList.remove('active');
                    x.setAttribute('aria-pressed', 'false');
                });
                ev.currentTarget.classList.add('active');
                ev.currentTarget.setAttribute('aria-pressed', 'true');
                this._map.setStyle(styleUrl);
            } catch (e) {
                console.error('Failed to set style:', e);
            }
        });

        btnGroup.appendChild(btn);
    });

    container.appendChild(btnGroup);
    this._container = container;
    return container;
};
StyleControl.prototype.onRemove = function() {
    if (this._container && this._container.parentNode) this._container.parentNode.removeChild(this._container);
    this._map = undefined;
};

/**
 * Control to toggle label/POI/3D building layers
 */
function LayerToggleControl() {}
LayerToggleControl.prototype.onAdd = function(mapInst) {
    this._map = mapInst;
    const container = document.createElement('div');
    container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group layer-toggle-control';

    const btn3d = document.createElement('button');
    btn3d.type = 'button';
    btn3d.title = 'Toggle 3D Buildings';
    btn3d.textContent = '3D';
    btn3d.addEventListener('click', () => {
        // Toggle 3d-buildings layer visibility
        const lyr = this._map.getLayer('3d-buildings');
        if (!lyr) {
            ensureTerrainAnd3DBuildings(this._map);
            return;
        }
        const vis = this._map.getLayoutProperty('3d-buildings', 'visibility');
        this._map.setLayoutProperty('3d-buildings', 'visibility', vis === 'none' ? 'visible' : 'none');
    });

    const btnLabels = document.createElement('button');
    btnLabels.type = 'button';
    btnLabels.title = 'Toggle Labels/POI';
    btnLabels.textContent = 'Labels';
    btnLabels.addEventListener('click', () => {
        // Toggle visibility for all symbol layers that look like labels/poi
        const layers = this._map.getStyle().layers || [];
        layers.forEach(l => {
            try {
                if (l.type === 'symbol' && /label|place|poi|place_label/i.test(l.id)) {
                    const vis = this._map.getLayoutProperty(l.id, 'visibility') || 'visible';
                    this._map.setLayoutProperty(l.id, 'visibility', vis === 'none' ? 'visible' : 'none');
                }
            } catch (e) {}
        });
    });

    container.appendChild(btn3d);
    container.appendChild(btnLabels);
    this._container = container;
    return container;
};
LayerToggleControl.prototype.onRemove = function() {
    if (this._container && this._container.parentNode) this._container.parentNode.removeChild(this._container);
    this._map = undefined;
};

/**
 * Right-side compact controls to match Mapbox native control styling.
 * Includes Auto-pan toggle and 3D buildings toggle.
 */
function RightControls() {}
RightControls.prototype.onAdd = function(mapInst) {
    this._map = mapInst;
    const container = document.createElement('div');
    container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group right-controls';

    // Auto-pan toggle
    const autoBtn = document.createElement('button');
    autoBtn.type = 'button';
    autoBtn.title = 'Toggle auto pan/zoom on refresh';
    autoBtn.setAttribute('aria-label', 'Toggle auto pan');
    autoBtn.className = 'map-ctrl-btn auto-pan-btn';

    // SVG icons: compass for on, slashed compass for off
    const svgOn = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm3.5 6.5l-5 2.5 2.5-5 2.5 2.5z" fill="#111827"/></svg>`;
    const svgOff = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm5 15L7 7" stroke="#111827" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

    // Initialize state from localStorage (default true)
    autoPanEnabled = localStorage.getItem('autoPanEnabled') !== 'false';
    autoBtn.innerHTML = autoPanEnabled ? svgOn : svgOff;
    autoBtn.classList.toggle('active', autoPanEnabled === true);
    autoBtn.setAttribute('aria-pressed', autoPanEnabled ? 'true' : 'false');
    autoBtn.addEventListener('click', () => {
        autoPanEnabled = !autoPanEnabled;
        localStorage.setItem('autoPanEnabled', autoPanEnabled ? 'true' : 'false');
        autoBtn.innerHTML = autoPanEnabled ? svgOn : svgOff;
        autoBtn.classList.toggle('active', autoPanEnabled === true);
        // Accessibility state
        autoBtn.setAttribute('aria-pressed', autoPanEnabled ? 'true' : 'false');
        // If user turned off auto-pan, cancel any scheduled pan
        if (!autoPanEnabled && _autoPanTimeoutId) {
            clearTimeout(_autoPanTimeoutId);
            _autoPanTimeoutId = null;
        }
    });

    // 3D toggle
    const btn3d = document.createElement('button');
    btn3d.type = 'button';
    btn3d.title = 'Toggle 3D Buildings';
    btn3d.className = 'map-ctrl-btn toggle-3d-btn';
    btn3d.textContent = '3D';
    btn3d.addEventListener('click', () => {
        const lyr = this._map.getLayer('3d-buildings');
        if (!lyr) {
            ensureTerrainAnd3DBuildings(this._map);
            btn3d.classList.add('active');
            return;
        }
        const vis = this._map.getLayoutProperty('3d-buildings', 'visibility');
        const visible = vis !== 'none';
        this._map.setLayoutProperty('3d-buildings', 'visibility', visible ? 'none' : 'visible');
        btn3d.classList.toggle('active', !visible);
    });

    container.appendChild(autoBtn);
    container.appendChild(btn3d);
    this._container = container;
    return container;
};

RightControls.prototype.onRemove = function() {
    if (this._container && this._container.parentNode) this._container.parentNode.removeChild(this._container);
    this._map = undefined;
};

/**
 * Ensure terrain and 3D buildings exist on the map style
 */
function ensureTerrainAnd3DBuildings(mapInst) {
    if (!mapInst) return;
    try {
        const style = mapInst.getStyle();
        // Add raster-dem source for terrain if not present
        if (!mapInst.getSource('mapbox-dem')) {
            mapInst.addSource('mapbox-dem', {
                type: 'raster-dem',
                url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
                tileSize: 512
            });
        }

        // Set terrain with modest exaggeration
        try { mapInst.setTerrain({ source: 'mapbox-dem', exaggeration: 1.0 }); } catch (e) {}

        // Add sky layer for better visual depth if not present
        if (!mapInst.getLayer('sky')) {
            mapInst.addLayer({
                id: 'sky',
                type: 'sky',
                paint: {
                    'sky-type': 'atmosphere',
                    'sky-atmosphere-sun': [0.0, 0.0],
                    'sky-atmosphere-sun-intensity': 15
                }
            });
        }

        // Add 3D buildings layer if not present
        if (!mapInst.getLayer('3d-buildings')) {
            // Attempt to add based on composite source used by Mapbox styles
            mapInst.addLayer({
                id: '3d-buildings',
                source: 'composite',
                'source-layer': 'building',
                filter: ['==', ['get', 'extrude'], 'true'],
                type: 'fill-extrusion',
                minzoom: 15,
                paint: {
                    'fill-extrusion-color': '#aaa',
                    'fill-extrusion-height': ['get', 'height'],
                    'fill-extrusion-base': ['get', 'min_height'],
                    'fill-extrusion-opacity': 0.6
                }
            }, 'waterway-shadow');
        }
    } catch (error) {
        console.warn('[ensureTerrainAnd3DBuildings] failed:', error && error.message);
    }
}

// auto-pan toggle is now embedded in RightControls

/**
 * Ensure the Mapbox GeoJSON source and layers for clustering are added.
 * Called when the map is initialized or when first items are loaded.
 */
function ensureClusterSourceAndLayers() {
    if (!map) return;

    if (typeof map.isStyleLoaded === 'function' && !map.isStyleLoaded()) {
        if (!clusterSetupPending) {
            clusterSetupPending = true;
            map.once('styledata', () => {
                clusterSetupPending = false;
                ensureClusterSourceAndLayers();
            });
        }
        return;
    }

    if (!map.getSource(ITEMS_SOURCE_ID)) {
        // Use lastFeatures to rehydrate the source when available (prevents markers disappearing after style change)
        const initialData = {
            type: 'FeatureCollection',
            features: Array.isArray(lastFeatures) && lastFeatures.length ? lastFeatures : []
        };

        map.addSource(ITEMS_SOURCE_ID, {
            type: 'geojson',
            data: initialData,
            cluster: true,
            clusterMaxZoom: 14, // Max zoom to cluster points on
            clusterRadius: 50 // pixels
        });

        // Cluster circles
        map.addLayer({
            id: CLUSTERS_LAYER,
            type: 'circle',
            source: ITEMS_SOURCE_ID,
            filter: ['has', 'point_count'],
            paint: {
                'circle-color': '#6b7280',
                'circle-radius': ['step', ['get', 'point_count'], 20, 10, 26, 50, 32],
                'circle-stroke-color': '#ffffff',
                'circle-stroke-width': 2,
                'circle-opacity': 0.85
            }
        });

        // Cluster count labels
        map.addLayer({
            id: CLUSTER_COUNT_LAYER,
            type: 'symbol',
            source: ITEMS_SOURCE_ID,
            filter: ['has', 'point_count'],
            layout: {
                'text-field': '{point_count_abbreviated}',
                'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
                'text-size': 12
            },
            paint: {
                'text-color': '#ffffff'
            }
        });

        // Unclustered points layer
        map.addLayer({
            id: UNCLUSTERED_LAYER,
            type: 'circle',
            source: ITEMS_SOURCE_ID,
            filter: ['!', ['has', 'point_count']],
            paint: {
                'circle-color': ['get', 'fillColor'],
                'circle-radius': [
                    'case',
                    ['==', ['get', 'isInferred'], true],
                    13,
                    12
                ],
                'circle-stroke-width': [
                    'case',
                    ['==', ['get', 'isInferred'], true],
                    4,
                    3
                ],
                'circle-stroke-color': [
                    'case',
                    ['==', ['get', 'isInferred'], true],
                    INFERRED_STROKE_COLOR,
                    ['get', 'strokeColor']
                ],
                'circle-opacity': [
                    'case',
                    ['==', ['get', 'isInferred'], true],
                    0.9,
                    0.95
                ]
            }
        });

        // Click cluster to zoom in / expand
        map.on('click', CLUSTERS_LAYER, (e) => {
            const features = map.queryRenderedFeatures(e.point, { layers: [CLUSTERS_LAYER] });
            const clusterId = features[0].properties.cluster_id;
            map.getSource(ITEMS_SOURCE_ID).getClusterExpansionZoom(clusterId, (err, zoom) => {
                if (err) return;
                map.easeTo({ center: features[0].geometry.coordinates, zoom });
            });
        });

        // Click unclustered point to show popup and allow edit
        map.on('click', UNCLUSTERED_LAYER, (e) => {
            const feature = e.features[0];
            const props = feature.properties || {};
            const item = props._rawItem ? JSON.parse(props._rawItem) : props;
            const coordinates = feature.geometry.coordinates.slice();
            const html = createPopupHTML(item);
            new mapboxgl.Popup({ offset: 25, closeButton: true })
                .setLngLat(coordinates)
                .setHTML(html)
                .addTo(map);
        });

        // Change cursor over clusters/points
        map.on('mouseenter', CLUSTERS_LAYER, () => map.getCanvas().style.cursor = 'pointer');
        map.on('mouseleave', CLUSTERS_LAYER, () => map.getCanvas().style.cursor = '');
        map.on('mouseenter', UNCLUSTERED_LAYER, () => map.getCanvas().style.cursor = 'pointer');
        map.on('mouseleave', UNCLUSTERED_LAYER, () => map.getCanvas().style.cursor = '');
    }
    else {
        // If source already exists (for example after style reload), rehydrate it with the latest features
        try {
            const src = map.getSource(ITEMS_SOURCE_ID);
            if (src && typeof src.setData === 'function') {
                const data = { type: 'FeatureCollection', features: Array.isArray(lastFeatures) ? lastFeatures : [] };
                src.setData(data);
            }
        } catch (e) {
            // ignore errors from setData during early style load
        }
    }
}

/**
 * Initialize the geocoder control
 */
function initGeocoder() {
    // Prevent duplicate initialization
    if (geocoder) {
        console.log('Geocoder already initialized, skipping');
        return;
    }
    
    // Clear any existing geocoder elements from the container
    const geocoderContainer = document.getElementById('geocoder-container');
    if (geocoderContainer) {
        geocoderContainer.innerHTML = '';
    }
    
    geocoder = new MapboxGeocoder({
        accessToken: mapboxToken,
        mapboxgl: mapboxgl,
        marker: false,
        placeholder: 'Search for a location...',
        proximity: {
            longitude: -98.5795,
            latitude: 39.8283
        }
    });
    
    // Add geocoder to the container in the side panel
    if (geocoderContainer) {
        geocoderContainer.appendChild(geocoder.onAdd(map));
    }
    
    // Handle geocoder result
    geocoder.on('result', (e) => {
        const coords = e.result.geometry.coordinates;
        const placeName = e.result.place_name;
        // Save last geocoder result for form use
        try { window.lastGeocoderResult = e.result; } catch (ex) { /* ignore */ }

        // Update current marker position
        setCurrentMarkerPosition(coords[1], coords[0]);
        
        // Center map on location
        map.flyTo({
            center: coords,
            zoom: 14
        });
    });
}

/**
 * Handle map click events
 * @param {Object} e - Map click event
 */
function handleMapClick(e) {
    const panel = document.getElementById('side-panel');
    
    // If panel is open, update marker position
    if (panel.classList.contains('open')) {
        const { lng, lat } = e.lngLat;
        setCurrentMarkerPosition(lat, lng);
        return;
    }
    
    // Check if click is on a marker/cluster (ignore those clicks)
    const features = map.queryRenderedFeatures(e.point, {
        layers: [CLUSTERS_LAYER, UNCLUSTERED_LAYER]
    });
    
    if (features.length > 0) {
        // Clicked on a marker or cluster, let the layer-specific handler deal with it
        return;
    }
    
    // Show location info box for map clicks (not on markers)
    const { lng, lat } = e.lngLat;
    showLocationInfoBox(lat, lng);
}

/**
 * Show location information box with coordinates and reverse geocoded address
 * @param {number} lat - Latitude
 * @param {number} lng - Longitude
 */
function showLocationInfoBox(lat, lng) {
    const box = document.getElementById('location-info-box');
    const latEl = document.getElementById('location-lat');
    const lngEl = document.getElementById('location-lng');
    const addressEl = document.getElementById('location-address');
    
    if (!box || !latEl || !lngEl || !addressEl) return;
    
    // Update coordinates
    latEl.textContent = lat.toFixed(6);
    lngEl.textContent = lng.toFixed(6);
    
    // Show loading state for address
    addressEl.innerHTML = '<span class="address-loading">Loading address...</span>';
    
    // Show the box
    box.style.display = 'block';
    
    // Store current coordinates for "Create Item Here" button
    box.dataset.lat = lat;
    box.dataset.lng = lng;
    
    // Reverse geocode the address
    reverseGeocodeLocation(lng, lat, addressEl);
}

/**
 * Reverse geocode a location using Mapbox API
 * @param {number} lng - Longitude
 * @param {number} lat - Latitude
 * @param {HTMLElement} addressEl - Element to display the address
 */
async function reverseGeocodeLocation(lng, lat, addressEl) {
    try {
        const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${mapboxToken}`;
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('Geocoding request failed');
        }
        
        const data = await response.json();
        
        if (data.features && data.features.length > 0) {
            const place = data.features[0];
            const placeName = place.place_name || 'Address not found';
            addressEl.innerHTML = `<span>${placeName}</span>`;
            
            // Store the geocoded result for use when creating item
            const box = document.getElementById('location-info-box');
            if (box) {
                box.dataset.placeName = placeName;
                box.dataset.geocoderResult = JSON.stringify(place);
            }
        } else {
            addressEl.innerHTML = '<span class="address-error">Address not available</span>';
        }
    } catch (error) {
        console.error('Reverse geocoding failed:', error);
        addressEl.innerHTML = '<span class="address-error">Unable to load address</span>';
    }
}

/**
 * Hide the location info box
 */
function hideLocationInfoBox() {
    const box = document.getElementById('location-info-box');
    if (box) {
        box.style.display = 'none';
    }
}

/**
 * Set position of current marker (for new item)
 * @param {number} lat - Latitude
 * @param {number} lng - Longitude
 */
function setCurrentMarkerPosition(lat, lng) {
    // Update form fields
    document.getElementById('latitude').value = lat.toFixed(6);
    document.getElementById('longitude').value = lng.toFixed(6);
    document.getElementById('latitude-display').textContent = lat.toFixed(6);
    document.getElementById('longitude-display').textContent = lng.toFixed(6);
    
    // Remove existing current marker
    if (currentMarker) {
        currentMarker.remove();
    }
    
    // Create new marker
    const el = createMarkerElement({
        ImmediateNeedsRequired: false,
        Status: 'New'
    }, true);
    
    currentMarker = new mapboxgl.Marker({
        element: el,
        draggable: true
    })
        .setLngLat([lng, lat])
        .addTo(map);
    
    // Handle marker drag
    currentMarker.on('dragend', () => {
        const lngLat = currentMarker.getLngLat();
        setCurrentMarkerPosition(lngLat.lat, lngLat.lng);
    });
}

/**
 * Clear current marker
 */
function clearCurrentMarker() {
    if (currentMarker) {
        currentMarker.remove();
        currentMarker = null;
    }
    
    // Clear form fields
    document.getElementById('latitude').value = '';
    document.getElementById('longitude').value = '';
    document.getElementById('latitude-display').textContent = '--';
    document.getElementById('longitude-display').textContent = '--';
}

/**
 * Create marker element with custom styling
 * @param {Object} item - Item data
 * @param {boolean} isNew - Whether this is a new item being created
 * @returns {HTMLElement} Marker element
 */
function createMarkerElement(item, isNew = false) {
    const el = document.createElement('div');
    el.className = 'custom-marker';
    // Determine colors based on Priority and Status
    const priority = (item.Priority || (item.ImmediateNeedsRequired ? 'High' : 'Medium')) || 'Medium';
    // Determine CSS classes for marker core (priority) and ring (status)
    const markerCls = (() => {
        const p = String(priority || '').toLowerCase();
        if (p === 'high') return 'marker-core marker-high';
        if (p === 'low') return 'marker-core marker-low';
        return 'marker-core marker-medium';
    })();

    const status = typeof item.Status === 'object' ? item.Status.Value : (item.Status || 'New');
    const ringCls = (() => {
        const s = String(status || '').toLowerCase();
        if (s === 'completed') return 'marker-ring ring-completed';
        if (s === 'in progress' || s === 'inprogress') return 'marker-ring ring-inprogress';
        if (s === 'hold') return 'marker-ring ring-hold';
        if (s === 'pending') return 'marker-ring ring-pending';
        return 'marker-ring ring-low';
    })();

    // Build DOM structure: ring behind, core in front, optional '+' for new items
    const wrapper = document.createElement('div');
    wrapper.className = 'legend-marker';
    
    // Add subtle class for completed items to make them less prominent
    if (String(status || '').toLowerCase() === 'completed') {
        wrapper.classList.add('marker-completed-subtle');
    }

    const ring = document.createElement('span');
    ring.className = ringCls;

    const core = document.createElement('span');
    // markerCls contains classes for priority cores like 'marker-core marker-high'
    core.className = markerCls;
    if (isNew) {
        core.innerHTML = '<span style="color: white; font-size: 16px; font-weight: 700;">+</span>';
    }

    const countEl = document.createElement('span');
    countEl.className = 'marker-count';
    // hidden by default on map markers (legend shows counts)
    countEl.style.display = 'none';

    wrapper.appendChild(ring);
    wrapper.appendChild(core);
    wrapper.appendChild(countEl);

    // Hover effect on core
    wrapper.addEventListener('mouseenter', () => { core.style.transform = 'scale(1.2)'; });
    wrapper.addEventListener('mouseleave', () => { core.style.transform = 'scale(1)'; });

    el.appendChild(wrapper);
    return el;
}

/**
 * Add or update item markers on the map
 * @param {Array} items - Array of items to display
 */
function updateMapMarkers(items) {
    ensureClusterSourceAndLayers();

    const features = items.map(item => {
        const coords = getItemCoordinates(item);
        if (!coords) return null;
        const fillColor = determineFillColor(item);
        const strokeColor = determineStrokeColor(item);
        const isInferred = Boolean(item._locationInferred);
        return {
            type: 'Feature',
            geometry: {
                type: 'Point',
                coordinates: [Number(coords.lng), Number(coords.lat)]
            },
            properties: {
                id: item.Id || item.id,
                title: item.Title || '',
                _rawItem: JSON.stringify(item),
                fillColor,
                strokeColor,
                isInferred
            }
        };
    }).filter(Boolean);

    const geojson = {
        type: 'FeatureCollection',
        features
    };

    const src = map.getSource(ITEMS_SOURCE_ID);
    if (src) {
        src.setData(geojson);
    }

    // store last features for fitMapToMarkers
    lastFeatures = features;

    // Auto-pan if enabled, but throttle and debounce to avoid aggressive frequent pans
    if (features.length > 0 && autoPanEnabled) {
        const now = Date.now();
        const since = now - _lastAutoPanAt;

        // If we're within the cooldown, skip scheduling
        if (since < AUTO_PAN_COOLDOWN_MS) {
            return;
        }

        // Debounce multiple rapid updates by scheduling a short delayed pan
        if (_autoPanTimeoutId) {
            clearTimeout(_autoPanTimeoutId);
            _autoPanTimeoutId = null;
        }

        _autoPanTimeoutId = setTimeout(() => {
            _autoPanTimeoutId = null;
            // Respect the latest user preference at execution time
            if (!autoPanEnabled) return;
            try {
                fitMapToMarkers();
                _lastAutoPanAt = Date.now();
            } catch (e) {
                console.warn('[auto-pan] failed to fit bounds:', e && e.message);
            }
        }, 350);
    }
}

/**
 * Create or update a normal marker for a single item without replacing DOM element
 */
function upsertMarker(id, item, lat, lng) {
    // deprecated in favor of Mapbox clustering; no-op
}

/**
 * Create or update a cluster marker that shows a count badge
 */
function upsertClusterMarker(clusterId, ids, pseudoItem, lat, lng) {
    // deprecated in favor of Mapbox clustering; no-op
}

/**
 * Determine fill color for an item (used for unclustered circle paint).
 * Priority maps to a distinguishable color: High (red), Low (green), Medium (amber).
 * @param {Object} item - Item with Priority or ImmediateNeedsRequired field
 * @returns {string} Hex color code
 */
function determineFillColor(item) {
    const priority = item.Priority || (item.ImmediateNeedsRequired ? 'High' : 'Medium');
    if (String(priority).toLowerCase() === 'high') return '#dc3545';
    if (String(priority).toLowerCase() === 'low') return '#28a745';
    return '#ffc107';
}

/**
 * Determine stroke color for an item (used for unclustered circle stroke).
 * Stroke indicates status: Completed, In Progress, Hold, Pending or default.
 * @param {Object} item - Item with Status field
 * @returns {string} Hex color code
 */
function determineStrokeColor(item) {
    const status = typeof item.Status === 'object' ? item.Status.Value : (item.Status || 'New');
    if (status === 'Completed') return '#155724';
    if (status === 'In Progress') return '#0056b3';
    if (status === 'Hold') return '#6c757d';
    if (status === 'Pending') return '#9a6b00';
    return '#6b7280';
}

/**
 * Create popup content for a marker
 * @param {Object} item - Item data
 * @returns {mapboxgl.Popup} Popup object
 */
function createPopup(item) {
    const title = item.Title || 'Untitled';
    const eventType = typeof item.EventCausedDamage === 'object' 
        ? item.EventCausedDamage?.Value || 'Unknown'
        : item.EventCausedDamage || 'Unknown';
    const status = typeof item.Status === 'object'
        ? item.Status?.Value || 'New'
        : item.Status || 'New';
    const contact = item.Contact_x0020_Name || item.ContactName || 'N/A';
    const priority = item.Priority || (item.ImmediateNeedsRequired ? 'High' : 'Medium');
    const inferredBadge = buildInferredBadge(item);
    
    const popupContent = `
        <div style="min-width: 200px;">
            <div class="popup-title">${title}</div>
            ${inferredBadge}
            <div class="popup-detail"><strong>Type:</strong> ${eventType}</div>
            <div class="popup-detail"><strong>Status:</strong> ${status}</div>
            <div class="popup-detail"><strong>Priority:</strong> ${priority}</div>
            <div class="popup-detail"><strong>Contact:</strong> ${contact}</div>
            <div class="popup-actions">
                <button class="popup-btn popup-btn-primary" onclick="editItem('${item.Id || item.id}')">
                    Edit
                </button>
                <button class="popup-btn popup-btn-secondary" onclick="viewItemDetails('${item.Id || item.id}')">
                    Details
                </button>
            </div>
        </div>
    `;
    
    return new mapboxgl.Popup({
        offset: 25,
        closeButton: true,
        closeOnClick: false
    }).setHTML(popupContent);
}

/**
 * Return HTML string for popup content (used with Mapbox cluster/unclustered layers)
 */
function createPopupHTML(item) {
    const title = item.Title || 'Untitled';
    const eventType = typeof item.EventCausedDamage === 'object'
        ? item.EventCausedDamage?.Value || 'Unknown'
        : item.EventCausedDamage || 'Unknown';
    const status = typeof item.Status === 'object'
        ? item.Status?.Value || 'New'
        : item.Status || 'New';
    const contact = item.Contact_x0020_Name || item.ContactName || 'N/A';
    const priority = item.Priority || (item.ImmediateNeedsRequired ? 'High' : 'Medium');
    const inferredBadge = buildInferredBadge(item);

    return `
        <div style="min-width: 200px;">
            <div class="popup-title">${title}</div>
            ${inferredBadge}
            <div class="popup-detail"><strong>Type:</strong> ${eventType}</div>
            <div class="popup-detail"><strong>Status:</strong> ${status}</div>
            <div class="popup-detail"><strong>Priority:</strong> ${priority}</div>
            <div class="popup-detail"><strong>Contact:</strong> ${contact}</div>
            <div class="popup-actions">
                <button class="popup-btn popup-btn-primary" onclick="editItem('${item.Id || item.id}')">
                    Edit
                </button>
                <button class="popup-btn popup-btn-secondary" onclick="viewItemDetails('${item.Id || item.id}')">
                    Details
                </button>
            </div>
        </div>
    `;
}

function buildInferredBadge(item) {
    if (!item || !item._locationInferred) {
        return '';
    }

    const label = item._locationInferenceDisplayName || item._locationInferenceAddress || 'Address derived from source data';

    return `
        <div class="popup-inferred-badge">
            <span class="popup-inferred-title">Inferred location</span>
            <span class="popup-inferred-caption">${label}</span>
        </div>
    `;
}

/**
 * Fit map bounds to show all markers
 */
function fitMapToMarkers() {
    // Respect map and features
    if (!map || !lastFeatures || lastFeatures.length === 0) return;

    // Respect user preference; do nothing if auto-pan is turned off
    if (!autoPanEnabled) return;

    const now = Date.now();
    const since = now - _lastAutoPanAt;

    // If within cooldown, schedule a delayed fit after remaining cooldown (debounced)
    if (since < AUTO_PAN_COOLDOWN_MS) {
        const remaining = AUTO_PAN_COOLDOWN_MS - since;
        if (_autoPanTimeoutId) {
            clearTimeout(_autoPanTimeoutId);
            _autoPanTimeoutId = null;
        }
        _autoPanTimeoutId = setTimeout(() => {
            _autoPanTimeoutId = null;
            if (!autoPanEnabled) return;
            try {
                const b = new mapboxgl.LngLatBounds();
                lastFeatures.forEach(f => {
                    if (f && f.geometry && Array.isArray(f.geometry.coordinates)) b.extend(f.geometry.coordinates);
                });
                if (!b.isEmpty()) {
                    map.fitBounds(b, { padding: 50, maxZoom: 15 });
                    _lastAutoPanAt = Date.now();
                }
            } catch (e) {
                console.warn('[fitMapToMarkers scheduled] failed:', e && e.message);
            }
        }, Math.max(350, remaining));
        return;
    }

    // Perform immediate fit
    try {
        const bounds = new mapboxgl.LngLatBounds();
        lastFeatures.forEach(f => {
            if (f && f.geometry && Array.isArray(f.geometry.coordinates)) {
                bounds.extend(f.geometry.coordinates);
            }
        });

        if (!bounds.isEmpty()) {
            map.fitBounds(bounds, { padding: 50, maxZoom: 15 });
            _lastAutoPanAt = Date.now();
        }
    } catch (e) {
        console.warn('[fitMapToMarkers] failed:', e && e.message);
    }
}

/**
 * Get the map instance
 * @returns {mapboxgl.Map} Map instance
 */
function getMap() {
    return map;
}

/**
 * Return whether auto-pan is currently enabled
 * @returns {boolean}
 */
function isAutoPanEnabled() {
    return Boolean(autoPanEnabled);
}
