/**
 * SignalR Client Module
 * Manages real-time connections for items and user presence updates
 * Provides automatic reconnection, fallback to polling, and battery-efficient operation
 */

let signalRConnection = null;
let isConnected = false;
let isConnecting = false;
let reconnectAttempts = 0;
let maxReconnectAttempts = 10;
let reconnectDelay = 1000; // Start with 1 second
let maxReconnectDelay = 60000; // Max 60 seconds
let connectionStatusCallbacks = [];
let fallbackToPolling = false;
let pollingFallbackTimeout = null;

// Event handlers
const eventHandlers = {
    'newItem': [],
    'updateItem': [],
    'deleteItem': [],
    'userPresence': [],
    'connectionStatus': []
};

/**
 * Initialize SignalR connection
 * @param {string} token - Authentication token
 * @returns {Promise<boolean>} Success status
 */
async function initSignalR(token) {
    if (isConnecting || isConnected) {
        console.log('[SignalR] Already connected or connecting');
        return isConnected;
    }
    
    console.log('[SignalR] Initializing SignalR connection...');
    isConnecting = true;
    updateConnectionStatus('connecting');
    
    try {
        // Check if SignalR library is loaded
        if (typeof signalR === 'undefined') {
            console.error('[SignalR] SignalR library not loaded');
            throw new Error('SignalR library not available');
        }
        
        // Get connection info from negotiate endpoint
        console.log('[SignalR] Fetching connection info from /api/negotiate...');
        const negotiateResponse = await fetch(`${apiBaseUrl}/negotiate`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!negotiateResponse.ok) {
            let errorMessage = `Negotiate failed: ${negotiateResponse.status} ${negotiateResponse.statusText}`;
            try {
                const errorBody = await negotiateResponse.json();
                if (errorBody && errorBody.message) {
                    errorMessage = errorBody.message;
                }
            } catch (e) {
                // If we can't parse the error body, use the default message
            }
            throw new Error(errorMessage);
        }
        
        const connectionInfo = await negotiateResponse.json();
        console.log('[SignalR] Connection info received');
        
        // Create SignalR connection (let SignalR handle negotiation + transport selection automatically)
        signalRConnection = new signalR.HubConnectionBuilder()
            .withUrl(connectionInfo.url, {
                accessTokenFactory: () => connectionInfo.accessToken
            })
            .withAutomaticReconnect({
                nextRetryDelayInMilliseconds: (retryContext) => {
                    // Exponential backoff with jitter
                    const baseDelay = Math.min(1000 * Math.pow(2, retryContext.previousRetryCount), maxReconnectDelay);
                    const jitter = Math.random() * 1000;
                    return baseDelay + jitter;
                }
            })
            .configureLogging(signalR.LogLevel.Information)
            .build();

        // Set up event handlers
        setupSignalRHandlers();

        await signalRConnection.start();
        
        isConnected = true;
        isConnecting = false;
        reconnectAttempts = 0;
        reconnectDelay = 1000;
        fallbackToPolling = false;
        
        console.log('[SignalR] ✓ Connected successfully');
        updateConnectionStatus('connected');
        
        return true;
        
    } catch (error) {
        console.error('[SignalR] Connection failed:', error);
        isConnecting = false;
        isConnected = false;
        updateConnectionStatus('disconnected');
        
        // Attempt reconnection with exponential backoff
        if (reconnectAttempts < maxReconnectAttempts) {
            reconnectAttempts++;
            const delay = Math.min(reconnectDelay * Math.pow(2, reconnectAttempts - 1), maxReconnectDelay);
            console.log(`[SignalR] Reconnecting in ${delay}ms (attempt ${reconnectAttempts}/${maxReconnectAttempts})...`);
            
            setTimeout(() => {
                initSignalR(token);
            }, delay);
        } else {
            console.warn('[SignalR] Max reconnection attempts reached, falling back to polling');
            fallbackToPolling = true;
            updateConnectionStatus('polling-fallback');
            triggerPollingFallback();
        }
        
        return false;
    }
}

/**
 * Setup SignalR event handlers
 */
function setupSignalRHandlers() {
    if (!signalRConnection) return;
    
    // Handle new item events
    signalRConnection.on('newItem', (item) => {
        console.log('[SignalR] Received newItem event:', item);
        triggerEventHandlers('newItem', item);
    });
    
    // Handle item update events
    signalRConnection.on('updateItem', (item) => {
        console.log('[SignalR] Received updateItem event:', item);
        triggerEventHandlers('updateItem', item);
    });
    
    // Handle item delete events
    signalRConnection.on('deleteItem', (itemId) => {
        console.log('[SignalR] Received deleteItem event:', itemId);
        triggerEventHandlers('deleteItem', itemId);
    });
    
    // Handle user presence updates
    signalRConnection.on('userPresence', (presenceData) => {
        console.log('[SignalR] Received userPresence event:', presenceData);
        triggerEventHandlers('userPresence', presenceData);
    });
    
    // Handle connection state changes
    signalRConnection.onreconnecting((error) => {
        console.warn('[SignalR] Reconnecting...', error);
        updateConnectionStatus('reconnecting');
    });
    
    signalRConnection.onreconnected((connectionId) => {
        console.log('[SignalR] Reconnected successfully:', connectionId);
        isConnected = true;
        reconnectAttempts = 0;
        updateConnectionStatus('connected');
    });
    
    signalRConnection.onclose((error) => {
        console.error('[SignalR] Connection closed:', error);
        isConnected = false;
        updateConnectionStatus('disconnected');
        
        // Attempt to reconnect if not already reconnecting
        if (!isConnecting) {
            if (typeof getAccessToken === 'function') {
                const token = getAccessToken();
                if (token) {
                    setTimeout(() => initSignalR(token), reconnectDelay);
                }
            } else {
                console.warn('[SignalR] getAccessToken not available, cannot reconnect');
            }
        }
    });
}

/**
 * Register an event handler
 * @param {string} eventName - Event name (newItem, updateItem, deleteItem, userPresence)
 * @param {Function} handler - Handler function
 */
function onSignalREvent(eventName, handler) {
    if (eventHandlers[eventName]) {
        eventHandlers[eventName].push(handler);
    } else {
        console.warn(`[SignalR] Unknown event type: ${eventName}`);
    }
}

/**
 * Unregister an event handler
 * @param {string} eventName - Event name
 * @param {Function} handler - Handler function to remove
 */
function offSignalREvent(eventName, handler) {
    if (eventHandlers[eventName]) {
        const index = eventHandlers[eventName].indexOf(handler);
        if (index > -1) {
            eventHandlers[eventName].splice(index, 1);
        }
    }
}

/**
 * Trigger all registered handlers for an event
 * @param {string} eventName - Event name
 * @param {any} data - Event data
 */
function triggerEventHandlers(eventName, data) {
    if (eventHandlers[eventName]) {
        eventHandlers[eventName].forEach(handler => {
            try {
                handler(data);
            } catch (error) {
                console.error(`[SignalR] Error in ${eventName} handler:`, error);
            }
        });
    }
}

/**
 * Register a connection status callback
 * @param {Function} callback - Callback function(status)
 */
function onConnectionStatusChange(callback) {
    connectionStatusCallbacks.push(callback);
}

/**
 * Update connection status and notify callbacks
 * @param {string} status - Status (connecting, connected, reconnecting, disconnected, polling-fallback)
 */
function updateConnectionStatus(status) {
    console.log('[SignalR] Connection status:', status);
    connectionStatusCallbacks.forEach(callback => {
        try {
            callback(status);
        } catch (error) {
            console.error('[SignalR] Error in status callback:', error);
        }
    });
    
    // Update UI status indicator
    updateStatusIndicator(status);
}

/**
 * Update the UI status indicator
 * @param {string} status - Connection status
 */
function updateStatusIndicator(status) {
    const indicator = document.getElementById('signalr-status');
    if (!indicator) return;
    
    // Remove all status classes
    indicator.className = 'signalr-status';
    
    let icon = '';
    let text = '';
    let title = '';
    
    switch (status) {
        case 'connecting':
            indicator.classList.add('connecting');
            icon = '🔄';
            text = 'Connecting...';
            title = 'Establishing real-time connection';
            break;
        case 'connected':
            indicator.classList.add('connected');
            icon = '✓';
            text = 'Live';
            title = 'Real-time updates active';
            break;
        case 'reconnecting':
            indicator.classList.add('reconnecting');
            icon = '⚠️';
            text = 'Reconnecting...';
            title = 'Connection lost, attempting to reconnect';
            break;
        case 'disconnected':
            indicator.classList.add('disconnected');
            icon = '✕';
            text = 'Offline';
            title = 'Real-time connection unavailable';
            break;
        case 'polling-fallback':
            indicator.classList.add('polling');
            icon = '🔄';
            text = 'Polling';
            title = 'Using fallback polling mode';
            break;
    }
    
    indicator.innerHTML = `<span class="status-icon">${icon}</span><span class="status-text">${text}</span>`;
    indicator.title = title;
}

/**
 * Trigger fallback to polling mode
 */
function triggerPollingFallback() {
    console.log('[SignalR] Activating polling fallback');
    
    // Notify handlers that we're in fallback mode
    if (typeof startAutoRefresh === 'function') {
        startAutoRefresh();
    }
    
    if (typeof startPresencePolling === 'function') {
        startPresencePolling();
    }
}

/**
 * Stop polling fallback when SignalR reconnects
 */
function stopPollingFallback() {
    console.log('[SignalR] Deactivating polling fallback');
    
    if (typeof stopAutoRefresh === 'function') {
        stopAutoRefresh();
    }
    
    if (typeof stopPresencePolling === 'function') {
        stopPresencePolling();
    }
}

/**
 * Disconnect SignalR
 */
async function disconnectSignalR() {
    if (signalRConnection) {
        try {
            await signalRConnection.stop();
            console.log('[SignalR] Disconnected');
        } catch (error) {
            console.error('[SignalR] Error during disconnect:', error);
        }
        signalRConnection = null;
        isConnected = false;
        isConnecting = false;
    }
    updateConnectionStatus('disconnected');
}

/**
 * Check if SignalR is connected
 * @returns {boolean} Connection status
 */
function isSignalRConnected() {
    if (typeof signalR === 'undefined') {
        return false;
    }
    return isConnected && signalRConnection && signalRConnection.state === signalR.HubConnectionState.Connected;
}

/**
 * Send a message through SignalR (if needed for future features)
 * @param {string} method - Method name
 * @param {...any} args - Arguments
 */
async function invokeSignalR(method, ...args) {
    if (!isSignalRConnected()) {
        throw new Error('SignalR not connected');
    }
    
    try {
        return await signalRConnection.invoke(method, ...args);
    } catch (error) {
        console.error(`[SignalR] Error invoking ${method}:`, error);
        throw error;
    }
}

// Export functions for global use
window.initSignalR = initSignalR;
window.disconnectSignalR = disconnectSignalR;
window.isSignalRConnected = isSignalRConnected;
window.onSignalREvent = onSignalREvent;
window.offSignalREvent = offSignalREvent;
window.onConnectionStatusChange = onConnectionStatusChange;
