/**
 * Main application module
 * Coordinates authentication, API, and map functionality
 */

let config = null;
let items = [];
let refreshInterval = null;
let isEditing = false;
let editingItemId = null;
let assessmentModeParams = null; // Store assessment mode parameters from URL

// At the start of your app initialization, check for Teams context
async function initializeApp() {
    // Check URL parameters for Teams context
    const urlParams = new URLSearchParams(window.location.search);
    const loginHint = urlParams.get('loginHint');
    const userObjectId = urlParams.get('userObjectId');
    const tid = urlParams.get('tid');
    const groupId = urlParams.get('groupId');
    const incidentId = urlParams.get('incidentId');
    const siteUrl = urlParams.get('siteUrl');
    const listName = urlParams.get('listName');
    const dataSource = urlParams.get('dataSource');
    
    console.log('URL parameters:', { loginHint, userObjectId, tid, groupId, incidentId, siteUrl, listName, dataSource });
    
    /**
     * Assessment Mode Detection
     * 
     * When the Map App is added to an incident's General channel, the tab URL includes:
     * - dataSource=assessments - Indicates this is an assessment map (not general incident map)
     * - siteUrl - The SharePoint site URL where the "Ground Assessments" list is located
     * - listName - The name of the SharePoint list (e.g., "Ground Assessments")
     * - incidentId - (Optional) The incident ID for filtering, if the list is shared across incidents
     * 
     * In assessment mode:
     * - Map fetches ONLY from the specified SharePoint list (not all registered data sources)
     * - If incidentId is provided AND the list has an IncidentId field, items are filtered by incident
     * - If no IncidentId field exists, all items in the list are assumed to belong to the incident
     *   (this handles per-incident lists where the list itself is scoped to the incident)
     * 
     * Normal mode (when dataSource !== 'assessments'):
     * - Map fetches from all registered data sources in Table Storage
     * - No filtering by incident - shows all items from all sources
     */
    if (dataSource === 'assessments' && siteUrl && listName) {
        assessmentModeParams = {
            dataSource,
            siteUrl,
            listName
        };
        // Only include incidentId if it has a value
        if (incidentId) {
            assessmentModeParams.incidentId = incidentId;
        }
        console.log('Assessment mode detected:', assessmentModeParams);
    }
    
    // Check if running inside Teams
    if (window.microsoftTeams) {
        try {
            await window.microsoftTeams.app.initialize();
            const context = await window.microsoftTeams.app.getContext();
            console.log('Running inside Teams tab', context);
            
            // Get SSO token from Teams - this provides automatic sign-in
            try {
                const token = await window.microsoftTeams.authentication.getAuthToken({
                    silent: true // Try silent auth first
                });
                
                if (token) {
                    // Decode token to get user info
                    const tokenParts = token.split('.');
                    const payload = JSON.parse(atob(tokenParts[1]));
                    
                    currentUser = {
                        username: payload.preferred_username || payload.upn,
                        name: payload.name,
                        email: payload.email || payload.preferred_username,
                        id: payload.oid || userObjectId
                    };
                    
                    console.log('Authenticated user from Teams SSO:', currentUser);
                    
                    // Use this token for your API calls
                    setAPIToken(token);
                    console.log('✓ Teams SSO authentication successful');
                    
                    // Update UI to show user is logged in
                    updateAuthUI();
                    
                    // Initialize your map and load data
                    await onAuthenticated(token);
                    return;
                }
            } catch (ssoError) {
                console. warn('Teams SSO failed, falling back to interactive auth:', ssoError);
            }
        } catch (teamsError) {
            console. log('Not in Teams context, using standard auth');
        }
    }
    
    // If we have login hint from URL but not in Teams, use it for pre-filling login
    if (loginHint && !isAuthenticated()) {
        console.log('Pre-filling login with hint:', loginHint);
        // Store login hint for use during authentication
        sessionStorage.setItem('loginHint', loginHint);
    }
    
    // Standard initialization for browser context
    const config = await loadConfig();
    if (config) {
        await initAuth(config);
        if (isAuthenticated()) {
            const token = await getAccessToken();
            await onAuthenticated(token);
        }
    }
}

async function initAuth(config) {
    // Update MSAL config with provided values
    msalConfig.auth. clientId = config.entraClientId || config.clientId;
    msalConfig.auth.authority = `https://login.microsoftonline.com/${config.entraTenantId || config.tenantId}`;
    
    // Check if we have valid config
    if (!msalConfig. auth.clientId || !config.entraTenantId) {
        console.warn('⚠️ Entra ID not configured.  Running without authentication.');
        return null;
    }
    
    // Get login hint from session storage if available
    const loginHint = sessionStorage.getItem('loginHint');
    if (loginHint) {
        loginRequest.loginHint = loginHint;
        console.log('Using login hint for authentication:', loginHint);
    }
    
    // Build API scope
    try {
        if (config.apiScope && typeof config.apiScope === 'string' && config.apiScope.length > 0) {
            if (!/api: \/\/localhost\//i.test(config.apiScope)) {
                apiScopeValue = config.apiScope;
                loginRequest.scopes = ['User.Read'];
                console.log('Using server-provided API scope for backend requests:', apiScopeValue);
            }
        } else {
            const apiScope = buildApiScope(config.functionBaseUrl || window.location.origin, msalConfig.auth.clientId);
            if (apiScope) {
                apiScopeValue = apiScope;
                loginRequest.scopes = ['User.Read'];
                console. log('API scope set for backend requests (built):', apiScopeValue);
            }
        }
    } catch (e) {
        // ignore failures building scope
    }
    publishDebugAuthState();

    // Check if running in Teams - PRIORITIZE TEAMS SSO
    if (window.microsoftTeams) {
        try {
            await window.microsoftTeams.app.initialize();
            const context = await window.microsoftTeams. app.getContext();
            isTeamsContext = true;
            console.log('Running in Teams context', context);
            
            // Use Teams SSO (not popup auth)
            return await initTeamsSSOAuth();
        } catch (err) {
            console.log('Not in Teams context, using browser auth');
        }
    }
    
    // Browser context - use MSAL
    return initBrowserAuth();
}


/**
 * Initialize the application
 */
async function initApp() {
    console.log('🚀 Initializing TEOC Operations Map...');
    
    try {
        showLoading(true);
        
        // Load configuration
        console.log('📡 Loading configuration...');
        config = await getConfig();
        console.log('✓ Configuration loaded:', config);
        
        // Initialize API
        initAPI(config.functionBaseUrl || window.location.origin);
        
        // Initialize authentication
        console.log('🔐 Initializing authentication...');
        // Pass the full config object so initAuth can access server-provided values like apiScope
        const token = await initAuth(config);
        
        if (token) {
            console.log('✓ Authentication successful');
            setAPIToken(token);
            await onAuthenticated(token);
        } else {
            console.log('ℹ️ Not authenticated - showing sign-in prompt');
            // Show sign-in prompt
            showToast('Please sign in to continue', 'info');

            // For local testing we still initialize the map and UI so
            // developers can work without a full Entra auth flow. This
            // keeps the UX similar while features that require auth will
            // still be gated when attempting to call protected APIs.
            await onAuthenticated(null);
        }
        
        // Setup event listeners
        setupEventListeners();
        
        // Adapt UI for Teams if needed
        if (isInTeams()) {
            adaptUIForTeams();
        }
        
        showLoading(false);
        console.log('✓ Application initialized successfully');
        
        // Initialize legend with empty data (shows 0 counts) - will update when items load
        try { renderLegend([]); } catch (e) { console.warn('Legend render failed:', e); }
    } catch (error) {
        console.error('❌ App initialization failed:', error);
        showToast('Failed to initialize application. Check console for details.', 'error');
        showLoading(false);
        
        // Show error details in the map area
        const mapContainer = document.getElementById('map');
        if (mapContainer) {
            mapContainer.innerHTML = `
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f3f4f6; flex-direction: column; padding: 20px; text-align: center;">
                    <div style="max-width: 600px;">
                        <h2 style="color: #dc3545; margin-bottom: 16px;">❌ Initialization Error</h2>
                        <p style="color: #6b7280; margin-bottom: 16px;">
                            The application failed to initialize. This may be due to missing configuration or network issues.
                        </p>
                        <div style="background: #fff; padding: 16px; border-radius: 8px; text-align: left; margin-bottom: 16px; border: 1px solid #e5e7eb;">
                            <strong>Error details:</strong><br>
                            <code style="color: #dc3545; word-break: break-word;">${error.message}</code>
                        </div>
                        <p style="color: #6b7280; font-size: 14px;">
                            Please check the browser console (F12) for more information.
                        </p>
                    </div>
                </div>
            `;
        }
    }
}

/**
 * Handle post-authentication setup
 */
async function onAuthenticated(token) {
    try {
        // Check if we have a valid Mapbox token
        if (!config.mapboxToken) {
            showToast('⚠️ Mapbox token not configured. Map features will not be available.', 'error');
            console.warn('Mapbox token is missing. Set MAPBOX_API_KEY in function configuration.');
            
            // Show a message on the map container
            const mapContainer = document.getElementById('map');
            if (mapContainer) {
                mapContainer.innerHTML = `
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f3f4f6; flex-direction: column; padding: 20px; text-align: center;">
                        <div style="max-width: 500px;">
                            <h2 style="color: #dc3545; margin-bottom: 16px;">⚠️ Configuration Required</h2>
                            <p style="color: #6b7280; margin-bottom: 16px;">
                                The Mapbox API key is not configured. Please add <code>MAPBOX_API_KEY</code> to your Azure Function App settings.
                            </p>
                            <p style="color: #6b7280; font-size: 14px;">
                                Get a free API key at <a href="https://www.mapbox.com/" target="_blank" style="color: #007bff;">mapbox.com</a>
                            </p>
                        </div>
                    </div>
                `;
            }
            return;
        }
        
        // Initialize map (always do this for local testing even if not authenticated)
        initMap(config.mapboxToken, {
            center: config.defaultMapCenter || [133.7751, -25.2744],
            zoom: config.defaultMapZoom || 4
        });

        // Determine whether we have an access token. If we don't, skip
        // loading protected API data (items) to avoid 401 responses while
        // still letting developers interact with the map locally.
        const accessToken = token || await getAccessToken();

        if (accessToken && accessToken !== 'dev-token') {
            // Load initial items
            await loadItems();

            // Initialize SignalR for real-time updates
            const signalRConnected = await initSignalR(accessToken);
            
            if (signalRConnected) {
                // SignalR connected - set up event handlers
                setupSignalREventHandlers();
                console.log('✓ Real-time updates enabled via SignalR');
            } else {
                // SignalR failed - fall back to polling
                console.log('⚠️ SignalR connection failed, using polling fallback');
                startAutoRefresh();
            }

            // Initialize user presence tracking with SignalR support
            await initPresence(accessToken);
            console.log('User presence tracking initialized');
            
            // Initialize notification card system with config
            if (typeof initNotificationCards === 'function') {
                await initNotificationCards(config);
                console.log('✓ Notification cards initialized');
            }
            
            // Only show welcome message if user is actually authenticated
            showToast('Welcome! You are signed in.', 'success');
        } else {
            console.log('No access token available; skipping items and presence initialization.');
        }
        
        // Initialize legend with empty data before loading items
        try { renderLegend([]); } catch (e) { console.warn('Legend render failed:', e); }
    } catch (error) {
        console.error('Post-authentication setup failed:', error);
        showToast('Setup failed: ' + error.message, 'error');
    }
    finally {
        // Ensure any loading overlay is hidden after authentication
        try {
            showLoading(false);
        } catch (e) {
            // ignore
        }
    }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Login/logout buttons
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    if (loginBtn) loginBtn.addEventListener('click', handleLogin);
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);
    
    // FAB (Floating Action Button)
    const fab = document.getElementById('fab-add');
    if (fab) fab.addEventListener('click', openCreatePanel);
    
    // Panel controls
    const closePanelBtn = document.getElementById('close-panel');
    const cancelBtn = document.getElementById('cancel-btn');
    if (closePanelBtn) closePanelBtn.addEventListener('click', closePanel);
    if (cancelBtn) cancelBtn.addEventListener('click', closePanel);
    
    // Form submission
    const itemForm = document.getElementById('item-form');
    if (itemForm) itemForm.addEventListener('submit', handleFormSubmit);
    
    // Location info box controls
    const closeLocationInfo = document.getElementById('close-location-info');
    const createItemHere = document.getElementById('create-item-here');
    if (closeLocationInfo) closeLocationInfo.addEventListener('click', hideLocationInfoBox);
    if (createItemHere) createItemHere.addEventListener('click', handleCreateItemHere);
}

// Initialize header legend toggle and user display adjustments
function initHeaderUI() {
    const legendContent = document.getElementById('legend-content');
    const userNameEl = document.getElementById('user-name');
    const userImage = document.getElementById('user-image');
    
    // Setup legend popout toggle (consolidated - single event listener)
    const legendPopout = document.getElementById('legend-popout');
    if (legendPopout && legendContent) {
        console.log('✓ Attaching legend popout toggle event listener');
        legendPopout.addEventListener('click', () => {
            const isOpen = legendContent.classList.toggle('open');
            legendPopout.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            console.log('Legend popout toggled:', isOpen);
        });
    } else {
        console.warn('Legend popout or content element not found');
    }

    // Collapse username into initials on small screens
    function updateUserDisplay() {
        const user = getCurrentUser();
        if (!user) return;
        const name = user.name || user.username || '';
        const initials = name.split(' ').map(n => n[0]).slice(0,2).join('').toUpperCase();

        // If an avatar is available (Teams/MSAL may provide picture url in account), prefer it
        try {
            if (userImage) {
                if (user.imageUrl) {
                    userImage.innerHTML = `<img src="${user.imageUrl}" alt="${name}">`;
                } else {
                    userImage.textContent = initials;
                }
            }

            // On narrow screens, hide long name and show only initials/avatar
            if (userNameEl) {
                if (window.matchMedia && window.matchMedia('(max-width: 480px)').matches) {
                    userNameEl.textContent = '';
                } else {
                    userNameEl.textContent = name;
                }
            }

            // Populate user menu name
            const userMenuNameEl = document.getElementById('user-menu-name');
            if (userMenuNameEl) userMenuNameEl.textContent = name;
        } catch (e) {
            // ignore DOM update errors
        }

        // Mirror counts into header inline legend elements (if present)
        function mirror(cls, value) {
            document.querySelectorAll('.' + cls).forEach(el => el.textContent = String(value));
        }

            try {
                // Render legend based on current items data
                renderLegend(items);
            } catch (e) { /* ignore */ }
    }

    // Update when auth state changes
    const originalUpdateAuthUI = window.updateAuthUI;
    window.updateAuthUI = function() {
        if (typeof originalUpdateAuthUI === 'function') originalUpdateAuthUI();
        try { updateUserDisplay(); } catch (e) { /* ignore */ }
    };

    // Also update on resize
    window.addEventListener('resize', () => {
        try { updateUserDisplay(); } catch (e) {}
    });

    // Initial call
    try { updateUserDisplay(); } catch (e) {}

    // Debug: log current user menu structure for troubleshooting
    try {
        const dbgMenu = document.getElementById('user-menu');
        if (dbgMenu) {
            const dbgItems = Array.from(dbgMenu.children).map(c => ({ tag: c.tagName, id: c.id || null, text: c.textContent && c.textContent.trim() }));
            console.log('[initHeaderUI] user-menu children:', dbgItems);
        } else {
            console.log('[initHeaderUI] user-menu not found in DOM');
        }
    } catch (e) {
        console.warn('Failed to log user-menu structure:', e);
    }

    // Wire user menu open/close and sign out
    try {
        const userBtn = document.getElementById('user-btn');
        const userMenu = document.getElementById('user-menu');
        const userAdmin = document.getElementById('user-admin');
        const userSignout = document.getElementById('user-signout');
        // Ensure aria attributes are present and consistent
        try {
            if (userMenu && !userMenu.hasAttribute('aria-hidden')) userMenu.setAttribute('aria-hidden', 'true');
            if (userBtn && !userBtn.hasAttribute('aria-expanded')) userBtn.setAttribute('aria-expanded', 'false');
        } catch (e) {}
        if (userBtn && userMenu) {
            userBtn.addEventListener('click', (ev) => {
                const isOpen = userMenu.getAttribute('aria-hidden') === 'false';
                userMenu.setAttribute('aria-hidden', isOpen ? 'true' : 'false');
                userBtn.setAttribute('aria-expanded', !isOpen);
            });
        }
        if (userAdmin) {
            userAdmin.addEventListener('click', () => {
                window.location.href = '/web/admin.html';
            });
        }
        if (userSignout) {
            userSignout.addEventListener('click', async () => {
                try { await signOut(); } catch (e) { console.error(e); }
            });
        }
    } catch (e) { /* ignore */ }
}

// call initHeaderUI after DOM loaded
window.addEventListener('load', () => {
    try { initHeaderUI(); } catch (e) { /* ignore */ }
});

/**
 * Handle login button click
 */
async function handleLogin() {
    try {
        showLoading(true);
        await signIn();
    } catch (error) {
        console.error('Login failed:', error);
        showToast('Login failed: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Ensure loading overlay is hidden whether sign-in succeeds or fails
async function handleLoginWrapper() {
    try {
        showLoading(true);
        await signIn();
    } catch (error) {
        console.error('Login failed:', error);
        showToast('Login failed: ' + (error && error.message ? error.message : 'Unknown error'), 'error');
    } finally {
        showLoading(false);
    }
}

/**
 * Handle logout button click
 */
async function handleLogout() {
    try {
        await signOut();
        
        // Disconnect SignalR
        if (typeof disconnectSignalR !== 'undefined') {
            await disconnectSignalR();
        }
        
        // Stop presence tracking
        if (typeof stopPresence !== 'undefined') {
            stopPresence();
        }
        
        // Clear data
        items = [];
        stopAutoRefresh();
        
        // Clear map
        const mapInstance = getMap();
        if (mapInstance) {
            mapInstance.remove();
        }
        
        showToast('Signed out successfully', 'success');
    } catch (error) {
        console.error('Logout failed:', error);
        showToast('Logout failed: ' + error.message, 'error');
    }
}

/**
 * Load incident types from SharePoint and populate dropdown
 */

async function loadItems() {
    try {
        // Pass assessment mode parameters if available
        const filters = assessmentModeParams || {};
        const result = await fetchItems(filters);
        items = result.items || result;  // Support both new and old response format
        
        // Store available sources if provided
        if (result.sources) {
            window.availableSources = result.sources;
            updateSourcePicker(result.sources);
        }
        
        updateMapMarkers(items);
        updateLegendCounts(items);
        updateLegendStatusCounts(items);
        
        // Fit map to show all markers on first load
        if (items.length > 0) {
            try {
                if (typeof isAutoPanEnabled === 'function') {
                    if (isAutoPanEnabled()) fitMapToMarkers();
                } else {
                    fitMapToMarkers();
                }
            } catch (e) {
                fitMapToMarkers();
            }
        }
    } catch (error) {
        console.error('Failed to load items:', error);
        showToast('Failed to load items: ' + error.message, 'error');
    }
}

/**
 * Update source picker dropdown with available sources
 * @param {Array} sources - Array of source objects
 */
function updateSourcePicker(sources) {
    const sourceSelect = document.getElementById('source-select');
    if (!sourceSelect) return;
    
    // Clear existing options except default
    sourceSelect.innerHTML = '<option value="default">Default List</option>';
    
    // Add source options
    if (sources && sources.length > 0) {
        sources.forEach(source => {
            const option = document.createElement('option');
            option.value = source.id;
            option.textContent = `${source.name} (${source.type})`;
            sourceSelect.appendChild(option);
        });
        
        console.log(`Updated source picker with ${sources.length} sources`);
    }
}

/**
 * Update legend counts based on current items list
 * @param {Array} items
 */
function updateLegendCounts(items) {
    try {
        // Delegate rendering to renderLegend which computes counts and updates DOM
        try { renderLegend(items); } catch (e) { /* ignore */ }
    } catch (e) {
        // ignore
    }
}

/** Update status counts as well and set appropriate badge classes */
function updateLegendStatusCounts(items) {
    try {
        // Delegate rendering to renderLegend which computes counts and updates DOM
        try { renderLegend(items); } catch (e) { /* ignore */ }
    } catch (e) {
        // ignore
    }
}

/**
 * Render legend UI dynamically into header inline and popout panel.
 * Shows priority and status markers with counts. Renders with dummy data (0s) if no items provided.
 * @param {Array} items - Array of item objects to count and display
 */
function renderLegend(items) {
    // compute counts
    const priority = { High: 0, Medium: 0, Low: 0 };
    const status = { Pending: 0, 'In Progress': 0, Completed: 0, Hold: 0, New: 0 };
    (items || []).forEach(it => {
        const p = it.Priority || (it.ImmediateNeedsRequired ? 'High' : 'Medium');
        if (String(p).toLowerCase() === 'high') priority.High++;
        else if (String(p).toLowerCase() === 'low') priority.Low++;
        else priority.Medium++;

        const st = (typeof it.Status === 'object' ? it.Status.Value : it.Status) || 'New';
        if (status[st] !== undefined) status[st]++; else status.New++;
    });

    // Header inline: show priorities then top statuses
    const headerContainer = document.getElementById('header-inline-items');
    if (headerContainer) {
        headerContainer.innerHTML = '';
        // priorities
        ['High','Medium','Low'].forEach(k => {
            const entry = buildInlineLegendEntry(k, priority[k], 'priority');
            headerContainer.appendChild(entry);
        });
        // small separator
        const sep = document.createElement('div'); sep.className = 'inline-sep'; sep.textContent = '·'; headerContainer.appendChild(sep);
        // statuses - show only Pending, In Progress, Completed (most useful)
        ['Pending','In Progress','Completed'].forEach(k => {
            const entry = buildInlineLegendEntry(k, status[k], 'status');
            headerContainer.appendChild(entry);
        });
    }

    // Popout content (full legend)
    const popout = document.getElementById('legend-content');
    if (popout) {
        popout.innerHTML = '';
        // Priority section
        const priSec = document.createElement('div'); priSec.className = 'legend-section';
        const priTitle = document.createElement('div'); priTitle.className='legend-title'; priTitle.textContent = 'Priority'; priSec.appendChild(priTitle);
        const priList = document.createElement('div'); priList.className='legend-list';
        ['High','Medium','Low'].forEach(k => {
            const row = buildFullLegendRow(k, priority[k], 'priority');
            priList.appendChild(row);
        });
        priSec.appendChild(priList);
        popout.appendChild(priSec);

        // Status section
        const stSec = document.createElement('div'); stSec.className = 'legend-section';
        const stTitle = document.createElement('div'); stTitle.className='legend-title'; stTitle.textContent = 'Status'; stSec.appendChild(stTitle);
        const stList = document.createElement('div'); stList.className='legend-list';
        ['Pending','In Progress','Completed','Hold','New'].forEach(k => {
            const row = buildFullLegendRow(k, status[k], 'status');
            stList.appendChild(row);
        });
        stSec.appendChild(stList);
        popout.appendChild(stSec);

        const locSec = document.createElement('div');
        locSec.className = 'legend-section';
        const locTitle = document.createElement('div');
        locTitle.className = 'legend-title';
        locTitle.textContent = 'Location confidence';
        locSec.appendChild(locTitle);

        const locRow = document.createElement('div');
        locRow.className = 'legend-row';
        const locMarker = document.createElement('div');
        locMarker.className = 'legend-marker location-inferred';
        locRow.appendChild(locMarker);

        const locLabel = document.createElement('div');
        locLabel.className = 'legend-label';
        locLabel.textContent = 'Inferred from address (geocoded)';
        locRow.appendChild(locLabel);

        locSec.appendChild(locRow);
        popout.appendChild(locSec);
    }
}

/**
 * Build inline legend entry for header (compact view).
 * Creates a simple circular marker with count badge.
 * Circle color = Priority, Outline color = Status
 * @param {string} key - Priority or status key
 * @param {number} count - Number of items in this category
 * @param {string} type - 'priority' or 'status'
 * @returns {HTMLElement} Legend entry element
 */
function buildInlineLegendEntry(key, count, type = 'priority') {
    const container = document.createElement('div');
    container.className = 'header-inline-entry';
    
    const marker = document.createElement('div');
    marker.className = 'legend-marker';
    
    if (type === 'priority') {
        // Priority: colored circle with default status border
        marker.classList.add(getPriorityClass(key));
    } else {
        // Status: grey circle with colored status border
        marker.classList.add('status-only');
        marker.classList.add(getStatusClass(key));
    }
    
    const cnt = document.createElement('span');
    cnt.className = 'marker-count';
    cnt.textContent = String(count || 0);
    marker.appendChild(cnt);
    
    const label = document.createElement('span');
    label.className = 'legend-label-inline';
    label.textContent = (key === 'In Progress' ? 'In Prog' : key);
    
    container.appendChild(marker);
    container.appendChild(label);
    return container;
}

/**
 * Build full legend row for popout panel (verbose view).
 * Creates a simple circular marker with count badge and label.
 * Circle color = Priority, Outline color = Status
 * @param {string} key - Priority or status key
 * @param {number} count - Number of items in this category
 * @param {string} type - 'priority' or 'status'
 * @returns {HTMLElement} Legend row element
 */
function buildFullLegendRow(key, count, type) {
    const row = document.createElement('div');
    row.className = 'legend-row';
    
    const marker = document.createElement('div');
    marker.className = 'legend-marker';
    
    if (type === 'priority') {
        // Priority: colored circle with default status border
        marker.classList.add(getPriorityClass(key));
    } else {
        // Status: grey circle with colored status border
        marker.classList.add('status-only');
        marker.classList.add(getStatusClass(key));
    }
    
    const cnt = document.createElement('span');
    cnt.className = 'marker-count';
    cnt.textContent = String(count || 0);
    marker.appendChild(cnt);
    
    const label = document.createElement('div');
    label.className = 'legend-label';
    label.textContent = key + ' (' + (count || 0) + ')';
    
    row.appendChild(marker);
    row.appendChild(label);
    return row;
}

/**
 * Get the priority CSS class based on key.
 * @param {string} key - Priority key
 * @returns {string} CSS class name
 */
function getPriorityClass(key) {
    const k = String(key).toLowerCase();
    if (k.includes('high')) return 'priority-high';
    if (k.includes('medium')) return 'priority-medium';
    if (k.includes('low')) return 'priority-low';
    return 'priority-medium';
}

/**
 * Get the status CSS class based on key.
 * @param {string} key - Status key
 * @returns {string} CSS class name
 */
function getStatusClass(key) {
    const k = String(key).toLowerCase();
    if (k.includes('pending')) return 'status-pending';
    if (k.includes('in progress') || k.includes('inprogress')) return 'status-inprogress';
    if (k.includes('completed') || k.includes('complete')) return 'status-completed';
    if (k.includes('hold')) return 'status-hold';
    if (k.includes('new')) return 'status-new';
    return 'status-new';
}

/**
 * Setup SignalR event handlers for real-time updates
 */
function setupSignalREventHandlers() {
    console.log('[SignalR] Setting up event handlers...');
    
    // Handle new item events
    onSignalREvent('newItem', (item) => {
        console.log('[SignalR] New item received:', item);
        // Add to items array if not already present
        if (!items.find(i => i.id === item.id)) {
            items.push(item);
            // Create marker on map (calls renderItems internally)
            renderItems();
            showToast(`New item: ${item.Title}`, 'info');
        }
    });
    
    // Handle item update events
    onSignalREvent('updateItem', (item) => {
        console.log('[SignalR] Item update received:', item);
        // Update item in array
        const index = items.findIndex(i => i.id === item.id);
        if (index !== -1) {
            items[index] = item;
            // Re-render markers to reflect updates
            renderItems();
            showToast(`Item updated: ${item.Title}`, 'info');
        } else {
            // Item not in array, add it
            items.push(item);
            renderItems();
        }
    });
    
    // Handle item delete events
    onSignalREvent('deleteItem', (itemId) => {
        console.log('[SignalR] Item delete received:', itemId);
        // Remove from array
        const index = items.findIndex(i => i.id === itemId);
        if (index !== -1) {
            items.splice(index, 1);
            // Re-render markers to remove deleted item
            renderItems();
            showToast('Item deleted', 'info');
        }
    });
    
    console.log('[SignalR] Event handlers registered');
}

/**
 * Start auto-refresh of items (polling fallback)
 */
function startAutoRefresh() {
    // Avoid creating multiple intervals
    if (refreshInterval) return;

    console.log('[Polling] Starting fallback polling (30s interval)...');
    // Refresh every 30 seconds
    refreshInterval = setInterval(async () => {
        try {
            await loadItems();
        } catch (error) {
            console.error('Auto-refresh failed:', error);
        }
    }, 30000);
}

/**
 * Stop auto-refresh
 */
function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
        console.log('[Polling] Stopped polling');
    }
}

/**
 * Open panel for creating new item
 */
function openCreatePanel() {
    if (!isAuthenticated()) {
        showToast('Please sign in to create items', 'error');
        return;
    }
    
    isEditing = false;
    editingItemId = null;
    
    // Reset form
    const itemFormEl = document.getElementById('item-form');
    if (itemFormEl) itemFormEl.reset();
    const panelTitleEl = document.getElementById('panel-title');
    if (panelTitleEl) panelTitleEl.textContent = 'Create New Item';
    const submitTextEl = document.getElementById('submit-text');
    if (submitTextEl) submitTextEl.textContent = 'Create Item';
    
    // Clear current marker
    clearCurrentMarker();
    
    // Pre-fill user info
    const user = getCurrentUser();
    if (user && user.name) {
        const contactNameEl = document.getElementById('contact-name');
        if (contactNameEl) contactNameEl.value = user.name;
    }
    
    // Hide location info box if visible
    if (typeof hideLocationInfoBox === 'function') {
        hideLocationInfoBox();
    }
    
    // Open panel
    const sidePanelEl = document.getElementById('side-panel');
    if (sidePanelEl) sidePanelEl.classList.add('open');
}

/**
 * Open panel for editing existing item
 * @param {string} itemId - Item ID
 */
async function editItem(itemId) {
    if (!isAuthenticated()) {
        showToast('Please sign in to edit items', 'error');
        return;
    }
    
    const item = items.find(i => (i.Id || i.id) === itemId);
    if (!item) {
        showToast('Item not found', 'error');
        return;
    }
    
    isEditing = true;
    editingItemId = itemId;
    
    // Populate form with item data (guarding DOM elements)
    const titleEl = document.getElementById('title'); if (titleEl) titleEl.value = item.Title || '';
    const eventTypeEl = document.getElementById('event-type'); if (eventTypeEl) eventTypeEl.value = typeof item.EventCausedDamage === 'object' ? item.EventCausedDamage.Value : item.EventCausedDamage || '';
    const descEl = document.getElementById('description'); if (descEl) descEl.value = item.MoreInformation || '';
    const contactNameEl = document.getElementById('contact-name'); if (contactNameEl) contactNameEl.value = item.ContactName || item['Contact_x0020_Name'] || '';
    const contactPhoneEl = document.getElementById('contact-phone'); if (contactPhoneEl) contactPhoneEl.value = item.ContactPhoneNumber || item['ContactPhoneNumber'] || '';
    const immediateEl = document.getElementById('immediate-needs'); if (immediateEl) immediateEl.checked = item.ImmediateNeedsRequired || false;
    const statusEl = document.getElementById('status'); if (statusEl) statusEl.value = typeof item.Status === 'object' ? item.Status.Value : item.Status || 'New';
    const priorityEl = document.getElementById('priority'); if (priorityEl) priorityEl.value = item.Priority || (item.ImmediateNeedsRequired ? 'High' : 'Medium');
    
    // Set coordinates
    // Use Location.coordinates, GeoLoc, or fallback numeric fields
    const coords = (item.Location && item.Location.coordinates) || item.GeoLoc || null;
    const lat = coords && (coords.latitude || coords.lat) ? (coords.latitude || coords.lat) : (item.latitude || item.Latitude);
    const lng = coords && (coords.longitude || coords.lng) ? (coords.longitude || coords.lng) : (item.longitude || item.Longitude);
    if (lat && lng) {
        try { setCurrentMarkerPosition(lat, lng); } catch (e) { /* ignore */ }
    }
    
    // Update panel
    document.getElementById('panel-title').textContent = 'Edit Item';
    document.getElementById('submit-text').textContent = 'Update Item';
    
    // Open panel
    const sidePanelEl2 = document.getElementById('side-panel');
    if (sidePanelEl2) sidePanelEl2.classList.add('open');
}

// Expose to window for inline onclick handlers
window.editItem = editItem;

/**
 * View item details (could open a detailed view)
 * @param {string} itemId - Item ID
 */
function viewItemDetails(itemId) {
    const item = items.find(i => (i.Id || i.id) === itemId);
    if (!item) {
        showToast('Item not found', 'error');
        return;
    }
    
    // For now, just show edit panel
    editItem(itemId);
}

// Expose to window for inline onclick handlers
window.viewItemDetails = viewItemDetails;

/**
 * Close the side panel
 */
function closePanel() {
    const sp = document.getElementById('side-panel'); if (sp) sp.classList.remove('open');
    try { clearCurrentMarker(); } catch (e) {}
    isEditing = false;
    editingItemId = null;
}

/**
 * Handle "Create Item Here" button click from location info box
 */
function handleCreateItemHere() {
    const box = document.getElementById('location-info-box');
    if (!box) return;
    
    // Get coordinates from the box
    const lat = parseFloat(box.dataset.lat);
    const lng = parseFloat(box.dataset.lng);
    
    if (isNaN(lat) || isNaN(lng)) {
        showToast('Invalid coordinates', 'error');
        return;
    }
    
    // Open the create panel
    openCreatePanel();
    
    // Set the marker position with the stored coordinates
    // Use setTimeout to ensure panel is fully opened and geocoder is initialized
    setTimeout(() => {
        try {
            setCurrentMarkerPosition(lat, lng);
            
            // If we have geocoder result, store it for form submission (matches existing pattern in map.js:545)
            if (box.dataset.geocoderResult) {
                try {
                    window.lastGeocoderResult = JSON.parse(box.dataset.geocoderResult);
                } catch (e) {
                    console.warn('Failed to parse geocoder result - address data may not be saved:', e);
                }
            }
        } catch (e) {
            console.error('Failed to set marker position - location may not be prefilled correctly:', e);
            showToast('Warning: Could not set location marker', 'info');
        }
    }, 100);
    
    // Hide the location info box
    hideLocationInfoBox();
}

/**
 * Handle form submission
 * @param {Event} e - Submit event
 */
async function handleFormSubmit(e) {
    e.preventDefault();
    
    if (!isAuthenticated()) {
        showToast('Please sign in to submit', 'error');
        return;
    }
    
    // Get form data
    const formEl = e.target || document.getElementById('item-form');
    if (!formEl) {
        showToast('Form element not found', 'error');
        return;
    }
    const formData = new FormData(formEl);
    
    const itemData = {
        Title: formData.get('Title'),
        EventCausedDamage: formData.get('EventCausedDamage'),
        MoreInformation: formData.get('MoreInformation'),
        ContactName: formData.get('ContactName'),
        ContactPhoneNumber: formData.get('ContactPhoneNumber'),
        ImmediateNeedsRequired: document.getElementById('immediate-needs').checked,
        Status: formData.get('Status'),
        Priority: formData.get('Priority') || (document.getElementById('immediate-needs').checked ? 'High' : 'Medium'),
        latitude: parseFloat(formData.get('latitude')) || null,
        longitude: parseFloat(formData.get('longitude')) || null,
        sourceId: formData.get('sourceId') || 'default'  // Get selected source
    };
    
    // If editing, preserve the source information
    if (isEditing && editingItemId) {
        // Find the item being edited to get its source info
        const editingItem = items.find(item => item.id == editingItemId);
        if (editingItem) {
            itemData.sourceId = editingItem.sourceId || editingItem._sourceId || 'default';
        }
    }

    // If the user selected a place via the geocoder, include richer address info
    try {
        const g = window.lastGeocoderResult;
        if (g && g.place_name) {
            itemData.locationDisplayName = g.place_name;
            itemData.locationUri = g.properties && g.properties.wikidata ? g.properties.wikidata : (g.id || '');
            // Attempt to construct an address object from the geocoder context
            const address = {};
            if (g.context && Array.isArray(g.context)) {
                g.context.forEach(c => {
                    if (c.id && c.id.startsWith('place')) address.City = c.text;
                    if (c.id && c.id.startsWith('region')) address.State = c.text;
                    if (c.id && c.id.startsWith('country')) address.CountryOrRegion = c.text;
                    if (c.id && c.id.startsWith('postcode')) address.PostalCode = c.text;
                });
            }
            // If feature has address fields, include street
            if (g.properties && g.properties.address) address.Street = g.properties.address;
            itemData.address = address;
        }
    } catch (e) {
        // ignore geocoder extraction errors
    }
    
    // Validate required fields
    if (!itemData.Title || !itemData.EventCausedDamage || !itemData.ContactName || !itemData.ContactPhoneNumber) {
        showToast('Please fill in all required fields', 'error');
        return;
    }
    
    // Validate coordinates
    if (!itemData.latitude || !itemData.longitude) {
        showToast('Please select a location on the map', 'error');
        return;
    }
    
    // Show loading state
    const submitBtn = document.getElementById('submit-btn');
    if (submitBtn) submitBtn.disabled = true;
    const submitTextEl2 = document.getElementById('submit-text'); if (submitTextEl2) submitTextEl2.style.display = 'none';
    const submitLoadingEl = document.getElementById('submit-loading'); if (submitLoadingEl) submitLoadingEl.style.display = 'inline';
    
    try {
        if (isEditing) {
            await updateItem(editingItemId, itemData);
        } else {
            await createItem(itemData);
        }
        
        // Reload items
        await loadItems();
        
        // Close panel
        closePanel();
    } catch (error) {
        console.error('Form submission failed:', error);
        showToast('Failed to save item: ' + error.message, 'error');
    } finally {
        // Reset loading state
        if (submitBtn) submitBtn.disabled = false;
        if (submitTextEl2) submitTextEl2.style.display = 'inline';
        if (submitLoadingEl) submitLoadingEl.style.display = 'none';
    }
}

/**
 * Adapt UI for Teams context
 */
function adaptUIForTeams() {
    try {
        const authBar = document.getElementById('auth-bar');
        if (authBar) authBar.style.display = 'none';

        const mapEl = document.getElementById('map');
        if (mapEl) mapEl.style.top = '0';

        // Adjust side panel height
        const panel = document.getElementById('side-panel');
        if (panel) {
            panel.style.top = '0';
            panel.style.height = '100vh';
        }
    } catch (e) {
        // ignore
    }
}

/**
 * Show/hide loading overlay
 * @param {boolean} show - Whether to show loading
 * @param {string} message - Optional loading message
 */
function showLoading(show, message = 'Loading...') {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.style.display = show ? 'flex' : 'none';
        const text = overlay.querySelector('p');
        if (text && message) {
            text.textContent = message;
        }
    }
}

/**
 * Show toast notification
 * @param {string} message - Toast message
 * @param {string} type - Toast type (success, error, info)
 */
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ'
    };
    
    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || icons.info}</span>
        <span class="toast-message">${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            container.removeChild(toast);
        }, 300);
    }, 5000);
}

// Initialize app when window fully loads (ensures all external scripts are loaded)
if (document.readyState === 'complete') {
    initApp();
} else {
    window.addEventListener('load', initApp);
}
