const { app } = require('@azure/functions');

/**
 * Health check endpoint for monitoring
 * Returns basic health status and version info
 */
app.http('health', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'health',
    handler: async (request, context) => {
        return {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            },
            jsonBody: {
                status: 'healthy',
                version: '1.0.0',
                timestamp: new Date().toISOString(),
                features: {
                    webInterface: true,
                    teamsIntegration: true,
                    mapboxMaps: true,
                    entraAuth: true
                }
            }
        };
    }
});
