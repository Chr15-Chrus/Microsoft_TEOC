const { app } = require('@azure/functions');
const { getDataSourcesTableClient } = require('../utils/data-sources');

/**
 * Get all registered data sources
 */
app.http('getSources', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'getSources',
    handler: async (request, context) => {
        context.log('getSources function called');

        try {
            const tableClient = await getDataSourcesTableClient(context);

            const sources = [];
            const entities = tableClient.listEntities({
                queryOptions: { filter: `PartitionKey eq 'source'` }
            });

            for await (const entity of entities) {
                sources.push({
                    id: entity.rowKey,
                    type: entity.type,
                    name: entity.name,
                    description: entity.description,
                    active: entity.active,
                    createdDate: entity.createdDate,
                    webhookUrl: entity.webhookUrl,
                    webhookExpiration: entity.webhookExpiration
                });
            }

            // Sort by created date (newest first)
            sources.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));

            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                jsonBody: sources
            };
        } catch (error) {
            context.error('Error fetching sources:', error);
            return {
                status: 500,
                jsonBody: { error: 'Failed to fetch sources', message: error.message }
            };
        }
    }
});
