const { app } = require('@azure/functions');
const { requireAuth } = require('../utils/auth-middleware');
const { forwardGeocode } = require('../utils/mapbox-geocoding');

/**
 * Geocode an address to coordinates using Mapbox API
 * This supports searching for locations to validate for SharePoint's structured Location field
 */
app.http('geocode', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'geocode',
    handler: async (request, context) => {
        try {
            // Verify user authentication
            const user = await requireAuth(request);
            if (!user) {
                return {
                    status: 401,
                    jsonBody: {
                        error: 'Unauthorized',
                        message: 'Valid authentication token required'
                    }
                };
            }
            
            context.log('Geocoding for user:', user.email);
            
            // Parse request body
            const { address } = await request.json();
            
            if (!address) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Address is required'
                    }
                };
            }
            
            const result = await forwardGeocode(address, { optional: false, context });

            if (!result) {
                return {
                    status: 404,
                    jsonBody: {
                        error: 'Not Found',
                        message: 'No coordinates found for the provided address'
                    }
                };
            }

            context.log('Geocoding successful:', result.displayName);

            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json'
                },
                jsonBody: result
            };
        } catch (error) {
            context.error('Error in geocoding:', error);
            
            if (error.message === 'Invalid Mapbox API key' || error.response?.status === 401) {
                return {
                    status: 401,
                    jsonBody: {
                        error: 'Unauthorized',
                        message: 'Invalid Mapbox API key'
                    }
                };
            }

            if (error.message === 'Mapbox API key not configured') {
                return {
                    status: 500,
                    jsonBody: {
                        error: 'Configuration Error',
                        message: error.message
                    }
                };
            }
            
            return {
                status: 500,
                jsonBody: {
                    error: 'Geocoding failed',
                    message: error.message
                }
            };
        }
    }
});
