const { app } = require('@azure/functions');

/**
 * Simple endpoint to test bot is receiving messages
 * and help diagnose conversation ID issues
 */
app.http('getBotInfo', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        try {
            const body = await request.text();
            
            // Log everything we receive
            console.log('=== BOT INFO DEBUG ===');
            console.log('Headers:', JSON.stringify(Object.fromEntries(request.headers), null, 2));
            console.log('Body:', body);
            
            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: 'Bot endpoint is working',
                    timestamp: new Date().toISOString(),
                    receivedBody: body ? JSON.parse(body) : null
                }, null, 2)
            };
        } catch (error) {
            console.error('Error:', error);
            return {
                status: 500,
                body: JSON.stringify({ error: error.message })
            };
        }
    }
});
