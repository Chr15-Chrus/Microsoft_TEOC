const { app } = require('@azure/functions');
const axios = require('axios');
const { getUserGraphToken } = require('../utils/sharepoint-auth');
const { requireAuth } = require('../utils/auth-middleware');
const { validateAndParseCoordinates, formatLocationForSharePoint } = require('../utils/coordinate-utils');
const { getSourceById, DEFAULT_SOURCE_ID } = require('../utils/data-sources');

/**
 * Update an existing item in a data source
 * Accepts partial item data including updated coordinates and source information
 */
app.http('updateItem', {
    methods: ['PATCH'],
    authLevel: 'anonymous',
    route: 'updateItem/{itemId}',
    handler: async (request, context) => {
        try {
            // Verify user authentication (allow LOCAL_DEBUG bypass)
            let user, userToken;
            if (process.env.LOCAL_DEBUG === 'true') {
                // Safety check: prevent LOCAL_DEBUG in production
                if (process.env.NODE_ENV === 'production' || process.env.AZURE_FUNCTIONS_ENVIRONMENT === 'Production') {
                    context.error('LOCAL_DEBUG is enabled in production environment - this is a security risk!');
                    return {
                        status: 500,
                        jsonBody: {
                            error: 'Configuration Error',
                            message: 'Invalid debug configuration'
                        }
                    };
                }
                user = { email: 'local@dev' };
                userToken = null;
                context.log('LOCAL_DEBUG enabled — bypassing auth as', user.email);
            } else {
                user = await requireAuth(request);
                if (!user) {
                    return {
                        status: 401,
                        jsonBody: {
                            error: 'Unauthorized',
                            message: 'Valid authentication token required'
                        }
                    };
                }
                userToken = request.headers.get('authorization');
            }

            context.log('Updating item for user:', user.email);
            
            // Get item ID from route
            const itemId = request.params.itemId;
            if (!itemId) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Item ID is required'
                    }
                };
            }
            
            // Parse request body
            const itemData = await request.json();
            context.log('updateItem payload:', itemData);
            
            // Determine source
            const sourceId = itemData.sourceId || itemData._sourceId || DEFAULT_SOURCE_ID;
            context.log('Updating item in source:', sourceId);
            
            // Get source configuration from Table Storage
            let siteUrl, listId;
            try {
                const source = await getSourceById(sourceId, context);
                if (!source || source.active === false) {
                    return {
                        status: 400,
                        jsonBody: {
                            error: 'Bad Request',
                            message: 'Invalid or inactive source. Ensure the source exists and is active in Table Storage.'
                        }
                    };
                }

                if (source.type !== 'sharepoint') {
                    return {
                        status: 400,
                        jsonBody: {
                            error: 'Bad Request',
                            message: 'Only SharePoint sources support direct item updates'
                        }
                    };
                }

                siteUrl = source.siteUrl;
                listId = source.listId;
                context.log('Resolved source from DataSources:', source.rowKey);
            } catch (error) {
                context.error('Failed to load source configuration:', error.message);
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Unable to load source configuration. Ensure the source exists in Table Storage.'
                    }
                };
            }
            
            if (!siteUrl || !listId) {
                throw new Error('SharePoint configuration not complete');
            }
            
            // Get SharePoint access token using user's context
            let accessToken;
            if (userToken && process.env.LOCAL_DEBUG !== 'true') {
                try {
                    accessToken = await getUserGraphToken(userToken);
                    context.log('Using user-delegated Graph token for item update');
                } catch (error) {
                    context.error('Failed to get user Graph token:', error.message);
                    return {
                        status: 403,
                        jsonBody: {
                            error: 'Forbidden',
                            message: 'Unable to authenticate with SharePoint using your credentials'
                        }
                    };
                }
            } else {
                // LOCAL_DEBUG mode - use app-only token
                (context.warn ?? context.log).call(context, 'Using app-only token (LOCAL_DEBUG mode)');
                const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
                accessToken = await getSharePointAccessToken();
            }
            
            // Build Graph API URL
            const u = new URL(siteUrl);
            const hostname = u.hostname;
            const pathParts = u.pathname.split('/').filter(Boolean);
            const siteName = pathParts.length > 1 ? pathParts[pathParts.length - 1] : pathParts[0] || '';

            const graphUrl = `https://graph.microsoft.com/v1.0/sites/${hostname}:/sites/${siteName}:/lists/${listId}/items/${itemId}/fields`;
            
            // Prepare item fields (only include fields that are provided)
            const fields = {};

            const mapField = (clientName, spName) => {
                if (itemData[clientName] !== undefined) fields[spName || clientName] = itemData[clientName];
            };

            mapField('Title', 'Title');
            mapField('ContactName', 'Contact_x0020_Name');
            mapField('ContactPhoneNumber', 'ContactPhoneNumber');
            mapField('EventCausedDamage', 'EventCausedDamage');
            mapField('MoreInformation', 'MoreInformation');
            mapField('ImmediateNeedsRequired', 'ImmediateNeedsRequired');
            mapField('Status', 'Status');
            mapField('Priority', 'Priority');
            mapField('Acknowledged', 'Acknowledged');

            // Handle coordinates
            const coordinates = validateAndParseCoordinates(itemData);
            if (coordinates) {
                const { lat, lng } = coordinates;
                context.log('updateItem coordinates:', { lat, lng });
                fields.latitude = lat;
                fields.longitude = lng;
            }
            
            if (Object.keys(fields).length === 0) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'No fields to update'
                    }
                };
            }
            
            context.log('Updating item in SharePoint:', itemId, fields);
            
            // Update item in SharePoint
            const response = await axios.patch(graphUrl, fields, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });
            
            context.log('Item updated successfully:', itemId);
            
            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json'
                },
                jsonBody: {
                    success: true,
                    id: itemId,
                    sourceId: sourceId,
                    item: response.data
                }
            };
        } catch (error) {
            context.error('Error updating item:', error);
            context.error('Graph error body:', error.response?.data || error.response || null);

            if (error.response?.status === 403 || error.response?.status === 401) {
                return {
                    status: 403,
                    jsonBody: {
                        error: 'Forbidden',
                        message: 'You do not have permission to edit this item'
                    }
                };
            }

            if (error.response?.status === 404) {
                return {
                    status: 404,
                    jsonBody: {
                        error: 'Not Found',
                        message: 'Item not found'
                    }
                };
            }

            if (error.response?.status === 400) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: error.response.data?.error?.message || 'Invalid item data',
                        graphError: error.response.data || null
                    }
                };
            }

            return {
                status: error.response?.status || 500,
                jsonBody: {
                    error: 'Failed to update item',
                    message: error.message,
                    graphError: error.response?.data || null
                }
            };
        }
    }
});
