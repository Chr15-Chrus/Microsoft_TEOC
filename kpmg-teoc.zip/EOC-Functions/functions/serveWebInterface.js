const { app } = require('@azure/functions');
const fs = require('fs').promises;
const path = require('path');

// Teams iframe embedding header - allows Microsoft Teams to embed this page
const TEAMS_FRAME_CSP = "frame-ancestors 'self' https://teams.microsoft.com https://*.teams.microsoft.com https://*.microsoft.com https://*.cloud.microsoft https://*.office.com https://*.sharepoint.com https://*.officeppe.com";

/**
 * Serve the web interface files
 * This function serves static HTML, CSS, JS, and other assets for the web UI
 */
app.http('serveWebInterface', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'web/{*file}',
    handler: async (request, context) => {
        try {
            // If the request was to `/web` (no trailing slash) the browser
            // will resolve relative asset paths against the site root
            // (resulting in requests like `/js/app.js`), so redirect to
            // `/web/` which preserves the expected relative path (`/web/js/...`).
            // Normalize request URL to a pathname. The Functions runtime may
            // provide `request.url` as a full URL or as a path; handle both. 
            let requestedUrl = '';
            try {
                if (request && request.url) {
                    // If it's a full URL, extract the pathname
                    try {
                        requestedUrl = new URL(String(request.url)).pathname;
                    } catch (e) {
                        requestedUrl = String(request.url);
                    }
                }
            } catch (e) {
                requestedUrl = '';
            }

            context.log(`Requested pathname: ${requestedUrl}`);

            // Redirect `/web` (no trailing slash) to `/web/` to preserve
            // relative paths in the HTML (so assets resolve under `/web/js/...`).
            if (/^\/?web(?:$|[?#])/.test(requestedUrl) && !/^\/?web\//.test(requestedUrl)) {
                context.log('Redirecting /web -> /web/');
                return {
                    status: 301,
                    headers: { 
                        Location: '/web/',
                        'Content-Security-Policy': TEAMS_FRAME_CSP
                    },
                    body: ''
                };
            }

            const file = request.params.file || 'index.html';
            
            context.log(`Serving file: ${file}`);
            
            // Security: prevent directory traversal
            if (file.includes('.. ') || file.includes('~')) {
                context.warn(`Forbidden file access attempt: ${file}`);
                return {
                    status: 403,
                    headers: {
                        'Content-Security-Policy': TEAMS_FRAME_CSP
                    },
                    body:  'Forbidden'
                };
            }
            
            // Determine file path. In this repo the `web` folder lives at the
            // repository root (../../web relative to this file) but during
            // some packaging strategies it may be placed at ../web. Check both
            // locations so the function works both locally and when the
            // deployed package contains the web folder in either location.
            const candidates = [
                path.join(__dirname, '..', '..', 'web'), // repo root (local dev)
                path.join(__dirname, '..', 'web'),        // packaged alongside functions
                path.join(__dirname, 'web')               // web copied into functions package
            ];

            let webRoot = null;
            for (const candidate of candidates) {
                try {
                    const stats = await fs.stat(candidate);
                    if (!stats.isDirectory()) {
                        continue;
                    }

                    // Ensure the candidate actually contains index.html.  This prevents
                    // partial directories (e.g., leftover css-only folders) from being
                    // selected as the root and breaking page loads.
                    await fs.access(path.join(candidate, 'index.html'));
                    webRoot = candidate;
                    break;
                } catch (err) {
                    // ignore this candidate and continue
                }
            }

            if (!webRoot) {
                context.log(`Web root not found in expected locations: ${candidates.join(', ')}`);
                // Fall back to repo root to keep behavior consistent with previous versions.
                webRoot = candidates[0];
            }

            let filePath = path.resolve(webRoot, file);
            
            context.log(`Web root: ${webRoot}`);
            context.log(`Resolved file path: ${filePath}`);
            
            // Default to index.html for directory requests
            try {
                const stats = await fs.stat(filePath);
                if (stats.isDirectory()) {
                    filePath = path.join(filePath, 'index.html');
                    context.log(`Directory detected, serving: ${filePath}`);
                }
            } catch (err) {
                // File doesn't exist, continue to 404 below
                context.log(`File stat failed: ${err.message}`);
            }
            
            // Read file
            try {
                // Read text files with utf8 so relative paths resolve correctly
                const ext = path.extname(filePath).toLowerCase();
                const readOptions = ['.html', '.css', '.js', '.json'].includes(ext) ? 'utf8' : null;
                const content = await fs.readFile(filePath, readOptions);
                
                // Determine content type
                // ext already computed above for readOptions
                const contentTypes = {
                    '.html': 'text/html',
                    '.css': 'text/css',
                    '.js': 'application/javascript',
                    '.json': 'application/json',
                    '.png': 'image/png',
                    '.jpg': 'image/jpeg',
                    '.jpeg': 'image/jpeg',
                    '.gif': 'image/gif',
                    '.svg': 'image/svg+xml',
                    '.ico': 'image/x-icon',
                    '.woff': 'font/woff',
                    '.woff2': 'font/woff2',
                    '.ttf': 'font/ttf'
                };
                
                const contentType = contentTypes[ext] || 'application/octet-stream';
                
                context.log(`Successfully serving ${file} as ${contentType}`);
                
                return {
                    status: 200,
                    headers: {
                        'Content-Type': contentType,
                        'Cache-Control': ext === '. html' ? 'no-cache' : 'public, max-age=31536000',
                        'Cross-Origin-Opener-Policy': 'same-origin-allow-popups',
                        'Cross-Origin-Embedder-Policy': 'unsafe-none',
                        // Allow Microsoft Teams to embed this page in an iframe
                        'Content-Security-Policy':  TEAMS_FRAME_CSP
                    },
                    body:  content
                };
            } catch (err) {
                context. error('File not found:', filePath, err.message);
                return {
                    status: 404,
                    headers: { 
                        'Content-Type':  'text/plain',
                        'Content-Security-Policy':  TEAMS_FRAME_CSP
                    },
                    body: 'File not found'
                };
            }
        } catch (error) {
            context.error('Error serving web interface:', error);
            return {
                status: 500,
                headers: { 
                    'Content-Type': 'text/plain',
                    'Content-Security-Policy': TEAMS_FRAME_CSP
                },
                body: 'Internal server error'
            };
        }
    }
});