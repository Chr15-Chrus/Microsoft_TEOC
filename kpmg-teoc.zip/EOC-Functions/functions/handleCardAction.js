const { app } = require('@azure/functions');
const axios = require('axios');
const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Updates SharePoint list item
 * @param {string} siteUrl - SharePoint site URL
 * @param {string} listId - List GUID
 * @param {number} itemId - Item ID
 * @param {Object} updates - Fields to update
 * @param {string} accessToken - SharePoint access token
 * @returns {Promise<Object>} Updated item
 */
async function updateSharePointItem(siteUrl, listId, itemId, updates, accessToken) {
    const apiUrl = `${siteUrl}/_api/web/lists(guid'${listId}')/items(${itemId})`;

    // Get item etag first
    const getResponse = await axios.get(apiUrl, {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json;odata=verbose'
        }
    });

    const etag = getResponse.data.d.__metadata.etag;

    // Update the item
    const updateResponse = await axios.post(
        apiUrl,
        {
            __metadata: { type: getResponse.data.d.__metadata.type },
            ...updates
        },
        {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'IF-MATCH': etag,
                'X-HTTP-Method': 'MERGE'
            }
        }
    );

    // Fetch updated item
    const updatedResponse = await axios.get(apiUrl, {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json;odata=verbose'
        }
    });

    return updatedResponse.data.d;
}

/**
 * Creates an updated adaptive card with new status
 * @param {Object} assessment - Updated assessment data
 * @param {string} action - Action that was performed
 * @param {string} userEmail - Email of user who performed action
 * @returns {Object} Updated adaptive card
 */
function createUpdatedCard(assessment, action, userEmail) {
    const locationData = assessment.Location ? JSON.parse(assessment.Location) : {};
    const displayName = locationData.DisplayName || 'Unknown Location';
    const address = locationData.Address || {};
    const locationString = [address.City, address.State, address.CountryOrRegion]
        .filter(x => x)
        .join(', ') || displayName;

    let statusEmoji = '🔵';
    let statusText = assessment.Status || 'New';
    
    if (action === 'acknowledge') {
        statusEmoji = '✅';
        statusText = `Acknowledged by ${userEmail}`;
    } else if (action === 'escalate') {
        statusEmoji = '⚠️';
        statusText = 'ESCALATED';
    } else if (action === 'resolve') {
        statusEmoji = '✔️';
        statusText = 'COMPLETED';
    }

    return {
        type: "message",
        attachments: [
            {
                contentType: "application/vnd.microsoft.card.adaptive",
                contentUrl: null,
                content: {
                    $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
                    type: "AdaptiveCard",
                    version: "1.4",
                    body: [
                        {
                            type: "TextBlock",
                            text: `${statusEmoji} TEOC Assessment - ${statusText}`,
                            weight: "Bolder",
                            size: "Large",
                            color: action === 'resolve' ? 'Good' : (action === 'escalate' ? 'Attention' : 'Default')
                        },
                        {
                            type: "TextBlock",
                            text: assessment.Title || "Untitled Assessment",
                            weight: "Bolder",
                            size: "Medium",
                            wrap: true
                        },
                        {
                            type: "FactSet",
                            facts: [
                                {
                                    title: "Contact:",
                                    value: `${assessment.Contact_x0020_Name || 'N/A'} (${assessment.ContactPhoneNumber || 'No phone'})`
                                },
                                {
                                    title: "Location:",
                                    value: locationString
                                },
                                {
                                    title: "Event Type:",
                                    value: assessment.EventCausedDamage || 'Not specified'
                                },
                                {
                                    title: "Immediate Needs:",
                                    value: assessment.ImmediateNeedsRequired ? "⚠️ YES" : "No"
                                },
                                {
                                    title: "Status:",
                                    value: assessment.Status || 'New'
                                },
                                {
                                    title: "Acknowledged By:",
                                    value: assessment.Acknowledged || 'Not acknowledged'
                                }
                            ]
                        },
                        {
                            type: "TextBlock",
                            text: "**Additional Information:**",
                            weight: "Bolder",
                            spacing: "Medium",
                            isVisible: !!assessment.MoreInformation
                        },
                        {
                            type: "TextBlock",
                            text: assessment.MoreInformation || '',
                            wrap: true,
                            isVisible: !!assessment.MoreInformation
                        },
                        {
                            type: "Container",
                            style: action === 'resolve' ? 'good' : (action === 'escalate' ? 'attention' : 'emphasis'),
                            items: [
                                {
                                    type: "TextBlock",
                                    text: `Action completed: ${action.toUpperCase()}`,
                                    weight: "Bolder",
                                    color: action === 'resolve' ? 'Good' : (action === 'escalate' ? 'Attention' : 'Accent')
                                },
                                {
                                    type: "TextBlock",
                                    text: `Updated at ${new Date().toLocaleString()}`,
                                    spacing: "Small",
                                    isSubtle: true
                                }
                            ],
                            spacing: "Medium"
                        }
                    ],
                    actions: action === 'resolve' ? [] : [
                        // Show remaining actions based on current state
                        ...(action !== 'acknowledge' ? [{
                            type: "Action.Http",
                            title: "✅ Acknowledge",
                            method: "POST",
                            url: `${process.env.FUNCTION_BASE_URL}/api/handleCardAction`,
                            body: JSON.stringify({
                                action: "acknowledge",
                                itemId: assessment.ID,
                                listId: assessment.ListId,
                                siteUrl: assessment.SiteUrl
                            })
                        }] : []),
                        ...(action !== 'escalate' ? [{
                            type: "Action.Http",
                            title: "⚠️ Escalate",
                            method: "POST",
                            url: `${process.env.FUNCTION_BASE_URL}/api/handleCardAction`,
                            body: JSON.stringify({
                                action: "escalate",
                                itemId: assessment.ID,
                                listId: assessment.ListId,
                                siteUrl: assessment.SiteUrl
                            })
                        }] : []),
                        {
                            type: "Action.Http",
                            title: "✔️ Resolve",
                            method: "POST",
                            url: `${process.env.FUNCTION_BASE_URL}/api/handleCardAction`,
                            body: JSON.stringify({
                                action: "resolve",
                                itemId: assessment.ID,
                                listId: assessment.ListId,
                                siteUrl: assessment.SiteUrl
                            })
                        }
                    ]
                }
            }
        ]
    };
}

/**
 * Posts updated card to Teams (replaces the original)
 * Note: This requires the card to be posted with an activity ID initially
 * For demo purposes, this posts a new message
 * @param {Object} card - Updated adaptive card
 */
async function updateTeamsCard(card) {
    const webhookUrl = await getSecretValue('TEAMS_WEBHOOK_URL', { optional: true });
    
    if (!webhookUrl) {
        throw new Error('TEAMS_WEBHOOK_URL not configured');
    }

    // For demo, we post a new card. In production, you'd use Graph API to update the original
    await axios.post(webhookUrl, card, {
        headers: { 'Content-Type': 'application/json' }
    });
}

/**
 * Azure Function: Handle Card Action
 * Triggered when user clicks a button on the adaptive card
 */
app.http('handleCardAction', {
    methods: ['POST'],
    authLevel: 'function',
    handler: async (request, context) => {
        try {
            context.log('Processing card action...');

            const body = await request.json();
            const { action, itemId, listId, siteUrl } = body;

            // Get user information from request
            const userEmail = body.userEmail || `Acknowledged at ${new Date().toISOString()}`;

            context.log(`Action: ${action}, Item: ${itemId}, User: ${userEmail}`);

            // Validate input
            if (!action || !itemId || !listId || !siteUrl) {
                return {
                    status: 400,
                    body: JSON.stringify({ error: 'Missing required parameters' })
                };
            }

            // Get SharePoint access token
            context.log('Getting SharePoint access token...');
            const accessToken = await getSharePointAccessToken();

            // Prepare updates based on action
            let updates = {};
            
            switch (action) {
                case 'acknowledge':
                    // For SharePoint Person/User field, just use the email
                    // SharePoint REST API will accept email and resolve to user ID
                    updates = {
                        Acknowledged: userEmail
                    };
                    break;
                
                case 'escalate':
                    updates = {
                        ImmediateNeedsRequired: true,
                        Status: 'Pending'
                    };
                    break;
                
                case 'resolve':
                    updates = {
                        Status: 'Completed'
                    };
                    break;
                
                default:
                    return {
                        status: 400,
                        body: JSON.stringify({ error: 'Invalid action' })
                    };
            }

            // Update SharePoint item
            context.log('Updating SharePoint item...');
            const updatedItem = await updateSharePointItem(
                siteUrl,
                listId,
                itemId,
                updates,
                accessToken
            );

            // Create updated card
            context.log('Creating updated card...');
            updatedItem.SiteUrl = siteUrl;
            updatedItem.ListId = listId;
            const updatedCard = createUpdatedCard(updatedItem, action, userEmail);

            // Post updated card to Teams
            context.log('Posting updated card to Teams...');
            await updateTeamsCard(updatedCard);

            context.log(`Successfully completed ${action} action`);

            return {
                status: 200,
                body: JSON.stringify({ 
                    success: true,
                    action: action,
                    message: `Assessment ${action} completed successfully`
                })
            };

        } catch (error) {
            context.error('Error handling card action:', error);
            return {
                status: 500,
                body: JSON.stringify({ 
                    error: 'Failed to process action',
                    details: error.message 
                })
            };
        }
    }
});
