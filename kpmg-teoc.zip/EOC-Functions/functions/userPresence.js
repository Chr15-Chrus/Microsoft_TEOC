const { app } = require('@azure/functions');
const { TableClient } = require('@azure/data-tables');
const { resolveStorageConnectionString } = require('../utils/data-sources');

/**
 * User presence tracking using Azure Table Storage
 * Provides shared state across all function instances for real-time sync
 */

// Azure Table Storage client for presence data
let tableClientPromise;

/**
 * Initialize Table Storage client (lazy initialization)
 */
async function getTableClient() {
    if (tableClientPromise) {
        return tableClientPromise;
    }

    tableClientPromise = (async () => {
        const connectionString = await resolveStorageConnectionString();
        const client = TableClient.fromConnectionString(connectionString, 'UserPresence');
        await client.createTable().catch(() => {}); // Ignore if already exists
        return client;
    })();

    try {
        const client = await tableClientPromise;
        return client;
    } catch (error) {
        tableClientPromise = null;
        throw error;
    }
}

app.http('userPresence', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    route: 'presence',
    handler: async (request, context) => {
        const action = request.query.get('action') || 'connect';
        
        context.log(`[userPresence] action: ${action}, method: ${request.method}`);
        
        try {
            // Get user from auth header
            const authHeader = request.headers.get('authorization');
            if (!authHeader || !authHeader.startsWith('Bearer ')) {
                return {
                    status: 401,
                    jsonBody: {
                        error: 'Unauthorized',
                        message: 'Valid authentication token required'
                    }
                };
            }
            
            // Parse user info from token (simplified - in production use full JWT validation)
            const token = authHeader.replace('Bearer ', '');
            const userInfo = await getUserFromToken(token);
            
            if (!userInfo) {
                return {
                    status: 401,
                    jsonBody: { error: 'Invalid token' }
                };
            }
            
            const userId = userInfo.id || userInfo.email;
            const table = await getTableClient();
            
            context.log(`[userPresence] Processing action '${action}' for user: ${userId}`);
            
            switch (action) {
                case 'connect':
                    // User connected - add to presence list in Table Storage
                    const body = await request.json().catch(() => ({}));
                    // Validate initial location data using proper type checks to allow 0 values
                    const initialLocation = validateCoordinates(body.latitude, body.longitude) ? {
                        latitude: body.latitude,
                        longitude: body.longitude
                    } : null;
                    
                    const userEntity = {
                        partitionKey: 'presence',
                        rowKey: userId,
                        id: userId,
                        name: userInfo.name || '',
                        email: userInfo.email || '',
                        connectedAt: new Date().toISOString(),
                        lastSeen: new Date().toISOString()
                    };
                    
                    // Only include latitude/longitude if they have valid values
                    // Azure Table Storage doesn't handle null well, so we omit the properties instead
                    if (initialLocation) {
                        userEntity.latitude = initialLocation.latitude;
                        userEntity.longitude = initialLocation.longitude;
                    }
                    
                    // Include phone number if available
                    if (userInfo.phone) {
                        userEntity.phone = userInfo.phone;
                    }
                    
                    // Use Replace to ensure the row is overwritten each time
                    await table.upsertEntity(userEntity, 'Replace');
                    context.log(`[userPresence] User connected: ${userId}`);
                    
                    // Return all active users
                    const allUsers = await getAllActiveUsers(table, context);
                    return {
                        status: 200,
                        jsonBody: {
                            success: true,
                            userId: userId,
                            users: allUsers
                        }
                    };
                
                case 'update':
                    // Update user location in Table Storage
                    const payload = await request.json().catch(() => ({}));
                    const { latitude, longitude } = payload;
                    
                    // Validate that latitude and longitude are valid numbers
                    // Use validateCoordinates to allow 0 values (equator/prime meridian)
                    if (!validateCoordinates(latitude, longitude)) {
                        context.log(`[userPresence] Invalid location data: lat=${latitude} (${typeof latitude}), lng=${longitude} (${typeof longitude})`);
                        return {
                            status: 400,
                            jsonBody: { error: 'Valid latitude and longitude numbers required' }
                        };
                    }
                    
                    context.log(`[userPresence] Updating location for ${userId}: lat=${latitude}, lng=${longitude}`);
                    
                    // Get existing entity and update
                    try {
                        const existing = await table.getEntity('presence', userId);
                        // Build a full entity preserving connectedAt and name/email/phone
                        const updatedEntity = {
                            partitionKey: 'presence',
                            rowKey: userId,
                            id: userId,
                            name: existing.name || userInfo.name || '',
                            email: existing.email || userInfo.email || '',
                            connectedAt: existing.connectedAt || new Date().toISOString(),
                            lastSeen: new Date().toISOString(),
                            latitude: latitude,
                            longitude: longitude
                        };
                        // Preserve phone if it exists
                        if (existing.phone || userInfo.phone) {
                            updatedEntity.phone = existing.phone || userInfo.phone;
                        }
                        // Replace the entity so latitude/longitude are overwritten (no running log)
                        await table.upsertEntity(updatedEntity, 'Replace');
                        context.log(`[userPresence] Location updated (replace) for ${userId}: ${latitude}, ${longitude}`);
                    } catch (err) {
                        // If entity doesn't exist, create it (single row)
                        const newEntity = {
                            partitionKey: 'presence',
                            rowKey: userId,
                            id: userId,
                            name: userInfo.name || '',
                            email: userInfo.email || '',
                            connectedAt: new Date().toISOString(),
                            lastSeen: new Date().toISOString(),
                            latitude: latitude,
                            longitude: longitude
                        };
                        // Include phone if available
                        if (userInfo.phone) {
                            newEntity.phone = userInfo.phone;
                        }
                        await table.upsertEntity(newEntity, 'Replace');
                        context.log(`[userPresence] Created new entity (replace) for ${userId}`);
                    }
                    
                    const allUsersAfterUpdate = await getAllActiveUsers(table, context);
                    return {
                        status: 200,
                        jsonBody: {
                            success: true,
                            users: allUsersAfterUpdate
                        }
                    };
                
                case 'list':
                    // Get all connected users from Table Storage
                    // Clean up stale connections (older than 5 minutes)
                    const activeUsers = await getAllActiveUsers(table, context);
                    
                    return {
                        status: 200,
                        jsonBody: {
                            users: activeUsers
                        }
                    };
                
                case 'disconnect':
                    // User disconnected - remove from presence list
                    try {
                        await table.deleteEntity('presence', userId);
                        context.log(`[userPresence] User disconnected: ${userId}`);
                    } catch (err) {
                        context.warn(`[userPresence] Failed to delete entity ${userId}:`, err.message);
                    }
                    
                    const remainingUsers = await getAllActiveUsers(table, context);
                    return {
                        status: 200,
                        jsonBody: {
                            success: true,
                            users: remainingUsers
                        }
                    };
                
                default:
                    return {
                        status: 400,
                        jsonBody: { error: 'Invalid action' }
                    };
            }
        } catch (error) {
            context.error('Error in user presence handler:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Internal server error',
                    message: error.message
                }
            };
        }
    }
});

/**
 * Get all active users from Table Storage and clean up stale entries
 * @param {TableClient} table - Table Storage client
 * @param {InvocationContext} context - Function context for logging
 * @returns {Array} Array of active user objects
 */
async function getAllActiveUsers(table, context) {
    const activeUsers = [];
    const now = new Date();
    const staleThreshold = 60 * 60 * 1000; // 60 minutes
    
    try {
        // Query all entities in the 'presence' partition
        const entities = table.listEntities({ queryOptions: { filter: "PartitionKey eq 'presence'" } });
        
        for await (const entity of entities) {
            const lastSeen = new Date(entity.lastSeen);
            const age = now - lastSeen;
            
            // Delete stale entries (older than 60 minutes)
            if (age > staleThreshold) {
                context.log(`[getAllActiveUsers] Removing stale user: ${entity.rowKey} (${Math.round(age/60000)} minutes old)`);
                await table.deleteEntity('presence', entity.rowKey).catch(err => {
                    context.warn(`[getAllActiveUsers] Failed to delete stale entity:`, err.message);
                });
                continue;
            }
            
            // Add active user to result
            // Azure Table Storage may not return properties with null values, so check if properties exist
            // and are valid numbers (not null, undefined, or falsy). Latitude can be 0 (equator), so use
            // type checking instead of truthy checks.
            const hasValidLocation = validateCoordinates(entity.latitude, entity.longitude);
            
            const user = {
                id: entity.id || entity.rowKey,
                name: entity.name,
                email: entity.email,
                phone: entity.phone || null,
                connectedAt: entity.connectedAt,
                lastSeen: entity.lastSeen,
                location: hasValidLocation ? {
                    latitude: entity.latitude,
                    longitude: entity.longitude
                } : null
            };
            
            activeUsers.push(user);
        }
        
        context.log(`[getAllActiveUsers] Returning ${activeUsers.length} active users`);
    } catch (error) {
        context.error('[getAllActiveUsers] Error querying Table Storage:', error);
    }
    
    return activeUsers;
}

/**
 * Validate that coordinates are valid numbers within acceptable ranges
 * @param {*} latitude - Latitude value to validate (-90 to 90)
 * @param {*} longitude - Longitude value to validate (-180 to 180)
 * @returns {boolean} True if both are valid numbers within acceptable ranges
 */
function validateCoordinates(latitude, longitude) {
    return Number.isFinite(latitude) && 
           Number.isFinite(longitude) &&
           latitude >= -90 && latitude <= 90 &&
           longitude >= -180 && longitude <= 180;
}

/**
 * Extract user info from JWT token (simplified version)
 * In production, use full JWT validation from auth-middleware
 */
async function getUserFromToken(token) {
    try {
        // Decode JWT without verification (for demo - use proper validation in production)
        const parts = token.split('.');
        if (parts.length !== 3) return null;
        
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        
        // Use email/upn as primary ID for consistency with MSAL frontend
        const primaryId = payload.email || payload.preferred_username || payload.upn || payload.oid || payload.sub;
        
        return {
            id: primaryId,
            oid: payload.oid || payload.sub,
            email: payload.email || payload.preferred_username || payload.upn,
            name: payload.name,
            phone: payload.phone_number || payload.mobilePhone || payload.businessPhones?.[0] || null
        };
    } catch (error) {
        return null;
    }
}
