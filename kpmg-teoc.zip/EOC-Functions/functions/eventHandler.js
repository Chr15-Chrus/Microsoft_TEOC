const { app } = require('@azure/functions');
const fetch = require('node-fetch');
const { DefaultAzureCredential } = require('@azure/identity');
const routingService = require('../utils/routing-service');
const { createEventNotificationCard, wrapCardForTeams } = require('../utils/adaptive-card-templates');
const { findSourceByListId } = require('../utils/data-sources');

/**
 * Event Grid triggered function
 * Receives normalized TEOC events, determines routing, and broadcasts via SignalR and Teams
 */
app.eventGrid('eventHandler', {
  handler: async (event, context) => {
    context.log('eventHandler triggered with event:', {
      eventId: event.id,
      eventType: event.eventType || event.type,
      source: event.source
    });

  const signalRBase = process.env.SIGNALR_REST_BASE_URL;
  const hubName = process.env.SIGNALR_HUB_NAME || 'teocHub';

  if (!signalRBase) {
    context.warn('SIGNALR_REST_BASE_URL not configured. Skipping broadcast.');
    return;
  }

  try {
    // Extract event data (CloudEvents format)
    const eventData = event.data || event;
    
    // Log incoming event for debugging
    context.log('Processing event data:', {
      itemId: eventData.itemId,
      title: eventData.title,
      eventType: eventData.eventType,
      priority: eventData.priority,
      location: eventData.location,
      sourceListId: eventData.sourceListId
    });

    // Look up the data source to get Teams webhook URL
    let teamsWebhookUrl = null;
    if (eventData.sourceListId) {
      try {
        const dataSource = await findSourceByListId(eventData.sourceListId, context);
        if (dataSource && dataSource.teamsWebhookUrl) {
          teamsWebhookUrl = dataSource.teamsWebhookUrl;
          context.log(`Found Teams webhook URL for source: ${dataSource.rowKey}`);
        }
      } catch (err) {
        context.warn('Failed to lookup data source for Teams webhook:', err);
      }
    }

    // Determine routing based on configuration
    const routes = await routingService.determineRoutes(eventData);
    
    if (!routes || routes.length === 0) {
      context.warn('No routes determined for event', eventData.itemId);
      return;
    }

    context.log('Routing determined:', {
      itemId: eventData.itemId,
      routeCount: routes.length,
      routes: routes.map(r => ({
        teamId: r.teamId,
        teamName: r.teamName,
        reason: r.reason,
        group: r.signalRGroup
      }))
    });

    // Get Azure AD token for SignalR
    const credential = new DefaultAzureCredential();
    const token = await credential.getToken('https://signalr.azure.com/.default');
    
    if (!token || !token.token) {
      context.error('Failed to acquire AAD token for SignalR');
      return;
    }

    // Broadcast to each determined route
    const broadcastResults = [];
    const teamsResults = [];
    
    for (const route of routes) {
      try {
        // Broadcast to SignalR
        const result = await broadcastToSignalRGroup(
          signalRBase,
          hubName,
          route.signalRGroup,
          eventData,
          token.token,
          context
        );
        
        broadcastResults.push({
          teamId: route.teamId,
          group: route.signalRGroup,
          success: result.success,
          statusCode: result.statusCode
        });
      } catch (err) {
        context.error(`Failed to broadcast to group ${route.signalRGroup}:`, err);
        broadcastResults.push({
          teamId: route.teamId,
          group: route.signalRGroup,
          success: false,
          error: err.message
        });
      }
    }

    // Post to Teams webhooks
    const teamsWebhooks = new Set(); // Use Set to avoid duplicate posts
    
    // 1. Add data source default webhook (e.g., General channel of the SharePoint site)
    if (teamsWebhookUrl) {
      teamsWebhooks.add(teamsWebhookUrl);
    }
    
    // 2. Add routing-based webhooks (e.g., shared operations channels)
    for (const route of routes) {
      if (route.teamsWebhooks && route.teamsWebhooks.length > 0) {
        route.teamsWebhooks.forEach(url => teamsWebhooks.add(url));
      }
    }
    
    // Post to all unique Teams webhooks
    for (const webhookUrl of teamsWebhooks) {
      try {
        await postToTeamsWebhook(event, webhookUrl, context);
        teamsResults.push({
          webhookUrl: webhookUrl.substring(0, 50) + '...',
          success: true
        });
      } catch (teamsErr) {
        context.error(`Failed to post to Teams webhook:`, teamsErr);
        teamsResults.push({
          webhookUrl: webhookUrl.substring(0, 50) + '...',
          success: false,
          error: teamsErr.message
        });
      }
    }

    // Log summary
    const successCount = broadcastResults.filter(r => r.success).length;
    const teamsSuccessCount = teamsResults.filter(r => r.success).length;
    context.log('Broadcast complete:', {
      itemId: eventData.itemId,
      signalR: {
        total: broadcastResults.length,
        successful: successCount,
        failed: broadcastResults.length - successCount
      },
      teams: {
        total: teamsResults.length,
        successful: teamsSuccessCount,
        failed: teamsResults.length - teamsSuccessCount
      },
      results: broadcastResults,
      teamsResults: teamsResults
    });

  } catch (err) {
    context.error('Error in eventHandler:', err);
    throw err;
  }
}
});

/**
 * Broadcast message to specific SignalR group
 */
async function broadcastToSignalRGroup(signalRBase, hubName, groupName, eventData, token, context) {
  // Send CloudEvents format as-is
  // Client will render adaptive cards from the CloudEvents data
  const message = {
    target: 'newItem',
    arguments: [eventData]
  };

  const publishUrl = `${signalRBase}/api/v1/hubs/${hubName}/groups/${groupName}/:send`;
  
  context.log(`Broadcasting to group: ${groupName}`);
  
  const res = await fetch(publishUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(message)
  });

  if (!res.ok) {
    const errorText = await res.text();
    context.error(`SignalR publish to group ${groupName} failed:`, res.status, errorText);
    return { success: false, statusCode: res.status, error: errorText };
  }

  context.log(`SignalR broadcast to group ${groupName} successful`);
  return { success: true, statusCode: res.status };
}

/**
 * Post adaptive card to Teams webhook
 */
async function postToTeamsWebhook(eventData, webhookUrl, context) {
  context.log('Posting to Teams webhook...');
  
  // Generate adaptive card from CloudEvents data
  const functionBaseUrl = process.env.FUNCTION_BASE_URL || '';
  const cardJson = createEventNotificationCard(eventData, {
    functionBaseUrl: functionBaseUrl,
    includeActions: true,
    compact: false
  });
  
  // Wrap for Teams
  const teamsMessage = wrapCardForTeams(cardJson);
  
  const res = await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(teamsMessage)
  });
  
  if (!res.ok) {
    const errorText = await res.text();
    context.error(`Teams webhook post failed:`, res.status, errorText);
    throw new Error(`Teams webhook failed: ${res.status} ${errorText}`);
  }
  
  context.log('Teams webhook post successful');
}
