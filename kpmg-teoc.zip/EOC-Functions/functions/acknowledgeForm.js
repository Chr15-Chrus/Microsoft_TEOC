const { app } = require('@azure/functions');
const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
const { findSourceByListId } = require('../utils/data-sources');
const axios = require('axios');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Azure Function: Acknowledge Form
 * Provides a simple HTML form for acknowledging assessments
 */
app.http('acknowledgeForm', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        const itemId = request.query.get('itemId');
        const listId = request.query.get('listId');
        const title = request.query.get('title') || 'Assessment';
        
        // Handle POST - process acknowledgement
        if (request.method === 'POST') {
            try {
                const formData = await request.formData();
                const userEmail = formData.get('userEmail');
                
                if (!userEmail) {
                    return {
                        status: 400,
                        headers: { 'Content-Type': 'text/html' },
                        body: '<html><body><h1>Error</h1><p>Email is required</p><a href="javascript:history.back()">Go Back</a></body></html>'
                    };
                }
                
                // Resolve source from DataSources table by listId
                let siteUrl;
                try {
                    const source = await findSourceByListId(listId, context);
                    if (!source || source.active === false) {
                        throw new Error('Source not found or inactive');
                    }
                    if (source.type !== 'sharepoint') {
                        throw new Error('Only SharePoint sources are supported');
                    }
                    siteUrl = source.siteUrl;
                    context.log('Resolved source from DataSources:', source.rowKey);
                } catch (error) {
                    context.error('Failed to resolve source from DataSources:', error.message);
                    return {
                        status: 400,
                        headers: { 'Content-Type': 'text/html' },
                        body: `<html><body><h1>Error</h1><p>Source configuration not found. Ensure the list is registered in Table Storage.</p></body></html>`
                    };
                }
                
                // Get Microsoft Graph token and update item
                const accessToken = await getSharePointAccessToken();
                
                // Get site ID from SharePoint URL
                const siteUrlObj = new URL(siteUrl);
                const hostname = siteUrlObj.hostname;
                const sitePath = siteUrlObj.pathname;
                
                // Get site ID using Graph API
                const siteResponse = await axios.get(
                    `https://graph.microsoft.com/v1.0/sites/${hostname}:${sitePath}`,
                    {
                        headers: { 'Authorization': `Bearer ${accessToken}` }
                    }
                );
                const siteId = siteResponse.data.id;
                
                // Update the item using Graph API
                await axios.patch(
                    `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items/${itemId}/fields`,
                    {
                        Acknowledged: userEmail
                    },
                    {
                        headers: {
                            'Authorization': `Bearer ${accessToken}`,
                            'Content-Type': 'application/json'
                        }
                    }
                );
                
                // Post update to Teams (webhook URL would also come from source config in production)
                const webhookUrl = await getSecretValue('TEAMS_WEBHOOK_URL', { optional: true });
                if (webhookUrl) {
                    await axios.post(webhookUrl, {
                        text: `✅ Assessment "${title}" acknowledged by ${userEmail}`
                    });
                }
                
                return {
                    status: 200,
                    headers: { 'Content-Type': 'text/html' },
                    body: `
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <meta charset="UTF-8">
                            <title>Acknowledgement Successful</title>
                            <meta name="viewport" content="width=device-width, initial-scale=1">
                            <style>
                                @keyframes fadeIn {
                                    from { opacity: 0; transform: translateY(-20px); }
                                    to { opacity: 1; transform: translateY(0); }
                                }
                                
                                @keyframes checkmark {
                                    0% { transform: scale(0) rotate(0deg); }
                                    50% { transform: scale(1.2) rotate(180deg); }
                                    100% { transform: scale(1) rotate(360deg); }
                                }
                                
                                body {
                                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                    min-height: 100vh;
                                    margin: 0;
                                    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
                                    padding: 20px;
                                }
                                
                                .container {
                                    background: white;
                                    padding: 40px;
                                    border-radius: 15px;
                                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                                    text-align: center;
                                    max-width: 600px;
                                    width: 100%;
                                    animation: fadeIn 0.5s ease-out;
                                }
                                
                                .success-icon {
                                    font-size: 80px;
                                    margin-bottom: 20px;
                                    animation: checkmark 0.6s ease-out;
                                    display: inline-block;
                                }
                                
                                h1 {
                                    color: #11998e;
                                    margin-top: 0;
                                    margin-bottom: 10px;
                                }
                                
                                .success-box {
                                    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
                                    border-left: 4px solid #28a745;
                                    padding: 20px;
                                    border-radius: 8px;
                                    margin: 25px 0;
                                    text-align: left;
                                }
                                
                                .success-box p {
                                    margin: 10px 0;
                                    color: #155724;
                                }
                                
                                .success-box strong {
                                    color: #0c3d1f;
                                }
                                
                                .info-box {
                                    background: #e3f2fd;
                                    border-left: 4px solid #2196F3;
                                    padding: 15px;
                                    border-radius: 5px;
                                    margin: 20px 0;
                                    text-align: left;
                                }
                                
                                .info-box p {
                                    margin: 8px 0;
                                    color: #1976D2;
                                    font-size: 14px;
                                }
                                
                                .btn {
                                    margin-top: 20px;
                                    padding: 14px 32px;
                                    background: #11998e;
                                    color: white;
                                    border: none;
                                    border-radius: 8px;
                                    cursor: pointer;
                                    font-size: 16px;
                                    font-weight: 600;
                                    transition: all 0.3s ease;
                                }
                                
                                .btn:hover {
                                    background: #0d7a6f;
                                    transform: translateY(-2px);
                                    box-shadow: 0 4px 12px rgba(17, 153, 142, 0.4);
                                }
                                
                                @media (max-width: 600px) {
                                    .container {
                                        padding: 30px 20px;
                                    }
                                }
                            </style>
                        </head>
                        <body>
                            <div class="container">
                                <div class="success-icon">✅</div>
                                <h1>Acknowledgement Successful!</h1>
                                <p>Your acknowledgement has been recorded and the team has been notified</p>
                                
                                <div class="success-box">
                                    <p><strong>📋 Assessment:</strong> ${title}</p>
                                    <p><strong>✍️ Acknowledged by:</strong> ${userEmail}</p>
                                    <p><strong>⏰ Time:</strong> ${new Date().toLocaleString()}</p>
                                </div>
                                
                                <div class="info-box">
                                    <p>✓ SharePoint list has been updated</p>
                                    <p>✓ Teams channel has been notified</p>
                                    <p>✓ Team members can see your acknowledgement</p>
                                </div>
                                
                                <button class="btn" onclick="window.close()">🏠 Close Window</button>
                            </div>
                        </body>
                        </html>
                    `
                };
                
            } catch (error) {
                context.error('Error processing acknowledgement:', error);
                return {
                    status: 500,
                    headers: { 'Content-Type': 'text/html' },
                    body: `<html><body><h1>Error</h1><p>${error.message}</p></body></html>`
                };
            }
        }
        
        // Handle GET - show enhanced form
        return {
            status: 200,
            headers: { 'Content-Type': 'text/html' },
            body: `
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Acknowledge Assessment</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                        @keyframes fadeIn {
                            from { opacity: 0; transform: translateY(-20px); }
                            to { opacity: 1; transform: translateY(0); }
                        }
                        
                        body {
                            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                            min-height: 100vh;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            margin: 0;
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            padding: 20px;
                        }
                        
                        .card {
                            background: white;
                            padding: 40px;
                            border-radius: 15px;
                            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                            max-width: 500px;
                            width: 100%;
                            animation: fadeIn 0.5s ease-out;
                        }
                        
                        .header-icon {
                            font-size: 60px;
                            text-align: center;
                            margin-bottom: 20px;
                        }
                        
                        h1 {
                            color: #0078d4;
                            margin-top: 0;
                            margin-bottom: 10px;
                            text-align: center;
                            font-size: 26px;
                        }
                        
                        .subtitle {
                            text-align: center;
                            color: #666;
                            margin-bottom: 30px;
                            font-size: 14px;
                        }
                        
                        .info-banner {
                            background: linear-gradient(135deg, #e7f3ff 0%, #cfe4ff 100%);
                            padding: 15px;
                            border-radius: 8px;
                            margin-bottom: 25px;
                            border-left: 4px solid #0078d4;
                        }
                        
                        .info-banner strong {
                            color: #0078d4;
                            display: block;
                            margin-bottom: 5px;
                        }
                        
                        .info-banner span {
                            color: #333;
                            font-size: 15px;
                        }
                        
                        label {
                            display: block;
                            margin: 20px 0 8px;
                            font-weight: 600;
                            color: #333;
                            font-size: 15px;
                        }
                        
                        input {
                            width: 100%;
                            padding: 14px;
                            border: 2px solid #e0e0e0;
                            border-radius: 8px;
                            box-sizing: border-box;
                            font-size: 16px;
                            transition: all 0.3s ease;
                        }
                        
                        input:focus {
                            outline: none;
                            border-color: #0078d4;
                            box-shadow: 0 0 0 3px rgba(0, 120, 212, 0.1);
                        }
                        
                        button {
                            background: linear-gradient(135deg, #0078d4 0%, #005a9e 100%);
                            color: white;
                            padding: 16px 30px;
                            border: none;
                            border-radius: 8px;
                            cursor: pointer;
                            font-size: 16px;
                            font-weight: 600;
                            margin-top: 25px;
                            width: 100%;
                            transition: all 0.3s ease;
                        }
                        
                        button:hover {
                            transform: translateY(-2px);
                            box-shadow: 0 8px 20px rgba(0, 120, 212, 0.3);
                        }
                        
                        button:active {
                            transform: translateY(0);
                        }
                        
                        .help-text {
                            font-size: 13px;
                            color: #666;
                            margin-top: 6px;
                            font-style: italic;
                        }
                        
                        @media (max-width: 600px) {
                            .card {
                                padding: 30px 20px;
                            }
                            
                            h1 {
                                font-size: 22px;
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="header-icon">✅</div>
                        <h1>Acknowledge Assessment</h1>
                        <p class="subtitle">Confirm you have reviewed this assessment</p>
                        
                        <div class="info-banner">
                            <strong>📋 Assessment Details</strong>
                            <span>${decodeURIComponent(title)}</span>
                        </div>
                        
                        <form method="POST">
                            <label for="userEmail">
                                👤 Your Email Address
                            </label>
                            <input 
                                type="email" 
                                id="userEmail" 
                                name="userEmail" 
                                required 
                                placeholder="your.email@company.com"
                                autocomplete="email"
                            >
                            <p class="help-text">Your email will be recorded as the person who acknowledged this assessment</p>
                            
                            <button type="submit">
                                ✅ Submit Acknowledgement
                            </button>
                        </form>
                    </div>
                </body>
                </html>
            `
        };
    }
});
