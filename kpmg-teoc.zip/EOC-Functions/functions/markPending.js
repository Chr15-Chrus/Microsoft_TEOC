const { app } = require('@azure/functions');
const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
const { findSourceByListId } = require('../utils/data-sources');
const axios = require('axios');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Simple endpoint to mark an assessment as Pending
 * Opens in browser, updates SharePoint, posts confirmation card to Teams
 */
app.http('markPending', {
    methods: ['GET'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        try {
            const itemId = request.query.get('itemId');
            const listId = request.query.get('listId');
            const title = request.query.get('title') || 'Assessment';
            const webhookUrl = await getSecretValue('TEAMS_WEBHOOK_URL', { optional: true });

            if (!itemId || !listId) {
                return {
                    status: 400,
                    headers: { 'Content-Type': 'text/html' },
                    body: '<h1>Error</h1><p>Missing itemId or listId parameters</p>'
                };
            }

            console.log(`Marking assessment ${itemId} as Pending`);

            // Resolve source from DataSources table by listId
            let siteUrl;
            try {
                const source = await findSourceByListId(listId, context);
                if (!source || source.active === false) {
                    throw new Error('Source not found or inactive');
                }
                if (source.type !== 'sharepoint') {
                    throw new Error('Only SharePoint sources are supported');
                }
                siteUrl = source.siteUrl;
                context.log('Resolved source from DataSources:', source.rowKey);
            } catch (error) {
                context.error('Failed to resolve source from DataSources:', error.message);
                return {
                    status: 400,
                    headers: { 'Content-Type': 'text/html' },
                    body: '<h1>Error</h1><p>Source configuration not found. Ensure the list is registered in Table Storage.</p>'
                };
            }

            // Get Microsoft Graph access token
            const accessToken = await getSharePointAccessToken();
            
            // Get site ID from SharePoint URL
            const siteUrlObj = new URL(siteUrl);
            const hostname = siteUrlObj.hostname;
            const sitePath = siteUrlObj.pathname;
            
            // Get site ID using Graph API
            const siteResponse = await axios.get(
                `https://graph.microsoft.com/v1.0/sites/${hostname}:${sitePath}`,
                {
                    headers: { 'Authorization': `Bearer ${accessToken}` }
                }
            );
            const siteId = siteResponse.data.id;

            // Update the list item using Graph API
            await axios.patch(
                `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items/${itemId}/fields`,
                {
                    Status: 'Pending'
                },
                {
                    headers: {
                        'Authorization': `Bearer ${accessToken}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            console.log('SharePoint item updated to Pending');

            // Post enhanced confirmation card to Teams
            if (webhookUrl) {
                const confirmationCard = {
                    type: "message",
                    attachments: [
                        {
                            contentType: "application/vnd.microsoft.card.adaptive",
                            content: {
                                type: "AdaptiveCard",
                                version: "1.4",
                                $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
                                body: [
                                    {
                                        type: "Container",
                                        style: "good",
                                        items: [
                                            {
                                                type: "ColumnSet",
                                                columns: [
                                                    {
                                                        type: "Column",
                                                        width: "auto",
                                                        items: [
                                                            {
                                                                type: "TextBlock",
                                                                text: "✅",
                                                                size: "ExtraLarge"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        type: "Column",
                                                        width: "stretch",
                                                        items: [
                                                            {
                                                                type: "TextBlock",
                                                                text: "Status Updated",
                                                                weight: "Bolder",
                                                                size: "Large",
                                                                color: "Good"
                                                            },
                                                            {
                                                                type: "TextBlock",
                                                                text: "Assessment marked as Pending",
                                                                isSubtle: true,
                                                                spacing: "None"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        type: "Container",
                                        spacing: "Medium",
                                        items: [
                                            {
                                                type: "TextBlock",
                                                text: `**${title}**`,
                                                size: "Medium",
                                                wrap: true
                                            },
                                            {
                                                type: "FactSet",
                                                facts: [
                                                    {
                                                        title: "Assessment ID:",
                                                        value: itemId
                                                    },
                                                    {
                                                        title: "New Status:",
                                                        value: "🟡 Pending"
                                                    },
                                                    {
                                                        title: "Updated:",
                                                        value: new Date().toLocaleString()
                                                    }
                                                ],
                                                spacing: "Small"
                                            }
                                        ]
                                    },
                                    {
                                        type: "Container",
                                        style: "emphasis",
                                        spacing: "Small",
                                        items: [
                                            {
                                                type: "TextBlock",
                                                text: "💡 Next Steps",
                                                weight: "Bolder",
                                                size: "Small"
                                            },
                                            {
                                                type: "TextBlock",
                                                text: "• Assign a team member to investigate\n• Schedule site visit if needed\n• Update status when action is taken",
                                                wrap: true,
                                                spacing: "Small",
                                                size: "Small"
                                            }
                                        ]
                                    }
                                ]
                            }
                        }
                    ]
                };

                await axios.post(webhookUrl, confirmationCard);
                console.log('Enhanced confirmation card posted to Teams');
            }

            // Return enhanced success page with animation
            return {
                status: 200,
                headers: { 'Content-Type': 'text/html' },
                body: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="UTF-8">
                        <title>Status Updated</title>
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <style>
                            @keyframes fadeIn {
                                from { opacity: 0; transform: translateY(-20px); }
                                to { opacity: 1; transform: translateY(0); }
                            }
                            
                            @keyframes checkmark {
                                0% { transform: scale(0) rotate(0deg); }
                                50% { transform: scale(1.2) rotate(180deg); }
                                100% { transform: scale(1) rotate(360deg); }
                            }
                            
                            @keyframes pulse {
                                0%, 100% { transform: scale(1); }
                                50% { transform: scale(1.05); }
                            }
                            
                            body {
                                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                min-height: 100vh;
                                margin: 0;
                                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                                padding: 20px;
                            }
                            
                            .container {
                                background: white;
                                padding: 40px;
                                border-radius: 15px;
                                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                                text-align: center;
                                max-width: 600px;
                                width: 100%;
                                animation: fadeIn 0.5s ease-out;
                            }
                            
                            .success-icon {
                                font-size: 80px;
                                margin-bottom: 20px;
                                animation: checkmark 0.6s ease-out;
                                display: inline-block;
                            }
                            
                            h1 {
                                color: #0078D4;
                                margin-top: 0;
                                margin-bottom: 10px;
                                font-size: 28px;
                            }
                            
                            .subtitle {
                                color: #666;
                                font-size: 14px;
                                margin-bottom: 30px;
                            }
                            
                            .message {
                                font-size: 18px;
                                color: #333;
                                margin: 20px 0;
                                line-height: 1.6;
                            }
                            
                            .assessment-title {
                                color: #0078D4;
                                font-weight: bold;
                                font-size: 20px;
                            }
                            
                            .details {
                                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                                padding: 20px;
                                border-radius: 10px;
                                margin: 25px 0;
                                text-align: left;
                                box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
                            }
                            
                            .details p {
                                margin: 12px 0;
                                display: flex;
                                align-items: center;
                                font-size: 15px;
                            }
                            
                            .details strong {
                                color: #333;
                                min-width: 140px;
                                display: inline-block;
                            }
                            
                            .status-badge {
                                display: inline-block;
                                padding: 6px 16px;
                                background: #FFA500;
                                color: white;
                                border-radius: 20px;
                                font-weight: bold;
                                font-size: 14px;
                                text-transform: uppercase;
                                letter-spacing: 0.5px;
                                animation: pulse 2s infinite;
                            }
                            
                            .info-box {
                                background: #e3f2fd;
                                border-left: 4px solid #2196F3;
                                padding: 15px;
                                border-radius: 5px;
                                margin: 20px 0;
                                text-align: left;
                            }
                            
                            .info-box p {
                                margin: 8px 0;
                                color: #1976D2;
                                font-size: 14px;
                            }
                            
                            .info-icon {
                                margin-right: 8px;
                            }
                            
                            .button-group {
                                display: flex;
                                gap: 10px;
                                justify-content: center;
                                margin-top: 30px;
                            }
                            
                            .btn {
                                padding: 14px 32px;
                                border: none;
                                border-radius: 8px;
                                cursor: pointer;
                                font-size: 16px;
                                font-weight: 600;
                                transition: all 0.3s ease;
                                text-decoration: none;
                                display: inline-block;
                            }
                            
                            .btn-primary {
                                background: #0078D4;
                                color: white;
                            }
                            
                            .btn-primary:hover {
                                background: #005a9e;
                                transform: translateY(-2px);
                                box-shadow: 0 4px 12px rgba(0,120,212,0.4);
                            }
                            
                            .btn-secondary {
                                background: #f0f0f0;
                                color: #333;
                            }
                            
                            .btn-secondary:hover {
                                background: #e0e0e0;
                                transform: translateY(-2px);
                            }
                            
                            @media (max-width: 600px) {
                                .container {
                                    padding: 30px 20px;
                                }
                                
                                .button-group {
                                    flex-direction: column;
                                }
                                
                                .btn {
                                    width: 100%;
                                }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <div class="success-icon">✅</div>
                            <h1>Status Updated Successfully!</h1>
                            <p class="subtitle">Your assessment has been updated and the team has been notified</p>
                            
                            <p class="message">
                                <span class="assessment-title">"${decodeURIComponent(title)}"</span><br>
                                has been marked as <span class="status-badge">Pending</span>
                            </p>
                            
                            <div class="details">
                                <p><strong>📋 Assessment ID:</strong> ${itemId}</p>
                                <p><strong>🔄 New Status:</strong> <span style="color: #FFA500; font-weight: bold;">Pending</span></p>
                                <p><strong>⏰ Updated At:</strong> ${new Date().toLocaleString()}</p>
                            </div>
                            
                            <div class="info-box">
                                <p><span class="info-icon">✓</span> SharePoint list has been updated</p>
                                <p><span class="info-icon">✓</span> Confirmation card posted to Teams channel</p>
                                <p><span class="info-icon">✓</span> Team members have been notified</p>
                            </div>
                            
                            <div class="button-group">
                                <button class="btn btn-primary" onclick="window.close()">
                                    🏠 Close Window
                                </button>
                            </div>
                        </div>
                        
                        <script>
                            // Auto-close after 10 seconds (optional)
                            // setTimeout(() => window.close(), 10000);
                        </script>
                    </body>
                    </html>
                `
            };

        } catch (error) {
            console.error('Error marking as pending:', error);
            return {
                status: 500,
                headers: { 'Content-Type': 'text/html' },
                body: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Error</title>
                        <style>
                            body {
                                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                height: 100vh;
                                margin: 0;
                                background: #f5f5f5;
                            }
                            .container {
                                background: white;
                                padding: 40px;
                                border-radius: 10px;
                                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                                text-align: center;
                                max-width: 500px;
                            }
                            h1 { color: #d13438; }
                            .error-icon { font-size: 60px; margin-bottom: 20px; }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <div class="error-icon">❌</div>
                            <h1>Error</h1>
                            <p>${error.message}</p>
                            <button onclick="window.close()">Close</button>
                        </div>
                    </body>
                    </html>
                `
            };
        }
    }
});
