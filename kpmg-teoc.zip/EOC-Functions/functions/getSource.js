const { app } = require('@azure/functions');
const { getDataSourcesTableClient } = require('../utils/data-sources');

/**
 * Get a specific data source by ID
 */
app.http('getSource', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'getSource',
    handler: async (request, context) => {
        context.log('getSource function called');

        const sourceId = request.query.get('id');
        if (!sourceId) {
            return {
                status: 400,
                jsonBody: { error: 'Missing source ID' }
            };
        }

        try {
            const tableClient = await getDataSourcesTableClient(context);
            const entity = await tableClient.getEntity('source', sourceId);

            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                jsonBody: {
                    id: entity.rowKey,
                    type: entity.type,
                    name: entity.name,
                    description: entity.description,
                    active: entity.active,
                    createdDate: entity.createdDate,
                    siteUrl: entity.siteUrl,
                    listUrl: entity.listUrl,
                    listId: entity.listId,
                    webhookUrl: entity.webhookUrl,
                    webhookExpiration: entity.webhookExpiration,
                    instanceUrl: entity.instanceUrl,
                    entity: entity.entity
                }
            };
        } catch (error) {
            context.error('Error fetching source:', error);
            return {
                status: 404,
                jsonBody: { error: 'Source not found', message: error.message }
            };
        }
    }
});
