const { app } = require('@azure/functions');
const crypto = require('crypto');
const { TableClient } = require('@azure/data-tables');
const { createSharePointSource } = require('../utils/sharepoint-source-manager');
const { getDataSourcesTableClient } = require('../utils/data-sources');
const { requireAuth } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit-logger');

/**
 * Register a new data source
 * Handles SharePoint, Dynamics 365, and custom API sources
 * Requires SourceAdmin role
 */
app.http('registerSource', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'registerSource',
    handler: async (request, context) => {
        context.log('registerSource function called');

        // Authenticate and check role
        const user = await requireAuth(request, ['SourceAdmin', 'Admin']);
        if (!user) {
            return {
                status: 401,
                jsonBody: { 
                    error: 'Unauthorized',
                    message: 'Valid authentication required with SourceAdmin or Admin role'
                }
            };
        }

        const body = await request.json();
        const { type, name, description, autoConfigure, sharepoint, dynamics, custom } = body;

        if (!type || !name) {
            return {
                status: 400,
                jsonBody: { error: 'Missing required fields: type and name' }
            };
        }

        try {
            if (type === 'sharepoint' && sharepoint) {
                const { source, webhook } = await createSharePointSource({
                    sourceId: sharepoint.sourceId,
                    name,
                    description,
                    siteUrl: sharepoint.siteUrl,
                    listUrl: sharepoint.listUrl,
                    listId: sharepoint.listId,
                    autoConfigure: autoConfigure !== false
                }, context);

                context.log(`SharePoint source registered: ${source.rowKey}`);

                // Log audit event
                await logAuditEvent({
                    action: 'CREATE_SOURCE',
                    userId: user.id,
                    userEmail: user.email,
                    resourceType: 'DataSource',
                    resourceId: source.rowKey,
                    details: {
                        sourceType: 'sharepoint',
                        name,
                        siteUrl: sharepoint.siteUrl,
                        autoConfigure,
                        webhookId: webhook?.id
                    }
                }, context);

                return {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' },
                    jsonBody: {
                        success: true,
                        sourceId: source.rowKey,
                        message: 'Data source registered successfully',
                        webhook,
                        nextSteps: getNextSteps(type, autoConfigure)
                    }
                };
            }

            // Initialize Table Storage client for non-SharePoint sources
            const tableClient = await getDataSourcesTableClient(context);
            const sourceId = crypto.randomUUID();
            const source = {
                partitionKey: 'source',
                rowKey: sourceId,
                type,
                name,
                description: description || '',
                active: true,
                createdBy: user.email,
                createdDate: new Date().toISOString(),
                modifiedDate: new Date().toISOString()
            };

            // Handle Dynamics source
            if (type === 'dynamics' && dynamics) {
                source.instanceUrl = dynamics.instanceUrl;
                source.entity = dynamics.entity;

                if (autoConfigure) {
                    // Note: Dynamics integration typically uses Power Automate flow
                    // Store configuration for manual flow setup
                    context.log('Dynamics source registered. User needs to create Power Automate flow.');
                }
            }

            // Handle custom API source
            else if (type === 'custom' && custom) {
                source.webhookUrl = custom.webhookUrl;
                source.format = custom.format;
            }

            // Save to Table Storage
            await tableClient.createEntity(source);

            context.log(`Source registered: ${sourceId}`);

            // Log audit event
            await logAuditEvent({
                action: 'CREATE_SOURCE',
                userId: user.id,
                userEmail: user.email,
                resourceType: 'DataSource',
                resourceId: sourceId,
                details: {
                    sourceType: type,
                    name,
                    autoConfigure
                }
            }, context);

            // Return success with webhook info
            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                jsonBody: {
                    success: true,
                    sourceId: sourceId,
                    message: 'Data source registered successfully',
                    webhook: null,
                    nextSteps: getNextSteps(type, autoConfigure)
                }
            };
        } catch (error) {
            context.error('Error registering source:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Failed to register source',
                    message: error.message
                }
            };
        }
    }
});

/**
 * Get next steps based on source type and configuration
 */
function getNextSteps(type, autoConfigure) {
    const steps = [];

    if (type === 'sharepoint') {
        if (autoConfigure) {
            steps.push('✅ Webhook registered automatically');
            steps.push('✅ Event Grid connection configured');
            steps.push('→ Events will flow automatically when items are created/updated');
        } else {
            steps.push('→ Manually register webhook using SharePoint API');
            steps.push('→ Configure Event Grid connection');
        }
    } else if (type === 'dynamics') {
        steps.push('→ Create Power Automate flow to monitor Dynamics entity');
        steps.push('→ Configure flow to call /api/publishEvent endpoint');
        steps.push('→ See documentation for flow template');
    } else if (type === 'custom') {
        steps.push('→ Configure your system to send events to /api/publishEvent');
        steps.push('→ Use CloudEvents format or custom JSON');
        steps.push('→ Include authentication headers');
    }

    return steps;
}
