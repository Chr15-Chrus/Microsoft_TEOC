const { app } = require('@azure/functions');
const fs = require('fs');
const path = require('path');

// MIME types for static files
const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '. png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg':  'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.webmanifest': 'application/manifest+json'
};

// Security headers required for Teams iframe embedding
const teamsFrameHeaders = {
    'Content-Security-Policy': "frame-ancestors 'self' https://teams.microsoft.com https://*.teams.microsoft.com https://*.microsoft.com https://*.cloud.microsoft https://*.office.com https://*.sharepoint.com https://*.officeppe.com",
    'X-Content-Type-Options': 'nosniff'
};

app.http('serveWeb', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'webmap/{*filepath}',
    handler: async (request, context) => {
        try {
            let filepath = request.params.filepath || 'index.html';
            
            // Security:  prevent directory traversal attacks
            if (filepath.includes('..') || filepath.includes('\\')) {
                return { 
                    status: 400, 
                    body: 'Invalid path',
                    headers: teamsFrameHeaders
                };
            }
            
            // Construct the full path to the file
            const webRoot = path.join(__dirname, '..', 'web');
            let fullPath = path.join(webRoot, filepath);
            
            // Check if file exists
            if (! fs.existsSync(fullPath)) {
                // If no extension, try adding .html
                if (!path.extname(filepath)) {
                    const htmlPath = fullPath + '.html';
                    if (fs.existsSync(htmlPath)) {
                        fullPath = htmlPath;
                        filepath = filepath + '.html';
                    } else {
                        // For SPA routing, serve index.html
                        fullPath = path.join(webRoot, 'index.html');
                        filepath = 'index.html';
                    }
                }
            }
            
            // Final check if file exists
            if (!fs. existsSync(fullPath)) {
                return { 
                    status: 404, 
                    body: 'File not found',
                    headers: teamsFrameHeaders
                };
            }
            
            // Check if it's a directory
            const stats = fs.statSync(fullPath);
            if (stats. isDirectory()) {
                fullPath = path.join(fullPath, 'index.html');
                if (! fs.existsSync(fullPath)) {
                    return { 
                        status: 404, 
                        body: 'File not found',
                        headers:  teamsFrameHeaders
                    };
                }
            }
            
            // Read the file
            const content = fs.readFileSync(fullPath);
            const ext = path.extname(fullPath).toLowerCase();
            const contentType = mimeTypes[ext] || 'application/octet-stream';
            
            // Return with Teams-compatible headers
            return {
                status: 200,
                headers: {
                    'Content-Type': contentType,
                    'Cache-Control': 'no-cache',
                    ... teamsFrameHeaders
                },
                body: content
            };
            
        } catch (error) {
            context.error('Error serving web file:', error);
            return {
                status: 500,
                body: 'Internal server error',
                headers: teamsFrameHeaders
            };
        }
    }
});