const { app } = require('@azure/functions');
const axios = require('axios');
const { requireAuth } = require('../utils/auth-middleware');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Reverse geocode coordinates to address using Mapbox API
 * This supports validating locations for SharePoint's structured Location field
 */
app.http('reverseGeocode', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'reverseGeocode',
    handler: async (request, context) => {
        try {
            // Verify user authentication
            const user = await requireAuth(request);
            if (!user) {
                return {
                    status: 401,
                    jsonBody: {
                        error: 'Unauthorized',
                        message: 'Valid authentication token required'
                    }
                };
            }
            
            context.log('Reverse geocoding for user:', user.email);
            
            // Parse request body
            const { latitude, longitude } = await request.json();
            
            if (!latitude || !longitude) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Latitude and longitude are required'
                    }
                };
            }
            
            // Get Mapbox API key
            const mapboxToken = await getSecretValue('MAPBOX_API_KEY');
            if (!mapboxToken) {
                return {
                    status: 500,
                    jsonBody: {
                        error: 'Configuration Error',
                        message: 'Mapbox API key not configured'
                    }
                };
            }
            
            // Call Mapbox Geocoding API for reverse geocoding
            // Note: Mapbox requires access tokens in URL query parameters (standard practice)
            // Public tokens are designed to be used in client-side code and can be restricted by URL
            const mapboxUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?access_token=${mapboxToken}`;
            
            context.log('Calling Mapbox API:', mapboxUrl.replace(/access_token=[^&]+/, 'access_token=***'));
            
            const response = await axios.get(mapboxUrl);
            
            if (!response.data || !response.data.features || response.data.features.length === 0) {
                return {
                    status: 404,
                    jsonBody: {
                        error: 'Not Found',
                        message: 'No address found for the provided coordinates'
                    }
                };
            }
            
            // Extract the first result
            const feature = response.data.features[0];
            
            // Parse address components from the context
            const address = {
                Street: '',
                City: '',
                State: '',
                CountryOrRegion: '',
                PostalCode: ''
            };
            
            if (feature.context && Array.isArray(feature.context)) {
                feature.context.forEach(c => {
                    if (c.id && c.id.startsWith('place')) address.City = c.text;
                    if (c.id && c.id.startsWith('region')) address.State = c.text;
                    if (c.id && c.id.startsWith('country')) address.CountryOrRegion = c.text;
                    if (c.id && c.id.startsWith('postcode')) address.PostalCode = c.text;
                });
            }
            
            // Extract street address if available
            if (feature.properties && feature.properties.address) {
                address.Street = feature.properties.address;
            } else if (feature.address) {
                address.Street = `${feature.address} ${feature.text}`;
            } else if (feature.place_type && feature.place_type.includes('address')) {
                address.Street = feature.text;
            }
            
            const result = {
                displayName: feature.place_name || `${latitude.toFixed(6)},${longitude.toFixed(6)}`,
                address: address,
                locationUri: (feature.properties && feature.properties.wikidata) ? feature.properties.wikidata : (feature.id || ''),
                coordinates: {
                    latitude: latitude,
                    longitude: longitude
                }
            };
            
            context.log('Reverse geocoding successful:', result.displayName);
            
            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json'
                },
                jsonBody: result
            };
        } catch (error) {
            context.error('Error in reverse geocoding:', error);
            
            if (error.response?.status === 401) {
                return {
                    status: 401,
                    jsonBody: {
                        error: 'Unauthorized',
                        message: 'Invalid Mapbox API key'
                    }
                };
            }
            
            return {
                status: 500,
                jsonBody: {
                    error: 'Reverse geocoding failed',
                    message: error.message
                }
            };
        }
    }
});
