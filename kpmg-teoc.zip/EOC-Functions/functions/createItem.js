const { app } = require('@azure/functions');
const axios = require('axios');
const { getUserGraphToken } = require('../utils/sharepoint-auth');
const { requireAuth } = require('../utils/auth-middleware');
const { validateAndParseCoordinates, formatLocationForSharePoint } = require('../utils/coordinate-utils');
const { getSourceById, DEFAULT_SOURCE_ID } = require('../utils/data-sources');

/**
 * Create a new item in a data source
 * Accepts item data including latitude/longitude coordinates and source selection
 */
app.http('createItem', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'createItem',
    handler: async (request, context) => {
        try {
            // Verify user authentication (allow LOCAL_DEBUG bypass)
            let user, userToken;
            if (process.env.LOCAL_DEBUG === 'true') {
                // Safety check: prevent LOCAL_DEBUG in production
                if (process.env.NODE_ENV === 'production' || process.env.AZURE_FUNCTIONS_ENVIRONMENT === 'Production') {
                    context.error('LOCAL_DEBUG is enabled in production environment - this is a security risk!');
                    return {
                        status: 500,
                        jsonBody: {
                            error: 'Configuration Error',
                            message: 'Invalid debug configuration'
                        }
                    };
                }
                user = { email: 'local@dev' };
                userToken = null;
                context.log('LOCAL_DEBUG enabled — bypassing auth as', user.email);
            } else {
                user = await requireAuth(request);
                if (!user) {
                    return {
                        status: 401,
                        jsonBody: {
                            error: 'Unauthorized',
                            message: 'Valid authentication token required'
                        }
                    };
                }
                userToken = request.headers.get('authorization');
            }

            context.log('Creating item for user:', user.email);
            
            // Parse request body
            const itemData = await request.json();
            context.log('createItem payload:', itemData);
            
            // Validate required fields
            if (!itemData.Title || !itemData.ContactName || !itemData.ContactPhoneNumber) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Missing required fields: Title, ContactName, ContactPhoneNumber'
                    }
                };
            }
            
            // Validate coordinates
            const coordinates = validateAndParseCoordinates(itemData);
            if (!coordinates) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Valid coordinates (latitude, longitude) are required'
                    }
                };
            }
            
            const { lat, lng } = coordinates;
            context.log('createItem coordinates:', { lat, lng });
            
            // Determine target source
            const sourceId = itemData.sourceId || DEFAULT_SOURCE_ID;
            context.log('Creating item in source:', sourceId);
            
            // Get source configuration from Table Storage
            let siteUrl, listId;
            try {
                const source = await getSourceById(sourceId, context);
                if (!source || source.active === false) {
                    return {
                        status: 400,
                        jsonBody: {
                            error: 'Bad Request',
                            message: 'Invalid or inactive source'
                        }
                    };
                }

                if (source.type !== 'sharepoint') {
                    return {
                        status: 400,
                        jsonBody: {
                            error: 'Bad Request',
                            message: 'Only SharePoint sources support direct item creation'
                        }
                    };
                }

                siteUrl = source.siteUrl;
                listId = source.listId;
            } catch (error) {
                context.error('Failed to load source configuration:', error.message);
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: 'Unable to load source configuration. Ensure the source exists in Table Storage.'
                    }
                };
            }
            
            if (!siteUrl || !listId) {
                throw new Error('SharePoint configuration not complete in Table Storage');
            }
            
            // Get SharePoint access token using user's context
            let accessToken;
            if (userToken && process.env.LOCAL_DEBUG !== 'true') {
                try {
                    accessToken = await getUserGraphToken(userToken);
                    context.log('Using user-delegated Graph token for item creation');
                } catch (error) {
                    context.error('Failed to get user Graph token:', error.message);
                    return {
                        status: 403,
                        jsonBody: {
                            error: 'Forbidden',
                            message: 'Unable to authenticate with SharePoint using your credentials'
                        }
                    };
                }
            } else {
                // LOCAL_DEBUG mode - use app-only token
                (context.warn ?? context.log).call(context, 'Using app-only token (LOCAL_DEBUG mode)');
                const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
                accessToken = await getSharePointAccessToken();
            }
            
            // Build Graph API URL
            const u = new URL(siteUrl);
            const hostname = u.hostname;
            const pathParts = u.pathname.split('/').filter(Boolean);
            const siteName = pathParts.length > 1 ? pathParts[pathParts.length - 1] : pathParts[0] || '';

            const graphUrl = `https://graph.microsoft.com/v1.0/sites/${hostname}:/sites/${siteName}:/lists/${listId}/items`;
            
            // Prepare item fields
            const fields = {
                Title: itemData.Title,
                Contact_x0020_Name: itemData.ContactName,
                ContactPhoneNumber: itemData.ContactPhoneNumber,
                EventCausedDamage: itemData.EventCausedDamage || 'Other',
                MoreInformation: itemData.MoreInformation || '',
                ImmediateNeedsRequired: itemData.ImmediateNeedsRequired || false,
                Status: itemData.Status || 'New',
                Priority: itemData.Priority || (itemData.ImmediateNeedsRequired ? 'High' : 'Medium'),
                latitude: lat,
                longitude: lng
            };

            context.log('Creating item in SharePoint with fields:', JSON.stringify(fields));

            const createResponse = await axios.post(graphUrl, { fields }, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });
            
            context.log('Item created successfully:', createResponse.data.id);
            
            return {
                status: 201,
                headers: {
                    'Content-Type': 'application/json'
                },
                jsonBody: {
                    success: true,
                    id: createResponse.data.id,
                    sourceId: sourceId,
                    item: createResponse.data.fields
                }
            };
        } catch (error) {
            context.error('Error creating item:', error);
            context.error('Graph error body:', error.response?.data || error.response || null);

            if (error.response?.status === 403 || error.response?.status === 401) {
                return {
                    status: 403,
                    jsonBody: {
                        error: 'Forbidden',
                        message: 'You do not have permission to create items in this list'
                    }
                };
            }

            if (error.response?.status === 400) {
                return {
                    status: 400,
                    jsonBody: {
                        error: 'Bad Request',
                        message: error.response.data?.error?.message || 'Invalid item data',
                        graphError: error.response.data || null
                    }
                };
            }

            return {
                status: error.response?.status || 500,
                jsonBody: {
                    error: 'Failed to create item',
                    message: error.message,
                    graphError: error.response?.data || null
                }
            };
        }
    }
});
