const { app } = require('@azure/functions');
const axios = require('axios');
const { getSecretValue } = require('../utils/secretProvider');
const { createEventNotificationCard, wrapCardForTeams } = require('../utils/adaptive-card-templates');

/**
 * Generates an Adaptive Card for a TEOC assessment (LEGACY - for backward compatibility)
 * This function is maintained for legacy Logic App integrations
 * New implementations should use the shared adaptive-card-templates.js
 * @param {Object} assessment - The assessment data from SharePoint
 * @param {string} aiSummary - AI-generated summary of similar items
 * @param {string} functionBaseUrl - Base URL for the Azure Function (for action callbacks)
 * @returns {Object} Adaptive Card JSON
 */
function createAdaptiveCard(assessment, aiSummary, functionBaseUrl) {
    // Handle location data - can be either JSON string or separate fields
    let locationString = 'Unknown Location';
    let mapUrl = '';
    let coordinates = null;
    let mapImageUrl = '';
    
    if (assessment.Location) {
        try {
            const locationData = JSON.parse(assessment.Location);
            const displayName = locationData.DisplayName || '';
            const address = locationData.Address || {};
            locationString = [address.City, address.State, address.CountryOrRegion]
                .filter(x => x)
                .join(', ') || displayName;
            
            // Extract coordinates if available
            if (locationData.Coordinates && locationData.Coordinates.Latitude && locationData.Coordinates.Longitude) {
                coordinates = locationData.Coordinates;
                // Create static map image URL (using OpenStreetMap static map)
                const lat = coordinates.Latitude;
                const lon = coordinates.Longitude;
                mapImageUrl = `https://www.mapquestapi.com/staticmap/v5/map?center=${lat},${lon}&zoom=13&size=400,200&type=map&locations=${lat},${lon}`;
            }
        } catch (e) {
            locationString = assessment.Location;
        }
    } else if (assessment.DispName || assessment.City || assessment.Street) {
        // Handle separate location fields from SharePoint trigger
        locationString = [
            assessment.DispName,
            assessment.Street,
            assessment.City,
            assessment.State,
            assessment.CountryOrRegion
        ].filter(x => x).join(', ');
    }
    
    // Create Google Maps URL for the location
    if (locationString && locationString !== 'Unknown Location') {
        mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(locationString)}`;
    }

    // Handle event type - can be string or object with Value
    const eventType = typeof assessment.EventCausedDamage === 'object' 
        ? assessment.EventCausedDamage?.Value || 'Not specified'
        : assessment.EventCausedDamage || 'Not specified';
    
    // Handle status - can be string or object with Value
    const status = typeof assessment.Status === 'object'
        ? assessment.Status?.Value || 'New'
        : assessment.Status || 'New';
    
    // Determine priority/severity based on immediate needs
    const severity = assessment.ImmediateNeedsRequired ? 'High' : 'Medium';
    const severityColor = assessment.ImmediateNeedsRequired ? 'Attention' : 'Warning';
    
    // Format creation time
    const createdTime = assessment.Created ? new Date(assessment.Created).toLocaleString() : new Date().toLocaleString();

    // Build the card body
    const cardBody = [
        // Header with severity indicator
        {
            type: "Container",
            style: "emphasis",
            items: [
                {
                    type: "ColumnSet",
                    columns: [
                        {
                            type: "Column",
                            width: "stretch",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: "🚨 New TEOC Assessment",
                                    weight: "Bolder",
                                    size: "Large",
                                    color: "Attention"
                                }
                            ]
                        },
                        {
                            type: "Column",
                            width: "auto",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: `${severity} Priority`,
                                    weight: "Bolder",
                                    color: severityColor,
                                    horizontalAlignment: "Right"
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        // Title
        {
            type: "TextBlock",
            text: assessment.Title || "Untitled Assessment",
            weight: "Bolder",
            size: "Medium",
            wrap: true,
            spacing: "Medium"
        },
        // Timestamp
        {
            type: "TextBlock",
            text: `📅 Reported: ${createdTime}`,
            size: "Small",
            isSubtle: true,
            spacing: "Small"
        }
    ];
    
    // Add map visualization if coordinates available
    if (coordinates) {
        cardBody.push({
            type: "Container",
            spacing: "Medium",
            separator: true,
            items: [
                {
                    type: "TextBlock",
                    text: "📍 Location Map",
                    weight: "Bolder",
                    size: "Medium"
                },
                {
                    type: "TextBlock",
                    text: locationString,
                    wrap: true,
                    spacing: "Small"
                },
                {
                    type: "TextBlock",
                    text: `Coordinates: ${coordinates.Latitude.toFixed(6)}, ${coordinates.Longitude.toFixed(6)}`,
                    size: "Small",
                    isSubtle: true,
                    spacing: "Small"
                },
                {
                    type: "ColumnSet",
                    columns: [
                        {
                            type: "Column",
                            width: "stretch",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: `[📍 Open in Google Maps](${mapUrl})`,
                                    spacing: "Small"
                                }
                            ]
                        },
                        {
                            type: "Column",
                            width: "stretch",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: `[🗺️ Open in Bing Maps](https://www.bing.com/maps?cp=${coordinates.Latitude}~${coordinates.Longitude}&lvl=14)`,
                                    spacing: "Small"
                                }
                            ]
                        }
                    ],
                    spacing: "Small"
                }
            ]
        });
    } else if (mapUrl) {
        // Fallback to simple location with link if no coordinates
        cardBody.push({
            type: "Container",
            spacing: "Medium",
            separator: true,
            items: [
                {
                    type: "TextBlock",
                    text: "📍 Location",
                    weight: "Bolder",
                    size: "Medium"
                },
                {
                    type: "TextBlock",
                    text: `[${locationString}](${mapUrl})`,
                    wrap: true,
                    spacing: "Small"
                }
            ]
        });
    }
    
    // Assessment details in a structured format
    cardBody.push({
        type: "Container",
        spacing: "Medium",
        separator: true,
        items: [
            {
                type: "TextBlock",
                text: "📋 Assessment Details",
                weight: "Bolder",
                size: "Medium"
            },
            {
                type: "FactSet",
                facts: [
                    {
                        title: "👤 Contact:",
                        value: `${assessment.Contact_x0020_Name || 'N/A'}`
                    },
                    {
                        title: "📞 Phone:",
                        value: assessment.ContactPhoneNumber || 'Not provided'
                    },
                    {
                        title: "⚡ Event Type:",
                        value: eventType
                    },
                    {
                        title: "🚨 Immediate Needs:",
                        value: assessment.ImmediateNeedsRequired ? "⚠️ YES - Requires urgent attention" : "✅ No immediate needs"
                    },
                    {
                        title: "📊 Current Status:",
                        value: status
                    },
                    {
                        title: "✍️ Acknowledged:",
                        value: assessment.Acknowledged || '⏳ Awaiting acknowledgment'
                    }
                ],
                spacing: "Small"
            }
        ]
    });
    
    // Additional information if provided
    if (assessment.MoreInformation) {
        cardBody.push({
            type: "Container",
            spacing: "Medium",
            separator: true,
            items: [
                {
                    type: "TextBlock",
                    text: "📝 Additional Information",
                    weight: "Bolder",
                    size: "Medium"
                },
                {
                    type: "TextBlock",
                    text: assessment.MoreInformation,
                    wrap: true,
                    spacing: "Small"
                }
            ]
        });
    }
    
    // AI Analysis section with enhanced formatting
    cardBody.push({
        type: "Container",
        style: "emphasis",
        spacing: "Medium",
        separator: true,
        items: [
            {
                type: "TextBlock",
                text: "🤖 AI-Powered Analysis",
                weight: "Bolder",
                size: "Medium",
                color: "Accent"
            },
            {
                type: "TextBlock",
                text: aiSummary || "No similar incidents found. This appears to be a unique assessment.",
                wrap: true,
                spacing: "Small",
                color: "Default"
            }
        ]
    });
    
    // Action buttons section
    cardBody.push({
        type: "Container",
        separator: true,
        spacing: "Medium",
        items: [
            {
                type: "TextBlock",
                text: "⚡ Quick Actions",
                weight: "Bolder",
                size: "Medium"
            },
            {
                type: "TextBlock",
                text: "Take action on this assessment (opens in browser for confirmation):",
                wrap: true,
                spacing: "Small",
                size: "Small",
                isSubtle: true
            }
        ]
    });

    return {
        type: "message",
        attachments: [
            {
                contentType: "application/vnd.microsoft.card.adaptive",
                contentUrl: null,
                content: {
                    $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
                    type: "AdaptiveCard",
                    version: "1.4",
                    body: cardBody,
                    actions: [
                        {
                            type: "Action.OpenUrl",
                            title: "📋 Mark as Pending",
                            url: `${functionBaseUrl}/api/markPending?itemId=${assessment.ID}&listId=${assessment.ListId}&title=${encodeURIComponent(assessment.Title || '')}`
                        },
                        {
                            type: "Action.OpenUrl",
                            title: "✅ Acknowledge This Assessment",
                            url: `${functionBaseUrl}/api/acknowledgeForm?itemId=${assessment.ID}&listId=${assessment.ListId}&title=${encodeURIComponent(assessment.Title || '')}`
                        }
                    ]
                }
            }
        ]
    };
}

/**
 * Finds similar assessments from a provided list
 * @param {Object} currentAssessment - Current assessment to compare
 * @param {Array} allItems - All list items from SharePoint
 * @returns {Array} Similar assessments
 */
function findSimilarAssessments(currentAssessment, allItems) {
    try {
        console.log(`Analyzing ${allItems.length} items for similarity`);
        
        // Extract current assessment details for comparison
        const currentCity = currentAssessment.City || '';
        const currentEventType = typeof currentAssessment.EventCausedDamage === 'object' 
            ? currentAssessment.EventCausedDamage?.Value 
            : currentAssessment.EventCausedDamage || '';
        const currentContact = currentAssessment.Contact_x0020_Name || '';
        const currentId = currentAssessment.ID;
        
        console.log('Current assessment:', { 
            id: currentId,
            city: currentCity, 
            eventType: currentEventType, 
            contact: currentContact 
        });
        
        // Filter for similar items (exclude current item)
        const similarItems = allItems.filter(item => {
            // Exclude the current item
            if (item.ID === currentId) {
                return false;
            }
            
            const itemCity = item.City || '';
            const itemEventType = item.EventCausedDamage?.Value || item.EventCausedDamage || '';
            const itemContact = item.Contact_x0020_Name || '';
            
            // Match if same city OR same event type OR same contact
            const cityMatch = currentCity && itemCity && itemCity.toLowerCase() === currentCity.toLowerCase();
            const eventMatch = currentEventType && itemEventType && itemEventType.toLowerCase() === currentEventType.toLowerCase();
            const contactMatch = currentContact && itemContact && itemContact.toLowerCase() === currentContact.toLowerCase();
            
            return cityMatch || eventMatch || contactMatch;
        });
        
        console.log(`Found ${similarItems.length} similar assessments`);
        
        // Sort by most similar (same city + same event type = highest priority)
        similarItems.sort((a, b) => {
            const aCity = (a.City || '').toLowerCase();
            const aEvent = (a.EventCausedDamage?.Value || a.EventCausedDamage || '').toLowerCase();
            const bCity = (b.City || '').toLowerCase();
            const bEvent = (b.EventCausedDamage?.Value || b.EventCausedDamage || '').toLowerCase();
            
            const currentCityLower = currentCity.toLowerCase();
            const currentEventLower = (currentEventType || '').toLowerCase();
            
            const aScore = (aCity === currentCityLower ? 2 : 0) + (aEvent === currentEventLower ? 2 : 0);
            const bScore = (bCity === currentCityLower ? 2 : 0) + (bEvent === currentEventLower ? 2 : 0);
            
            return bScore - aScore;
        });
        
        // Return top 10 most similar
        return similarItems.slice(0, 10);
        
    } catch (error) {
        console.error('Error finding similar assessments:', error);
        return [];
    }
}

/**
 * Calls AI endpoint to analyze similar assessments
 * @param {Object} currentAssessment - Current assessment
 * @param {Array} similarAssessments - Similar assessments from SharePoint
 * @returns {Promise<string>} AI-generated summary
 */
async function getAISummary(currentAssessment, similarAssessments) {
    const aiEndpoint = await getSecretValue('AI_ENDPOINT_URL', { optional: true });
    const aiApiKey = await getSecretValue('AI_API_KEY', { optional: true });

    if (!aiEndpoint) {
        console.log('AI endpoint not configured, skipping AI analysis');
        return `Found ${similarAssessments.length} similar assessment(s) in the system.`;
    }

    try {
        // Extract proper values
        const eventType = typeof currentAssessment.EventCausedDamage === 'object' 
            ? currentAssessment.EventCausedDamage?.Value 
            : currentAssessment.EventCausedDamage;
        
        const location = [currentAssessment.DispName, currentAssessment.City, currentAssessment.State]
            .filter(x => x).join(', ') || 'Unknown';
        
        // Format similar assessments
        const similarList = similarAssessments.map((item, idx) => {
            const itemEventType = item.EventCausedDamage?.Value || item.EventCausedDamage || 'Unknown';
            const itemStatus = item.Status?.Value || item.Status || 'Unknown';
            const itemLocation = [item.City, item.State].filter(x => x).join(', ') || 'Unknown';
            return `${idx + 1}. "${item.Title}" - ${itemEventType} at ${itemLocation} - Status: ${itemStatus}`;
        }).join('\n');
        
        const prompt = `Analyze this task/incident and provide a brief summary of similar incidents:

Current Assessment:
- Title: "${currentAssessment.Title}"
- Location: ${location}
- Event Type: ${eventType}
- Immediate Needs: ${currentAssessment.ImmediateNeedsRequired ? 'Yes' : 'No'}
- Contact: ${currentAssessment.Contact_x0020_Name}

Similar Incidents Found (${similarAssessments.length}):
${similarList || 'None'}

Provide a 2-3 sentence summary highlighting patterns, common event types or locations, common people, and any recommended actions. Focus on highlighting the specifics of similar, recent, incidents. This is for incidents across the city of perth so calling out 'city wide' is less helpful than localised trends to specific locations, common streets etc. If no similar incidents, note this is a new type of event for this location.`;

        const response = await axios.post(
            aiEndpoint,
            {
                messages: [
                    { role: 'system', content: 'You are a city operations analyst looking at receiving, triaging and recommending a response to incidents/items across a city.' },
                    { role: 'user', content: prompt }
                ],
                max_tokens: 200
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${aiApiKey}`
                }
            }
        );

        const aiText = response.data.choices?.[0]?.message?.content || 
               `Found ${similarAssessments.length} similar assessment(s) in the area.`;
        
        // Format the top 2 similar events in a readable list
        let formattedResponse = aiText;
        if (similarAssessments.length > 0) {
            const topTwo = similarAssessments.slice(0, 2);
            const eventsList = topTwo.map((item, index) => {
                const itemEventType = item.EventCausedDamage?.Value || item.EventCausedDamage || 'N/A';
                const itemLocation = [item.City, item.State].filter(x => x).join(', ') || 'N/A';
                const itemDate = item.Created ? new Date(item.Created).toLocaleDateString() : 'N/A';
                const itemStatus = item.Status?.Value || item.Status || 'N/A';
                return `${index + 1}. **${itemEventType}** in ${itemLocation} (${itemDate}) - Status: ${itemStatus}`;
            }).join('  \n');
            
            formattedResponse = `${aiText}\n\n**Recent Similar Events:**  \n${eventsList}`;
        }
        
        return formattedResponse;
    } catch (error) {
        console.error('AI analysis error:', error.message);
        return `Found ${similarAssessments.length} similar assessment(s). AI analysis unavailable.`;
    }
}

/**
 * Posts adaptive card to Teams channel
 * @param {Object} card - Adaptive card JSON
 * @returns {Promise<void>}
 */
async function postToTeams(card) {
    const webhookUrl = await getSecretValue('TEAMS_WEBHOOK_URL', { optional: true });
    
    if (!webhookUrl) {
        throw new Error('TEAMS_WEBHOOK_URL not configured');
    }

    await axios.post(webhookUrl, card, {
        headers: { 'Content-Type': 'application/json' }
    });
}

/**
 * Azure Function: Post Assessment Card
 * Triggered by Logic App when new SharePoint list item is created
 */
app.http('postAssessmentCard', {
    methods: ['POST'],
    authLevel: 'function',
    handler: async (request, context) => {
        try {
            context.log('Processing new TEOC assessment...');

            const assessment = await request.json();
            
            // Validate required fields
            if (!assessment.ID || !assessment.Title) {
                return {
                    status: 400,
                    body: JSON.stringify({ error: 'Missing required assessment fields' })
                };
            }

            // Get configuration
            const siteUrl = process.env.SHAREPOINT_SITE_URL;
            const listId = process.env.SHAREPOINT_LIST_ID;
            const functionBaseUrl = process.env.FUNCTION_BASE_URL

            // Add site and list context to assessment
            assessment.SiteUrl = siteUrl;
            assessment.ListId = listId;

            // Parse prior items from trigger (already queried by Logic App)
            context.log('Parsing prior items from trigger...');
            let allItems = [];
            if (assessment.PriorItems) {
                try {
                    const priorItemsData = typeof assessment.PriorItems === 'string' 
                        ? JSON.parse(assessment.PriorItems)
                        : assessment.PriorItems;
                    allItems = priorItemsData.value || [];
                    context.log(`Received ${allItems.length} prior items from trigger`);
                } catch (parseError) {
                    context.warn('Failed to parse PriorItems:', parseError.message);
                }
            }
            
            // Find similar assessments from the prior items list
            context.log('Finding similar assessments from prior items...');
            const similarAssessments = findSimilarAssessments(assessment, allItems);
            context.log(`Found ${similarAssessments.length} similar assessments`);
            
            // Get AI analysis
            context.log('Getting AI analysis...');
            const aiSummary = await getAISummary(assessment, similarAssessments);

            // Create adaptive card
            context.log('Creating adaptive card...');
            const card = createAdaptiveCard(assessment, aiSummary, functionBaseUrl);

            // Post to Teams
            context.log('Posting to Teams...');
            await postToTeams(card);

            context.log('Successfully posted assessment card to Teams');

            return {
                status: 200,
                body: JSON.stringify({ 
                    success: true, 
                    message: 'Adaptive card posted successfully',
                    similarItemsFound: similarAssessments.length
                })
            };

        } catch (error) {
            context.error('Error processing assessment:', error);
            return {
                status: 500,
                body: JSON.stringify({ 
                    error: 'Failed to process assessment',
                    details: error.message 
                })
            };
        }
    }
});
