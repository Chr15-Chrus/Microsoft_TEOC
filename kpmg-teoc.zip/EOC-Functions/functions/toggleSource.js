const { app } = require('@azure/functions');
const { getDataSourcesTableClient } = require('../utils/data-sources');
const { requireAuth } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit-logger');

/**
 * Toggle a data source's active state
 * Requires SourceAdmin role
 */
app.http('toggleSource', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'toggleSource',
    handler: async (request, context) => {
        context.log('toggleSource function called');

        // Authenticate and check role
        const user = await requireAuth(request, ['SourceAdmin', 'Admin']);
        if (!user) {
            return {
                status: 401,
                jsonBody: { 
                    error: 'Unauthorized',
                    message: 'Valid authentication required with SourceAdmin or Admin role'
                }
            };
        }

        const body = await request.json();
        const { id } = body;

        if (!id) {
            return {
                status: 400,
                jsonBody: { error: 'Missing source ID' }
            };
        }

        try {
            const tableClient = await getDataSourcesTableClient(context);
            const entity = await tableClient.getEntity('source', id);
            const previousState = entity.active;
            entity.active = !entity.active;
            entity.modifiedDate = new Date().toISOString();
            entity.modifiedBy = user.email;

            await tableClient.updateEntity(entity, 'Replace');

            // Log audit event
            await logAuditEvent({
                action: 'TOGGLE_SOURCE',
                userId: user.id,
                userEmail: user.email,
                resourceType: 'DataSource',
                resourceId: id,
                details: {
                    previousState,
                    newState: entity.active,
                    sourceName: entity.name
                }
            }, context);

            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                jsonBody: { success: true, active: entity.active }
            };
        } catch (error) {
            context.error('Error toggling source:', error);
            return {
                status: 500,
                jsonBody: { error: 'Failed to toggle source', message: error.message }
            };
        }
    }
});
