const { app } = require('@azure/functions');
const { TableClient } = require('@azure/data-tables');
const { getDataSourcesTableClient, resolveStorageConnectionString } = require('../utils/data-sources');
const { requireAuth } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit-logger');
const { unregisterSharePointWebhook } = require('../utils/sharepoint-source-manager');

/**
 * Delete a data source and clean up related resources
 * Requires SourceAdmin role
 */
app.http('deleteSource', {
    methods: ['DELETE'],
    authLevel: 'anonymous',
    route: 'deleteSource',
    handler: async (request, context) => {
        context.log('deleteSource function called');

        // Authenticate and check role
        const user = await requireAuth(request, ['SourceAdmin', 'Admin']);
        if (!user) {
            return {
                status: 401,
                jsonBody: { 
                    error: 'Unauthorized',
                    message: 'Valid authentication required with SourceAdmin or Admin role'
                }
            };
        }

        const body = await request.json();
        const { id } = body;

        if (!id) {
            return {
                status: 400,
                jsonBody: { error: 'Missing source ID' }
            };
        }

        try {
            const tableClient = await getDataSourcesTableClient(context);

            // Get source to check if it exists and get webhook info
            const entity = await tableClient.getEntity('source', id);

            // Unregister SharePoint webhook if exists
            if (entity.type === 'sharepoint' && entity.webhookId && entity.siteUrl && entity.listId) {
                try {
                    await unregisterSharePointWebhook({
                        siteUrl: entity.siteUrl,
                        siteGraphId: entity.siteGraphId,
                        listId: entity.listId,
                        webhookId: entity.webhookId
                    }, context);
                    context.log(`Webhook ${entity.webhookId} unregistered successfully`);
                } catch (webhookError) {
                    context.warn(`Failed to unregister webhook: ${webhookError.message}`);
                    // Continue with deletion even if webhook unregistration fails
                }
            }

            // Delete the source
            await tableClient.deleteEntity('source', id);

            // Delete webhook secret if exists
            try {
                const secretsConnection = await resolveStorageConnectionString();
                const secretsTableClient = TableClient.fromConnectionString(secretsConnection, 'WebhookSecrets');
                await secretsTableClient.deleteEntity('webhook', id);
            } catch (secretError) {
                context.warn('Failed to delete webhook secret:', secretError);
            }

            // Log audit event
            await logAuditEvent({
                action: 'DELETE_SOURCE',
                userId: user.id,
                userEmail: user.email,
                resourceType: 'DataSource',
                resourceId: id,
                details: {
                    sourceType: entity.type,
                    sourceName: entity.name,
                    webhookId: entity.webhookId
                }
            }, context);

            return {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
                jsonBody: { success: true, message: 'Source deleted successfully' }
            };
        } catch (error) {
            context.error('Error deleting source:', error);
            return {
                status: 500,
                jsonBody: { error: 'Failed to delete source', message: error.message }
            };
        }
    }
});
