const { app } = require('@azure/functions');
const { listSources, getDataSourcesTableClient } = require('../utils/data-sources');
const { 
    registerSharePointWebhook, 
    updateSharePointWebhook,  // ADD THIS
    unregisterSharePointWebhook, // ADD THIS
    storeWebhookClientState 
} = require('../utils/sharepoint-source-manager');

/**
 * Timer-triggered function to renew expiring SharePoint webhooks
 * Runs daily to check for subscriptions expiring within 30 days
 */
app.timer('renewWebhooks', {
    schedule: '0 0 2 * * *', // Run daily at 2 AM UTC
    handler: async (myTimer, context) => {
        context.log('Webhook renewal timer triggered');

        try {
            // Get all active SharePoint sources
            const sources = await listSources(context, { includeInactive: false });
            const sharePointSources = sources.filter(s => s.type === 'sharepoint' && s.webhookId && s.webhookExpiration);

            context.log(`Found ${sharePointSources.length} SharePoint sources with webhooks`);

            const now = new Date();
            // CHANGE: Reduce threshold to 1 day since webhooks expire in 2 days
            const renewalThreshold = new Date(now.getTime() + (1 * 24 * 60 * 60 * 1000)); // 1 day from now

            const renewed = [];
            const failed = [];
            const skipped = [];

            for (const source of sharePointSources) {
                try {
                    const expirationDate = new Date(source.webhookExpiration);
                    
                    // Skip if webhook doesn't expire within 1 day
                    if (expirationDate > renewalThreshold) {
                        context.log(`Skipping ${source.name}: expires ${expirationDate.toISOString()}`);
                        skipped.push({
                            sourceId: source.rowKey,
                            name: source.name,
                            expiresAt: source.webhookExpiration,
                            reason: 'Not expiring soon'
                        });
                        continue;
                    }

                    context.log(`Renewing webhook for ${source.name} (expires ${expirationDate.toISOString()})`);

                    let webhookInfo;
                    
                    // Try to UPDATE existing webhook first (PATCH)
                    try {
                        webhookInfo = await updateSharePointWebhook({
                            siteGraphId: source.siteGraphId,
                            listId: source.listId,
                            webhookId: source.webhookId,
                            sourceId: source.rowKey
                        }, context);
                        
                        context.log(`Successfully updated webhook ${source.webhookId} for ${source.name}`);
                        
                    } catch (updateError) {
                        // If update fails (webhook expired/deleted), delete old one and create new one
                        context.warn(`Update failed, recreating webhook: ${updateError.message}`);
                        
                        // Try to delete the old webhook (may already be gone)
                        try {
                            await unregisterSharePointWebhook({
                                siteUrl: source.siteUrl,
                                siteGraphId: source.siteGraphId,
                                listId: source.listId,
                                webhookId: source.webhookId
                            }, context);
                            context.log(`Deleted expired webhook ${source.webhookId}`);
                        } catch (deleteError) {
                            context.warn(`Could not delete old webhook (may already be gone): ${deleteError.message}`);
                        }
                        
                        // Create a new webhook subscription
                        webhookInfo = await registerSharePointWebhook({
                            siteUrl: source.siteUrl,
                            siteGraphId: source.siteGraphId,
                            listId: source.listId,
                            sourceId: source.rowKey
                        }, context);
                        
                        context.log(`Created new webhook ${webhookInfo.id} for ${source.name}`);
                    }

                    // Update the source entity with webhook info
                    const tableClient = await getDataSourcesTableClient(context);
                    const entity = await tableClient.getEntity('source', source.rowKey);
                    entity.webhookId = webhookInfo.id;
                    entity.webhookUrl = webhookInfo.url || entity.webhookUrl; // Keep existing URL if not returned
                    entity.webhookExpiration = webhookInfo.expirationDateTime;
                    entity.siteGraphId = entity.siteGraphId || webhookInfo.siteGraphId;
                    entity.modifiedDate = new Date().toISOString();
                    entity.modifiedBy = 'system:webhook-renewal';

                    await tableClient.updateEntity(entity, 'Replace');

                    context.log(`Successfully renewed webhook for ${source.name}, new expiration: ${webhookInfo.expirationDateTime}`);
                    renewed.push({
                        sourceId: source.rowKey,
                        name: source.name,
                        webhookId: webhookInfo.id,
                        expiresAt: webhookInfo.expirationDateTime
                    });

                } catch (error) {
                    context.error(`Failed to renew webhook for ${source.name}:`, error.message);
                    failed.push({
                        sourceId: source.rowKey,
                        name: source.name,
                        error: error.message
                    });
                }
            }

            const summary = {
                total: sharePointSources.length,
                renewed: renewed.length,
                failed: failed.length,
                skipped: skipped.length,
                details: {
                    renewed,
                    failed,
                    skipped
                }
            };

            context.log('Webhook renewal summary:', JSON.stringify(summary, null, 2));

            // Send alert if there were failures
            if (failed.length > 0) {
                context.warn(`WARNING: ${failed.length} webhook renewal(s) failed!`);
                // TODO: In production, send an email/Teams notification to admins
            }

        } catch (error) {
            context.error('Error in webhook renewal timer:', error);
            throw error;
        }
    }
});
