const { app } = require('@azure/functions');
const {
    CloudAdapter,
    ConfigurationBotFrameworkAuthentication,
    TurnContext,
    CardFactory,
    ActivityTypes
} = require('botbuilder');
const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
const axios = require('axios');
const { getSecretValue } = require('../utils/secretProvider');

let adapterInstance;

async function getAdapter() {
    if (adapterInstance) {
        return adapterInstance;
    }

    const microsoftAppId = await getSecretValue('MICROSOFT_APP_ID');
    const microsoftAppPassword = await getSecretValue('MICROSOFT_APP_PASSWORD');

    const botFrameworkAuthentication = new ConfigurationBotFrameworkAuthentication({
      MicrosoftAppId: process.env.MicrosoftAppId,
      MicrosoftAppPassword: process.env.MicrosoftAppPassword,
      MicrosoftAppTenantId: process.env.MicrosoftAppTenantId,
    });

    const adapter = new CloudAdapter(botFrameworkAuthentication);
    adapter.onTurnError = async (context, error) => {
        console.error(`\n [onTurnError] unhandled error: ${error}`);
        await context.sendActivity('The bot encountered an error.');
    };

    adapterInstance = adapter;
    return adapterInstance;
}

/**
 * Creates an adaptive card for TEOC assessment
 */
function createBotAdaptiveCard(assessment, showAcknowledged = false) {
    const eventType = typeof assessment.EventCausedDamage === 'object' 
        ? assessment.EventCausedDamage?.Value 
        : assessment.EventCausedDamage;
    
    const status = typeof assessment.Status === 'object'
        ? assessment.Status?.Value || 'New'
        : assessment.Status || 'New';
    
    const locationString = [assessment.DispName, assessment.City, assessment.State, assessment.CountryOrRegion]
        .filter(x => x).join(', ') || 'Unknown Location';
    
    const card = {
        type: "AdaptiveCard",
        $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
        version: "1.4",
        body: [
            {
                type: "TextBlock",
                text: "🚨 TEOC Emergency Assessment",
                weight: "Bolder",
                size: "Large",
                color: showAcknowledged ? "Good" : "Attention"
            },
            {
                type: "TextBlock",
                text: assessment.Title || "Untitled Assessment",
                weight: "Bolder",
                size: "Medium",
                wrap: true
            },
            {
                type: "FactSet",
                facts: [
                    { title: "Contact:", value: `${assessment.Contact_x0020_Name || 'N/A'} (${assessment.ContactPhoneNumber || 'No phone'})` },
                    { title: "Location:", value: locationString },
                    { title: "Event Type:", value: eventType },
                    { title: "Immediate Needs:", value: assessment.ImmediateNeedsRequired ? "⚠️ YES" : "No" },
                    { title: "Status:", value: status },
                    { title: "Acknowledged By:", value: assessment.Acknowledged || 'Not yet acknowledged' }
                ]
            }
        ],
        actions: []
    };
    
    // Add action buttons if not acknowledged
    if (!showAcknowledged) {
        card.actions.push(
            {
                type: "Action.Submit",
                title: "✅ Acknowledge",
                data: {
                    action: "acknowledge",
                    itemId: assessment.ID,
                    listId: assessment.ListId,
                    siteUrl: assessment.SiteUrl
                }
            },
            {
                type: "Action.Submit",
                title: "📋 Set to Pending",
                data: {
                    action: "pending",
                    itemId: assessment.ID,
                    listId: assessment.ListId,
                    siteUrl: assessment.SiteUrl
                }
            },
            {
                type: "Action.Submit",
                title: "⏸️ Put on Hold",
                data: {
                    action: "hold",
                    itemId: assessment.ID,
                    listId: assessment.ListId,
                    siteUrl: assessment.SiteUrl
                }
            },
            {
                type: "Action.Submit",
                title: "✔️ Mark Complete",
                data: {
                    action: "complete",
                    itemId: assessment.ID,
                    listId: assessment.ListId,
                    siteUrl: assessment.SiteUrl
                }
            }
        );
    }
    
    return card;
}

/**
 * Updates SharePoint list item based on action
 */
async function updateAssessment(action, itemId, listId, siteUrl, userEmail) {
    const accessToken = await getSharePointAccessToken();
    const apiUrl = `${siteUrl}/_api/web/lists(guid'${listId}')/items(${itemId})`;
    
    // Get current item
    const getResponse = await axios.get(apiUrl, {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json;odata=verbose'
        }
    });
    
    const etag = getResponse.data.d.__metadata.etag;
    const updates = {};
    
    // Determine updates based on action
    switch (action) {
        case 'acknowledge':
            updates.Acknowledged = userEmail;
            break;
        case 'pending':
            updates.Status = 'Pending';
            break;
        case 'hold':
            updates.Status = 'On Hold';
            break;
        case 'complete':
            updates.Status = 'Completed';
            break;
    }
    
    // Update SharePoint
    await axios.post(
        apiUrl,
        {
            __metadata: { type: getResponse.data.d.__metadata.type },
            ...updates
        },
        {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'IF-MATCH': etag,
                'X-HTTP-Method': 'MERGE'
            }
        }
    );
    
    // Get updated item
    const updatedResponse = await axios.get(apiUrl, {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json;odata=verbose'
        }
    });
    
    return updatedResponse.data.d;
}

/**
 * Main bot message handler
 */
async function handleBotMessage(context) {
    // Handle bot installation / conversation update
    if (context.activity.type === ActivityTypes.ConversationUpdate) {
        if (context.activity.membersAdded && context.activity.membersAdded.length > 0) {
            for (const member of context.activity.membersAdded) {
                if (member.id !== context.activity.recipient.id) {
                    // Bot was added to conversation
                    const conversationRef = TurnContext.getConversationReference(context.activity);
                    console.log('🎉 Bot added to conversation!');
                    console.log('📋 Save these values to Azure Function App Settings:');
                    console.log('TEAMS_CONVERSATION_ID =', conversationRef.conversation.id);
                    console.log('TEAMS_SERVICE_URL =', conversationRef.serviceUrl);
                    
                    await context.sendActivity(
                        `✅ TEOC Bot is ready!\n\n` +
                        `**Configuration Required:**\n` +
                        `Add these settings to your Azure Function App:\n` +
                        `\`\`\`\n` +
                        `TEAMS_CONVERSATION_ID = ${conversationRef.conversation.id}\n` +
                        `TEAMS_SERVICE_URL = ${conversationRef.serviceUrl}\n` +
                        `\`\`\`\n\n` +
                        `Then update your Logic App to call:\n` +
                        `\`https://<your-function-app>.azurewebsites.net/api/postBotCard\``
                    );
                }
            }
        }
        return;
    }
    
    if (context.activity.type === ActivityTypes.Message) {
        
        // Handle adaptive card button submissions
        if (context.activity.value) {
            const data = context.activity.value;
            const userEmail = context.activity.from.aadObjectId || context.activity.from.name;
            
            console.log('Button clicked:', data.action, 'by', userEmail);
            
            try {
                // Update SharePoint
                const updatedItem = await updateAssessment(
                    data.action,
                    data.itemId,
                    data.listId,
                    data.siteUrl,
                    userEmail
                );
                
                // Add updated fields to the item
                updatedItem.SiteUrl = data.siteUrl;
                updatedItem.ListId = data.listId;
                
                // Create updated card
                const updatedCard = createBotAdaptiveCard(updatedItem, data.action === 'acknowledge');
                
                // Update the card in place
                await context.updateActivity({
                    type: ActivityTypes.Message,
                    id: context.activity.replyToId,
                    attachments: [CardFactory.adaptiveCard(updatedCard)]
                });
                
                // Send confirmation message
                await context.sendActivity(`✅ Assessment ${data.action} by ${userEmail}`);
                
            } catch (error) {
                console.error('Error processing action:', error);
                await context.sendActivity(`❌ Error: ${error.message}`);
            }
        } else {
            // Regular text message
            await context.sendActivity('Send assessment data as JSON to create a card.');
        }
    }
}

/**
 * Azure Function endpoint for Teams Bot
 */
app.http('teocBot', {
  methods: ['POST', 'GET'],
  authLevel: 'anonymous',
  handler: async (request, context) => {
    try {
      if (request.method === 'GET') {
        return { status: 200, body: 'Bot endpoint is active' };
      }

      const adapter = await getAdapter();

      // Bot Framework sends the activity JSON in body + auth header
      const activity = await request.json();
      const authHeader = request.headers.get('authorization') || '';

      await adapter.processActivity(authHeader, activity, async (turnContext) => {
        await handleBotMessage(turnContext);
      });

      return { status: 200 };
    } catch (error) {
      context.error('Bot error:', error);
      return { status: 500, body: JSON.stringify({ error: error.message }) };
    }
  }
});


/**
 * Proactive message function - called by Logic App
 */
app.http('postBotCard', {
    methods: ['POST'],
    authLevel: 'function',
    handler: async (request, context) => {
        try {
            const assessment = await request.json();
            
            // Create adaptive card
            const card = createBotAdaptiveCard(assessment);
            
            // Post proactive message to Teams
            // Note: You need to store the conversation reference when bot is first added
            const conversationId = process.env.TEAMS_CONVERSATION_ID;
            const serviceUrl = process.env.TEAMS_SERVICE_URL;
            
            if (!conversationId || !serviceUrl) {
                throw new Error('Teams conversation not configured');
            }
            
            const conversationReference = {
                channelId: 'msteams',
                serviceUrl: serviceUrl,
                conversation: { id: conversationId }
            };
            
            const adapter = await getAdapter();
            await adapter.continueConversation(conversationReference, async (turnContext) => {
                await turnContext.sendActivity({
                    attachments: [CardFactory.adaptiveCard(card)]
                });
            });
            
            return {
                status: 200,
                body: JSON.stringify({ success: true, message: 'Card posted to Teams' })
            };
            
        } catch (error) {
            context.error('Error posting card:', error);
            return {
                status: 500,
                body: JSON.stringify({ error: error.message })
            };
        }
    }
});

module.exports = { createBotAdaptiveCard, updateAssessment };
