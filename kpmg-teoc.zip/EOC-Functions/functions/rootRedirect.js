const { app } = require('@azure/functions');

// Redirect requests to the site root to the web UI under /web/
app.http('rootRedirect', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: '',
  handler: async (request, context) => {
    try {
      // Use 302 so browsers update location but do not cache aggressively
      return {
        status: 302,
        headers: {
          Location: '/web/'
        },
        body: ''
      };
    } catch (err) {
      context.error('Error in root redirect:', err);
      return {
        status: 500,
        body: 'Internal server error'
      };
    }
  }
});
