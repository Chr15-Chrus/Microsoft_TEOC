const { app } = require('@azure/functions');
const { EventGridPublisherClient, AzureKeyCredential } = require('@azure/eventgrid');
const { DefaultAzureCredential } = require('@azure/identity');
const crypto = require('crypto');
const { mapSharePointToCommonFormat, mapDynamicsToCommonFormat, validateEvent } = require('../utils/event-mapper');
const { findSourceByListId, getSourceById } = require('../utils/data-sources');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Generate a UUID - uses crypto.randomUUID if available, otherwise generates manually
 * @returns {string} UUID string
 */
function generateUUID() {
    if (crypto.randomUUID) {
        return crypto.randomUUID();
    }
    // RFC 4122 v4 UUID fallback for older Node versions
    const bytes = crypto.randomBytes(16);
    // Set version (4) and variant (10xx)
    bytes[6] = (bytes[6] & 0x0f) | 0x40; // Version 4
    bytes[8] = (bytes[8] & 0x3f) | 0x80; // Variant 10xx
    const hex = bytes.toString('hex');
    return (
        hex.slice(0, 8) + '-' +
        hex.slice(8, 12) + '-' +
        hex.slice(12, 16) + '-' +
        hex.slice(16, 20) + '-' +
        hex.slice(20, 32)
    );
}

/**
 * HTTP triggered function to publish events to Event Grid
 * Accepts events from various sources (SharePoint, Dynamics, custom) and normalizes them
 * Validates that the source exists and is active in DataSources table
 */
app.http('publishEvent', {
  methods: ['POST'],
  authLevel: 'function',
  route: 'publishEvent',
  handler: async (request, context) => {
    context.log('publishEvent function received a request.');

    const topicEndpoint = process.env.EVENT_GRID_TOPIC_ENDPOINT;
    const topicKey = await getSecretValue('EVENT_GRID_TOPIC_KEY', { optional: true });

      if (!topicEndpoint) {
      context.error('EVENT_GRID_TOPIC_ENDPOINT not set');
      return { status: 500, body: 'Event Grid configuration missing' };
    }

    // Initialize Event Grid client
    let client;
    const useMsi = (process.env.EVENT_GRID_USE_MSI || 'false').toLowerCase() === 'true';
    if (useMsi) {
      const credential = new DefaultAzureCredential();
      client = new EventGridPublisherClient(topicEndpoint, credential);
    } else {
      if (!topicKey) {
        context.error('EVENT_GRID_TOPIC_KEY not set and MSI not enabled');
        return { status: 500, body: 'Event Grid authentication not configured' };
      }
      client = new EventGridPublisherClient(topicEndpoint, new AzureKeyCredential(topicKey));
    }

    const payload = await request.json();
    if (!payload) {
      return { status: 400, body: 'Missing event payload' };
    }

    try {
      let teocEvent;

      // Check if already in TEOC format (has CloudEvents fields)
      if (payload.id && payload.source && payload.specversion) {
        // Already in TEOC/CloudEvents format
        teocEvent = payload;
        context.log('Event already in TEOC format');
      } else {
        // Need to map from source format
        const sourceType = payload.sourceType || payload.source || 'unknown';
        
        context.log('Mapping event from source:', sourceType);

        if (sourceType === 'sharepoint' || sourceType.includes('sharepoint')) {
          // Resolve and validate SharePoint source
          const listId = payload.sourceListId || payload.listId;
          if (!listId) {
            return {
              status: 400,
              jsonBody: {
                error: 'Missing required field: sourceListId or listId for SharePoint events'
              }
            };
          }

          const source = await findSourceByListId(listId, context);
          if (!source) {
            context.error(`SharePoint source not found for list ID: ${listId}`);
            return {
              status: 400,
              jsonBody: {
                error: 'Source not found',
                message: 'SharePoint list must be registered in DataSources table'
              }
            };
          }

          if (!source.active) {
            context.warn(`SharePoint source ${source.rowKey} is inactive, rejecting event`);
            return {
              status: 403,
              jsonBody: {
                error: 'Source inactive',
                message: 'The source for this event is currently inactive'
              }
            };
          }

          // Map SharePoint event
          teocEvent = mapSharePointToCommonFormat(
            payload,
            listId,
            source.siteUrl
          );
        } else if (sourceType === 'dynamics' || sourceType.includes('dynamics')) {
          // Resolve and validate Dynamics source
          const sourceId = payload.sourceId;
          if (sourceId) {
            try {
              const source = await getSourceById(sourceId, context);
              if (!source) {
                context.error(`Dynamics source not found: ${sourceId}`);
                return {
                  status: 400,
                  jsonBody: {
                    error: 'Source not found',
                    message: 'Dynamics source must be registered in DataSources table'
                  }
                };
              }

              if (!source.active) {
                context.warn(`Dynamics source ${source.rowKey} is inactive, rejecting event`);
                return {
                  status: 403,
                  jsonBody: {
                    error: 'Source inactive',
                    message: 'The source for this event is currently inactive'
                  }
                };
              }

              context.log(`Validated Dynamics source: ${source.name}`);
            } catch (error) {
              context.error('Failed to validate Dynamics source:', error.message);
              return {
                status: 400,
                jsonBody: {
                  error: 'Source validation failed',
                  message: 'Unable to validate source configuration from DataSources table'
                }
              };
            }
          }

          // Map Dynamics event
          teocEvent = mapDynamicsToCommonFormat(
            payload,
            payload.entityType || payload.sourceListId || 'incidents'
          );
        } else {
          // For custom sources, validate if sourceId is provided
          const sourceId = payload.sourceId;
          if (sourceId) {
            try {
              const source = await getSourceById(sourceId, context);
              if (!source || !source.active) {
                return {
                  status: 403,
                  jsonBody: {
                    error: 'Source not found or inactive',
                    message: 'Custom source must be registered and active in DataSources table'
                  }
                };
              }
              context.log(`Validated custom source: ${source.name}`);
            } catch (error) {
              context.error('Failed to validate custom source:', error.message);
            }
          }

          // Use payload as-is but wrap in CloudEvents format
          teocEvent = {
            id: payload.id || generateUUID(),
            source: payload.source || 'teoc://custom',
            specversion: '1.0',
            type: payload.eventType || payload.type || 'TEOC.Item.Created',
            datacontenttype: 'application/json',
            time: payload.time || new Date().toISOString(),
            subject: payload.subject || '/items/unknown',
            data: payload.data || payload
          };
        }
      }

      // Validate event format
      const validation = validateEvent(teocEvent);
      if (!validation.valid) {
        context.error('Event validation failed:', validation.errors);
        return {
          status: 400,
          jsonBody: {
            error: 'Invalid event format',
            details: validation.errors
          }
        };
      }

      // Log event details
      context.log('Publishing TEOC event:', {
        id: teocEvent.id,
        type: teocEvent.type,
        source: teocEvent.source,
        itemId: teocEvent.data?.itemId,
        title: teocEvent.data?.title
      });

      // Publish to Event Grid (CloudEvents schema)
      await client.send([{
        id: teocEvent.id,
        source: teocEvent.source,
        specversion: teocEvent.specversion,
        type: teocEvent.type,
        datacontenttype: teocEvent.datacontenttype,
        time: teocEvent.time,
        subject: teocEvent.subject,
        data: teocEvent.data,
        dataschema: teocEvent.dataschema
      }], {
        inputSchema: 'CloudEventSchemaV1_0'
      });

      context.log('Event published successfully');
      return {
        status: 200,
        jsonBody: {
          success: true,
          eventId: teocEvent.id,
          message: 'Event published to Event Grid'
        }
      };

    } catch (err) {
      context.error('Failed to publish event:', err);
      return {
        status: 500,
        jsonBody: {
          error: 'Failed to publish event',
          message: err.message
        }
      };
    }
  }
});
