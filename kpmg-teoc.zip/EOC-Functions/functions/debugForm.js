const { app } = require('@azure/functions');

app.http('debugForm', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'debugForm',
    handler: async (request, context) => {
        try {
            const body = await request.json().catch(() => null);
            context.log('DebugForm received headers:', request.headers || {});
            context.log('DebugForm received body:', body);

            return {
                status: 200,
                jsonBody: {
                    receivedHeaders: request.headers || {},
                    receivedBody: body
                }
            };
        } catch (err) {
            context.error('DebugForm error:', err);
            return { status: 500, jsonBody: { error: 'Debug endpoint error', message: err.message } };
        }
    }
});
