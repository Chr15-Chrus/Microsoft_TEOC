const { app } = require('@azure/functions');
const { TableClient } = require('@azure/data-tables');
const { resolveStorageConnectionString, findSourceByListId } = require('../utils/data-sources');
const { processSharePointChange } = require('../utils/sharepoint-change-processor');
const routingService = require('../utils/routing-service');
const { DefaultAzureCredential } = require('@azure/identity');
const { createEventNotificationCard, wrapCardForTeams } = require('../utils/adaptive-card-templates');
const { postMessageToTeamsChannel } = require('../utils/teamsGraphPoster');
const fetch = require('node-fetch');

/**
 * Extract list ID from SharePoint resource URL
 * Handles multiple SharePoint resource URL formats
 * @param {string} resource - SharePoint resource URL
 * @returns {string|null} - List ID or null if not found
 */
function extractListIdFromResource(resource) {
    if (!resource) return null;

    // If resource is already a GUID
    const guidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (guidRegex.test(resource)) return resource;
    
    // Try common patterns:
    // - web/lists(guid'list-id')
    // - Lists/list-id
    // - lists/list-id
    const patterns = [
        /lists\(guid'([^']+)'\)/i,
        /Lists\/([a-f0-9-]{36})/i,
        /lists\/([a-f0-9-]{36})/i
    ];
    
    for (const pattern of patterns) {
        const match = resource.match(pattern);
        if (match) return match[1];
    }
    
    return null;
}

/**
 * SharePoint Webhook Gateway
 * Receives and validates SharePoint webhook notifications
 * Resolves source metadata from DataSources table
 * Publishes change notifications for further processing
 */
app.http('webhookGateway', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    route: 'webhookGateway',
    handler: async (request, context) => {
        try {
            // Parse validation query parameter (SharePoint sends this during subscription validation)
            const validationToken = request.query.get('validationtoken');
            
            // Handle validation request
            if (validationToken) {
                context.log('SharePoint webhook validation request received');
                return {
                    status: 200,
                    headers: { 'Content-Type': 'text/plain' },
                    body: validationToken
                };
            }

            // Parse webhook notification body
            const body = await request.json();
            context.log('Webhook notification received:', JSON.stringify(body, null, 2));

            if (!body || !body.value || !Array.isArray(body.value)) {
                context.warn('Invalid webhook payload format');
                return {
                    status: 400,
                    jsonBody: { error: 'Invalid payload format' }
                };
            }

            const connectionString = await resolveStorageConnectionString();
            if (!connectionString) {
                context.error('Storage connection not configured');
                return {
                    status: 500,
                    jsonBody: { error: 'Server configuration error' }
                };
            }

            const secretsClient = TableClient.fromConnectionString(connectionString, 'WebhookSecrets');
            const notifications = body.value;
            const processedNotifications = [];

            // Process each notification
            for (const notification of notifications) {
                try {
                    const { subscriptionId, clientState, resource, siteUrl } = notification;

                    if (!subscriptionId || !clientState || !resource) {
                        context.warn('Notification missing required fields:', notification);
                        continue;
                    }

                    // Extract list ID from resource URL using utility function
                    const listId = extractListIdFromResource(resource);
                    if (!listId) {
                        context.warn('Could not extract list ID from resource:', resource);
                        continue;
                    }

                    // Resolve source from DataSources by listId
                    const source = await findSourceByListId(listId, context);
                    if (!source) {
                        context.warn(`No source found for list ID: ${listId}`);
                        continue;
                    }

                    if (!source.active) {
                        context.log(`Source ${source.rowKey} is inactive, skipping notification`);
                        continue;
                    }

                    // Validate clientState against WebhookSecrets
                    let expectedClientState;
                    try {
                        const secretEntity = await secretsClient.getEntity('webhook', source.rowKey);
                        expectedClientState = secretEntity.clientState;
                    } catch (error) {
                        context.error(`Failed to retrieve webhook secret for source ${source.rowKey}:`, error.message);
                        continue;
                    }

                    if (clientState !== expectedClientState) {
                        context.error(`Client state mismatch for subscription ${subscriptionId}. Expected: ${expectedClientState}, Received: ${clientState}`);
                        continue;
                    }

                    context.log(`Valid notification for source: ${source.rowKey} (${source.name})`);

                    // Process SharePoint change: fetch item, normalize, check dedupe
                    try {
                        const eventData = await processSharePointChange(source, notification, context);
                        
                        if (!eventData) {
                            // Duplicate or no items found
                            context.log('No event data to process (duplicate or empty list)');
                            continue;
                        }
                        
                        // Determine routing
                        const routes = await routingService.determineRoutes(eventData);
                        
                        if (!routes || routes.length === 0) {
                            context.warn('No routes determined for event', eventData.itemId);
                            continue;
                        }
                        
                        context.log('Routing determined:', {
                            itemId: eventData.itemId,
                            routeCount: routes.length,
                            routes: routes.map(r => ({
                                teamId: r.teamId,
                                teamName: r.teamName,
                                reason: r.reason
                            }))
                        });
                        
                        // Broadcast via SignalR and post to Teams
                        const broadcastResult = await broadcastEvent(eventData, routes, source, context);
                        
                        processedNotifications.push({
                            sourceId: source.rowKey,
                            sourceName: source.name,
                            itemId: eventData.itemId,
                            title: eventData.title,
                            routes: routes.length,
                            signalR: broadcastResult.signalR,
                            teams: broadcastResult.teams
                        });
                        
                    } catch (processingError) {
                        context.error('Error processing SharePoint change:', {
                            error: processingError.message,
                            stack: processingError.stack,
                            sourceId: source.rowKey,
                            sourceName: source.name,
                            listId: listId,
                            subscriptionId: subscriptionId
                        });
                        // Continue processing other notifications
                    }

                } catch (notificationError) {
                    context.error('Error processing notification:', notificationError);
                    // Continue processing other notifications
                }
            }

            return {
                status: 200,
                jsonBody: {
                    success: true,
                    processed: processedNotifications.length,
                    total: notifications.length
                }
            };

        } catch (error) {
            context.error('Error in webhook gateway:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Internal server error',
                    message: error.message
                }
            };
        }
    }
});

/**
 * Broadcast event to SignalR groups and post to Teams webhooks
 * @param {Object} eventData - Normalized event data
 * @param {Array} routes - Routes determined by routing service
 * @param {Object} source - DataSource entity
 * @param {Object} context - Function context
 * @returns {Promise<Object>} Results of broadcast and Teams posting
 */
async function broadcastEvent(eventData, routes, source, context) {
    const signalRBase = process.env.SIGNALR_REST_BASE_URL;
    const hubName = process.env.SIGNALR_HUB_NAME || 'teocHub';
    const functionBaseUrl = process.env.FUNCTION_BASE_URL || '';
    
    const result = {
        signalR: {
            total: 0,
            successful: 0,
            failed: 0,
            results: []
        },
        teams: {
            total: 0,
            successful: 0,
            failed: 0,
            results: []
        }
    };
    
    // SignalR broadcast
    if (signalRBase) {
        try {
            // Get Azure AD token for SignalR
            const credential = new DefaultAzureCredential();
            let token;
            
            try {
                token = await credential.getToken('https://signalr.azure.com/.default');
            } catch (tokenError) {
                context.error('Failed to acquire AAD token for SignalR:', {
                    error: tokenError.message,
                    errorCode: tokenError.code
                });
                // Continue to Teams posting even if SignalR fails
                token = null;
            }
            
            if (token && token.token) {
                // Broadcast to each route's SignalR group
                for (const route of routes) {
                    try {
                        const broadcastResult = await broadcastToSignalRGroup(
                            signalRBase,
                            hubName,
                            route.signalRGroup,
                            eventData,
                            token.token,
                            context
                        );
                        
                        result.signalR.total++;
                        if (broadcastResult.success) {
                            result.signalR.successful++;
                        } else {
                            result.signalR.failed++;
                        }
                        
                        result.signalR.results.push({
                            group: route.signalRGroup,
                            success: broadcastResult.success,
                            statusCode: broadcastResult.statusCode
                        });
                    } catch (err) {
                        context.error(`Failed to broadcast to group ${route.signalRGroup}:`, err);
                        result.signalR.total++;
                        result.signalR.failed++;
                        result.signalR.results.push({
                            group: route.signalRGroup,
                            success: false,
                            error: err.message
                        });
                    }
                }
            } else {
                context.warn('Failed to acquire AAD token for SignalR');
            }
        } catch (err) {
            context.error('Error during SignalR broadcast:', err);
        }
    } else {
        context.warn('SIGNALR_REST_BASE_URL not configured. Skipping SignalR broadcast.');
    }
    
    // Teams posting via Microsoft Graph API (replacing webhooks)
    // Note: Legacy webhook logic below is kept intact but bypassed
    
    context.log('Posting to Teams via Microsoft Graph API');
    
    if (eventData.TeamWebURL) {
        try {
            // Generate adaptive card for the event
            const cardJson = createEventNotificationCard(eventData, {
                functionBaseUrl: functionBaseUrl,
                includeActions: true,
                compact: false
            });
            
            // Attach adaptive card to eventData for Graph poster
            eventData.adaptiveCard = cardJson;
            
            // Post message via Graph API
            const graphResult = await postMessageToTeamsChannel(eventData, context);
            
            result.teams.total++;
            if (graphResult.success) {
                result.teams.successful++;
                result.teams.results.push({
                    method: 'graph-api',
                    teamId: graphResult.teamId,
                    channelId: graphResult.channelId,
                    messageId: graphResult.messageId,
                    success: true
                });
            } else {
                result.teams.failed++;
                result.teams.results.push({
                    method: 'graph-api',
                    teamId: graphResult.teamId,
                    channelId: graphResult.channelId,
                    success: false,
                    error: graphResult.error
                });
            }
        } catch (graphError) {
            context.error('Error posting to Teams via Graph API:', graphError);
            result.teams.total++;
            result.teams.failed++;
            result.teams.results.push({
                method: 'graph-api',
                success: false,
                error: graphError.message
            });
        }
    } else {
        context.warn('No TeamWebURL found in eventData, skipping Teams posting');
    }
    
    // Teams webhook posting (additional fallback/legacy support)
    // Post to source.teamsWebhookUrl if available
    if (source.teamsWebhookUrl) {
        try {
            await postToTeamsWebhook(eventData, source.teamsWebhookUrl, functionBaseUrl, context);
            result.teams.total++;
            result.teams.successful++;
            result.teams.results.push({
                method: 'webhook',
                webhookUrl: source.teamsWebhookUrl.length > 50 ? source.teamsWebhookUrl.substring(0, 50) + '...' : source.teamsWebhookUrl,
                success: true
            });
        } catch (webhookError) {
            context.error('Error posting to Teams webhook:', webhookError);
            result.teams.total++;
            result.teams.failed++;
            result.teams.results.push({
                method: 'webhook',
                webhookUrl: source.teamsWebhookUrl.length > 50 ? source.teamsWebhookUrl.substring(0, 50) + '...' : source.teamsWebhookUrl,
                success: false,
                error: webhookError.message
            });
        }
    }
    
    // ========================================================================
    // LEGACY WEBHOOK LOGIC (kept intact but bypassed - DO NOT DELETE)
    // ========================================================================
    // The code below is the original Teams webhook implementation.
    // It is intentionally commented out to prevent execution while preserving
    // the logic for reference or potential rollback.
    // ========================================================================
    /*
    // Teams webhook posting
    const teamsWebhooks = new Set(); // Use Set to avoid duplicate posts
    
    // 1. Add data source default webhook
    if (source.teamsWebhookUrl) {
        teamsWebhooks.add(source.teamsWebhookUrl);
    }
    
    // 2. Add routing-based webhooks
    for (const route of routes) {
        if (route.teamsWebhooks && route.teamsWebhooks.length > 0) {
            route.teamsWebhooks.forEach(url => teamsWebhooks.add(url));
        }
    }
    
    // Post to all unique Teams webhooks
    for (const webhookUrl of teamsWebhooks) {
        try {
            await postToTeamsWebhook(eventData, webhookUrl, functionBaseUrl, context);
            result.teams.total++;
            result.teams.successful++;
            result.teams.results.push({
                webhookUrl: webhookUrl.substring(0, 50) + '...',
                success: true
            });
        } catch (teamsErr) {
            context.error(`Failed to post to Teams webhook:`, teamsErr);
            result.teams.total++;
            result.teams.failed++;
            result.teams.results.push({
                webhookUrl: webhookUrl.substring(0, 50) + '...',
                success: false,
                error: teamsErr.message
            });
        }
    }
    */
    // ========================================================================
    // END LEGACY WEBHOOK LOGIC
    // ========================================================================
    
    // Log summary
    context.log('Broadcast summary:', {
        itemId: eventData.itemId,
        signalR: {
            total: result.signalR.total,
            successful: result.signalR.successful,
            failed: result.signalR.failed
        },
        teams: {
            total: result.teams.total,
            successful: result.teams.successful,
            failed: result.teams.failed
        }
    });
    
    return result;
}

/**
 * Broadcast message to specific SignalR group
 */
async function broadcastToSignalRGroup(signalRBase, hubName, groupName, eventData, token, context) {
    const message = {
        target: 'newItem',
        arguments: [eventData]
    };

    const publishUrl = `${signalRBase}/api/v1/hubs/${hubName}/groups/${groupName}/:send`;
    
    context.log(`Broadcasting to SignalR group: ${groupName}`);
    
    const res = await fetch(publishUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(message)
    });

    if (!res.ok) {
        const errorText = await res.text();
        context.error(`SignalR publish to group ${groupName} failed:`, res.status, errorText);
        return { success: false, statusCode: res.status, error: errorText };
    }

    context.log(`SignalR broadcast to group ${groupName} successful`);
    return { success: true, statusCode: res.status };
}

/**
 * Post adaptive card to Teams webhook
 */
async function postToTeamsWebhook(eventData, webhookUrl, functionBaseUrl, context) {
    context.log('Posting to Teams webhook...');
    
    // Generate adaptive card from event data
    const cardJson = createEventNotificationCard(eventData, {
        functionBaseUrl: functionBaseUrl,
        includeActions: true,
        compact: false
    });
    
    // Wrap for Teams
    const teamsMessage = wrapCardForTeams(cardJson);
    
    const res = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(teamsMessage)
    });
    
    if (!res.ok) {
        const errorText = await res.text();
        context.error(`Teams webhook post failed:`, res.status, errorText);
        throw new Error(`Teams webhook failed: ${res.status} ${errorText}`);
    }
    
    context.log('Teams webhook post successful');
}
