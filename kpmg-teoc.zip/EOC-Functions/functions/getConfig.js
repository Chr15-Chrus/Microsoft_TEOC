const { app } = require('@azure/functions');
const { getSecretValue } = require('../utils/secretProvider');

/**
 * Get application configuration for the web interface
 * Returns non-sensitive configuration values needed by the client
 */
app.http('getConfig', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'config',
    handler: async (request, context) => {
        try {
            context.log('[getConfig] Starting configuration retrieval...');
            
            // Determine function base URL. Prefer explicit env var, otherwise
            // infer from request for local development to keep same-origin API calls.
            let inferredBase = process.env.FUNCTION_BASE_URL || '';
            try {
                if (!inferredBase && request && request.url) {
                    try {
                        inferredBase = new URL(String(request.url)).origin;
                    } catch (e) {
                        // fallback: use empty string
                        inferredBase = '';
                    }
                }
            } catch (e) {
                inferredBase = '';
            }

            // If the request appears to originate from localhost (local dev),
            // prefer the request origin so the client uses same-origin calls
            // and avoids CORS against the remote function app.
            let finalBase = inferredBase || '';
            try {
                if (request && request.url) {
                    try {
                        const origin = new URL(String(request.url)).origin;
                        if (origin.includes('127.0.0.1') || origin.includes('localhost')) {
                            finalBase = origin;
                        }
                    } catch (e) {
                        // ignore
                    }
                }
            } catch (e) {
                // ignore
            }

            context.log('[getConfig] Retrieving MAPBOX_API_KEY...');
            const mapboxToken = await getSecretValue('MAPBOX_API_KEY', { optional: true });
            context.log(`[getConfig] MAPBOX_API_KEY retrieved: ${mapboxToken ? 'YES (length: ' + mapboxToken.length + ')' : 'NO'}`);
            
            context.log('[getConfig] Retrieving ENTRA_CLIENT_ID/SHAREPOINT_CLIENT_ID...');
            const entraClientId = await getSecretValue(['ENTRA_CLIENT_ID', 'SHAREPOINT_CLIENT_ID'], { optional: true }) || '';
            context.log(`[getConfig] ENTRA_CLIENT_ID retrieved: ${entraClientId ? 'YES (length: ' + entraClientId.length + ')' : 'NO'}`);
            
            context.log('[getConfig] Retrieving ENTRA_IDENTIFIER_URI...');
            const identifierUri = await getSecretValue('ENTRA_IDENTIFIER_URI', { optional: true }) || '';
            context.log(`[getConfig] ENTRA_IDENTIFIER_URI retrieved: ${identifierUri ? 'YES (length: ' + identifierUri.length + ')' : 'NO'}`);
            
            context.log('[getConfig] Retrieving ENTRA_TENANT_ID/SHAREPOINT_TENANT_ID...');
            const entraTenantId = await getSecretValue(['ENTRA_TENANT_ID', 'SHAREPOINT_TENANT_ID'], { optional: true }) || '';
            context.log(`[getConfig] ENTRA_TENANT_ID retrieved: ${entraTenantId ? 'YES (length: ' + entraTenantId.length + ')' : 'NO'}`);

            context.log('[getConfig] Retrieving ENTRA_API_SCOPE/SHAREPOINT_API_SCOPE...');
            const apiScopeOverride = await getSecretValue(['ENTRA_API_SCOPE', 'SHAREPOINT_API_SCOPE'], { optional: true }) || '';
            context.log(`[getConfig] API scope override: ${apiScopeOverride ? 'YES (length: ' + apiScopeOverride.length + ')' : 'NO'}`);

            // Get notification auto-dismiss setting from environment (default 30 seconds)
            const notificationAutoDismiss = parseInt(process.env.NOTIFICATION_AUTO_DISMISS || '30');
            context.log(`[getConfig] Notification auto-dismiss: ${notificationAutoDismiss}s`);

            const apiScope = (() => {
                if (apiScopeOverride) return apiScopeOverride;
                // Prefer explicit identifier URI if provided; append /access_as_user
                if (identifierUri) return `${identifierUri.replace(/\/?$/, '')}/access_as_user`;
                // If no identifier URI, do NOT invent a localhost scope (causes AADSTS500011).
                return '';
            })();

            const config = {
                functionBaseUrl: finalBase,
                mapboxToken: mapboxToken || '',
                entraClientId,
                entraTenantId,
                identifierUri, // expose raw identifier URI for client diagnostics
                apiScope,
                notificationAutoDismiss, // Auto-dismiss time in seconds
                defaultMapCenter: [
                    // Default to Australia (longitude, latitude) if env vars not provided
                    parseFloat(process.env.DEFAULT_MAP_LNG || '133.7751'),
                    parseFloat(process.env.DEFAULT_MAP_LAT || '-25.2744')
                ],
                defaultMapZoom: parseInt(process.env.DEFAULT_MAP_ZOOM || '4')
            };
            
            context.log('[getConfig] Configuration assembled:', {
                functionBaseUrl: config.functionBaseUrl,
                mapboxToken: config.mapboxToken ? '***' + config.mapboxToken.slice(-4) : '(empty)',
                entraClientId: config.entraClientId || '(empty)',
                entraTenantId: config.entraTenantId || '(empty)',
                identifierUri: config.identifierUri || '(empty)',
                apiScope: config.apiScope || '(empty)'
            });
            
            // Validate required configuration
            if (!config.mapboxToken) {
                context.warn('MAPBOX_API_KEY not configured');
            }
            
            if (!config.entraClientId || !config.entraTenantId) {
                context.warn('Entra ID configuration not complete');
            }
            
            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache'
                },
                jsonBody: config
            };
        } catch (error) {
            context.error('Error getting config:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Failed to get configuration',
                    message: error.message
                }
            };
        }
    }
});
