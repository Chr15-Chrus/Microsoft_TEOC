const { app } = require('@azure/functions');
const { getConnectionInfo } = require('../utils/signalr-service');

const HUB_NAME = process.env.SIGNALR_HUB_NAME || 'teocHub';
const SIGNALR_CONNECTION_STRING = process.env.SIGNALR_CONNECTION_STRING;

/**
 * SignalR client negotiation endpoint
 * Returns connection information for clients to connect to SignalR Service
 * 
 * Uses direct REST API approach instead of bindings for better reliability
 * in Azure Functions v4 deployed environment.
 */
app.http('negotiate', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    route: 'negotiate',
    handler: async (request, context) => {
        try {
            context.log('negotiate function called');

            // Check if SignalR connection string is configured
            if (!SIGNALR_CONNECTION_STRING) {
                context.log('SIGNALR_CONNECTION_STRING environment variable is not configured');
                return {
                    status: 500,
                    jsonBody: {
                        error: 'SignalR service is not configured',
                        message: 'The server is missing SignalR configuration. Please contact your administrator.'
                    }
                };
            }

            // Optional: Get team ID from query for group-specific connections
            const teamId = request.query.get('teamId');
            const userId = request.query.get('userId');

            if (teamId) {
                context.log(`Negotiating connection for team: ${teamId}`);
            }
            if (userId) {
                context.log(`Negotiating connection for user: ${userId}`);
            }

            // Generate connection info using SignalR REST API
            const connectionInfo = getConnectionInfo(
                SIGNALR_CONNECTION_STRING,
                HUB_NAME,
                userId
            );

            context.log('Successfully generated SignalR connection info');

            return {
                status: 200,
                jsonBody: connectionInfo
            };
        } catch (error) {
            context.error('Error in negotiate function:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Failed to generate SignalR connection',
                    message: error.message
                }
            };
        }
    }
});
