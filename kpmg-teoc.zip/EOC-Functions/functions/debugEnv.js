const { app } = require('@azure/functions');

/**
 * Debug endpoint to check environment variable availability
 * This helps diagnose configuration issues
 * 
 * SECURITY WARNING: This endpoint exposes environment variable information.
 * It should use 'function' auth level in production and be disabled when not needed.
 */
app.http('debugEnv', {
    methods: ['GET'],
    authLevel: 'function',  // Requires function key - more secure than anonymous
    route: 'debug/env',
    handler: async (request, context) => {
        try {
            context.log('[debugEnv] Checking environment variables...');
            
            // List of configuration keys we're interested in
            const configKeys = [
                'MAPBOX_API_KEY',
                'ENTRA_CLIENT_ID',
                'ENTRA_TENANT_ID',
                'ENTRA_IDENTIFIER_URI',
                'SHAREPOINT_CLIENT_ID',
                'SHAREPOINT_TENANT_ID',
                'KEY_VAULT_URI',
                'KEY_VAULT_URL',
                'FUNCTION_BASE_URL'
            ];
            
            // Helper to determine if a key name suggests sensitive data
            const isSensitiveKey = (key) => {
                const sensitivePatterns = ['KEY', 'SECRET', 'PASSWORD', 'TOKEN', 'CONNECTION_STRING'];
                return sensitivePatterns.some(pattern => key.toUpperCase().includes(pattern));
            };
            
            const envStatus = {};
            
            for (const key of configKeys) {
                const value = process.env[key];
                const isSensitive = isSensitiveKey(key);
                
                envStatus[key] = {
                    exists: !!value,
                    length: value ? value.length : 0,
                    startsWithKeyVaultRef: value ? value.startsWith('@Microsoft.KeyVault(') : false,
                    // Mask sensitive values, show first/last 4 chars only for non-sensitive
                    preview: value ? 
                        (isSensitive ? '***' + (value.length > 4 ? value.slice(-4) : '***') : 
                         (value.length > 20 ? value.substring(0, 20) + '...' : value)) 
                        : null
                };
            }
            
            // Also check for any environment variable that might be a keyvault reference
            const allEnvKeys = Object.keys(process.env);
            const keyVaultRefs = allEnvKeys.filter(key => {
                const val = process.env[key];
                return val && typeof val === 'string' && val.startsWith('@Microsoft.KeyVault(');
            });
            
            context.log('[debugEnv] Environment variable status:', envStatus);
            context.log('[debugEnv] Total env vars:', allEnvKeys.length);
            context.log('[debugEnv] Key Vault references found:', keyVaultRefs.length);
            
            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache'
                },
                jsonBody: {
                    timestamp: new Date().toISOString(),
                    configKeys: envStatus,
                    totalEnvVars: allEnvKeys.length,
                    keyVaultReferences: keyVaultRefs,
                    note: 'This is a diagnostic endpoint. Requires function key for security.'
                }
            };
        } catch (error) {
            context.error('[debugEnv] Error:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Failed to check environment',
                    message: error.message
                }
            };
        }
    }
});
