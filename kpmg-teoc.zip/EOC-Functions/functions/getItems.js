const { app } = require('@azure/functions');
const axios = require('axios');
const { getUserGraphToken } = require('../utils/sharepoint-auth');
const { requireAuth } = require('../utils/auth-middleware');
const { getDataSourcesTableClient } = require('../utils/data-sources');
const { forwardGeocode } = require('../utils/mapbox-geocoding');

/**
 * Get all items from all registered and active data sources
 * Returns items in common event format for display on the map
 */
app.http('getItems', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'getItems',
    handler: async (request, context) => {
        try {
            // Verify user authentication (allow LOCAL_DEBUG bypass)
            let user, userToken;
            if (process.env.LOCAL_DEBUG === 'true') {
                // Safety check: prevent LOCAL_DEBUG in production
                if (process.env.NODE_ENV === 'production' || process.env.AZURE_FUNCTIONS_ENVIRONMENT === 'Production') {
                    context.error('LOCAL_DEBUG is enabled in production environment - this is a security risk!');
                    return {
                        status: 500,
                        jsonBody: {
                            error: 'Configuration Error',
                            message: 'Invalid debug configuration'
                        }
                    };
                }
                user = { email: 'local@dev' };
                userToken = null; // Will fall back to app-only token in LOCAL_DEBUG mode
                context.log('LOCAL_DEBUG enabled — bypassing auth as', user.email);
            } else {
                user = await requireAuth(request);
                if (!user) {
                    return {
                        status: 401,
                        jsonBody: {
                            error: 'Unauthorized',
                            message: 'Valid authentication token required'
                        }
                    };
                }
                // Extract user's token for OBO flow
                userToken = request.headers.get('authorization');
            }

            context.log('Authenticated user:', user.email);
            
            /**
             * Assessment Mode Support
             * 
             * Assessment mode is activated when a Map App tab is created for an incident's assessments.
             * The tab URL includes these query parameters:
             * 
             * - dataSource=assessments (required) - Indicates this is assessment mode
             * - siteUrl (required) - SharePoint site URL where the assessment list is located
             * - listName (required) - Name of the SharePoint list (e.g., "Ground Assessments")
             * - incidentId (optional) - Incident ID for filtering
             * 
             * Filtering Behavior:
             * 1. If the list has an IncidentId field AND incidentId parameter is provided:
             *    - Filters items to show only assessments for the specified incident
             *    - Supports shared assessment lists across multiple incidents
             * 
             * 2. If no IncidentId field exists (or incidentId parameter not provided):
             *    - Returns all items from the list
             *    - Assumes the list is scoped to a single incident (per-incident list pattern)
             * 
             * Security Note: User access is controlled by SharePoint permissions via OBO token flow.
             * Users can only access lists they have permission to view in SharePoint.
             */
            
            // Check for assessment mode query parameters
            const queryParams = request.query;
            const dataSource = queryParams.get('dataSource');
            const incidentId = queryParams.get('incidentId');
            const siteUrl = queryParams.get('siteUrl');
            const listName = queryParams.get('listName');
            
            const isAssessmentMode = dataSource === 'assessments' && siteUrl && listName;
            
            if (isAssessmentMode) {
                context.log('Assessment mode detected - fetching from specific list:', { siteUrl, listName, incidentId });
                
                // Basic URL validation to prevent malformed URLs
                let validatedSiteUrl;
                try {
                    validatedSiteUrl = new URL(decodeURIComponent(siteUrl));
                    // Ensure it's a valid SharePoint URL with proper domain suffix
                    // The hostname must END with .sharepoint.com to prevent subdomain attacks
                    if (!validatedSiteUrl.hostname.endsWith('.sharepoint.com')) {
                        throw new Error('Invalid SharePoint URL');
                    }
                } catch (error) {
                    context.error('Invalid siteUrl parameter:', siteUrl);
                    return {
                        status: 400,
                        jsonBody: {
                            error: 'Invalid Request',
                            message: 'The siteUrl parameter must be a valid SharePoint URL'
                        }
                    };
                }
                
                // Fetch items from the specified SharePoint list
                const assessmentSource = {
                    id: 'assessment-dynamic',
                    type: 'sharepoint',
                    name: listName || 'Ground Assessments',
                    siteUrl: validatedSiteUrl.toString(),
                    listId: listName
                };
                
                let items;
                try {
                    items = await fetchFromSharePointSource(assessmentSource, context, userToken);
                } catch (error) {
                    context.error('Failed to fetch from assessment list:', error);
                    return {
                        status: 403,
                        jsonBody: {
                            error: 'Access Denied',
                            message: 'Unable to access the specified SharePoint list. Check permissions.'
                        }
                    };
                }
                
                // Filter by incidentId if provided and the field exists
                let filteredItems = items;
                if (incidentId && items.length > 0) {
                    // Check if items have an IncidentId field (case-insensitive)
                    const hasIncidentIdField = items.some(item => {
                        const keys = Object.keys(item);
                        return keys.some(key => key.toLowerCase() === 'incidentid');
                    });
                    
                    if (hasIncidentIdField) {
                        filteredItems = items.filter(item => {
                            // Find the IncidentId field regardless of casing
                            const incidentIdKey = Object.keys(item).find(key => 
                                key.toLowerCase() === 'incidentid'
                            );
                            const itemIncidentId = incidentIdKey ? item[incidentIdKey] : null;
                            return itemIncidentId && itemIncidentId.toString() === incidentId.toString();
                        });
                        context.log(`Filtered ${items.length} items to ${filteredItems.length} for incident ${incidentId}`);
                    } else {
                        // List is per-incident, so all items belong to this incident
                        context.log(`No IncidentId field found - assuming all ${items.length} items belong to incident ${incidentId}`);
                    }
                } else if (incidentId && items.length === 0) {
                    context.log('No items in list - cannot determine if IncidentId field exists');
                }
                
                return {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Cache-Control': 'no-cache'
                    },
                    jsonBody: {
                        items: filteredItems,
                        count: filteredItems.length,
                        sources: [{
                            id: assessmentSource.id,
                            name: assessmentSource.name,
                            type: assessmentSource.type
                        }]
                    }
                };
            }
            
            // Normal mode - Get all active data sources from Table Storage
            const tableClient = await getDataSourcesTableClient(context);
            let allItems = [];
            const sources = [];

            const entities = tableClient.listEntities({
                queryOptions: { filter: `PartitionKey eq 'source' and active eq true` }
            });

            for await (const entity of entities) {
                sources.push({
                    id: entity.rowKey,
                    type: entity.type,
                    name: entity.name,
                    siteUrl: entity.siteUrl,
                    listId: entity.listId,
                    instanceUrl: entity.instanceUrl,
                    entity: entity.entity
                });
            }
            
            if (sources.length === 0) {
                context.warn('No active data sources configured in Table Storage');
                return {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Cache-Control': 'no-cache'
                    },
                    jsonBody: {
                        items: [],
                        count: 0,
                        sources: []
                    }
                };
            }

            context.log(`Found ${sources.length} active data sources`);
            
            // Track which sources the user can access
            const accessibleSources = [];
            
            // Fetch items from each source
            for (const source of sources) {
                try {
                    let items = [];
                    
                    if (source.type === 'sharepoint') {
                        items = await fetchFromSharePointSource(source, context, userToken);
                        // If we got items (empty array is valid), user has access to this source
                        if (items.length > 0 || Array.isArray(items)) {
                            // Add source metadata to each item
                            items.forEach(item => {
                                item.sourceId = source.id;
                                item.sourceName = source.name;
                                item.sourceType = source.type;
                            });
                            
                            allItems.push(...items);
                            accessibleSources.push(source);
                            context.log(`Fetched ${items.length} items from ${source.name}`);
                        }
                    } else if (source.type === 'dynamics') {
                        // Dynamics items would be pushed via publishEvent, not fetched
                        context.log(`Skipping Dynamics source ${source.name} (push-based)`);
                        continue;
                    } else if (source.type === 'custom') {
                        context.log(`Skipping custom source ${source.name} (push-based)`);
                        continue;
                    }
                } catch (error) {
                    context.error(`Failed to fetch from source ${source.name}:`, error);
                    // Continue with other sources - silent failure for permission issues
                }
            }
            
            context.log(`Retrieved ${allItems.length} total items from ${accessibleSources.length}/${sources.length} accessible sources`);
            
            return {
                status: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache'
                },
                jsonBody: {
                    items: allItems,
                    count: allItems.length,
                    sources: accessibleSources.map(s => ({
                        id: s.id,
                        name: s.name,
                        type: s.type
                    }))
                }
            };
        } catch (error) {
            context.error('Error fetching items:', error);
            return {
                status: 500,
                jsonBody: {
                    error: 'Failed to fetch items',
                    message: error.message
                }
            };
        }
    }
});

/**
 * Fetch items from a specific SharePoint source
 * Uses user's token to respect SharePoint permissions
 * Returns empty array if user doesn't have access (silent failure)
 */
async function fetchFromSharePointSource(source, context, userToken) {
    let accessToken;
    
    if (userToken && process.env.LOCAL_DEBUG !== 'true') {
        // Use on-behalf-of flow to get user's Graph token
        try {
            accessToken = await getUserGraphToken(userToken);
            context.log('Using user-delegated Graph token for', source.name);
        } catch (error) {
            (context.warn ?? context.log).call(context, 'Failed to get user Graph token for', source.name, ':', error.message);
            return []; // Silent failure - consistent return type
        }
    } else {
        // LOCAL_DEBUG mode - use app-only token
        (context.warn ?? context.log).call(context, 'Using app-only token for', source.name, '(LOCAL_DEBUG mode)');
        const { getSharePointAccessToken } = require('../utils/sharepoint-auth');
        accessToken = await getSharePointAccessToken();
    }
    
    const u = new URL(source.siteUrl);
    const hostname = u.hostname;
    const pathParts = u.pathname.split('/').filter(Boolean);
    const siteName = pathParts.length > 1 ? pathParts[pathParts.length - 1] : pathParts[0] || '';
    
    const graphUrl = `https://graph.microsoft.com/v1.0/sites/${hostname}:/sites/${siteName}:/lists/${source.listId}/items?expand=fields`;
    
    context.log(`Fetching from SharePoint: ${graphUrl}`);
    
    try {
        const response = await axios.get(graphUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });
        
        return await normalizeSharePointItems(response.data.value, source.id, source.siteUrl, source.listId, context);
    } catch (error) {
        if (error.response?.status === 403 || error.response?.status === 401) {
            // User doesn't have access to this list - silent failure
            context.log(`User does not have access to ${source.name} (403/401)`);
            return [];
        }
        if (error.response?.status === 404) {
            // List not found or user can't see it exists - silent failure
            context.log(`List ${source.name} not found or not visible to user (404)`);
            return [];
        }
        // Other errors (500, network issues) should be logged but also result in silent exclusion
        context.log.error(`Error fetching from ${source.name}:`, error.message);
        return [];
    }
}

/**
 * Normalize SharePoint items to common format
 */
async function normalizeSharePointItems(items, sourceId, siteUrl, listId, context) {
    const normalized = [];
    const geocodeCache = new Map();

    for (const item of items) {
        const fields = { ...(item.fields || {}) };

        const setIfMissing = (key, value) => {
            const normalizedValue = normalizeCoordinateValue(value);
            if (normalizedValue === null) {
                return;
            }
            if (fields[key] === undefined || fields[key] === null || fields[key] === '') {
                fields[key] = normalizedValue;
            }
        };

        const fromLoc = extractCoordinatesCandidate(fields.Location);
        if (fromLoc) {
            setIfMissing('latitude', fromLoc.lat);
            setIfMissing('longitude', fromLoc.lng);
        }

        const fromGeo = extractCoordinatesCandidate(fields.GeoLoc || fields.GeoLoc_ || fields.GeoLocation);
        if (fromGeo) {
            setIfMissing('latitude', fromGeo.lat);
            setIfMissing('longitude', fromGeo.lng);
        }

        const hasCoordinates = isValidCoordinate(fields.latitude) && isValidCoordinate(fields.longitude);

        if (!hasCoordinates) {
            const inferred = await inferCoordinatesFromAddress(fields, geocodeCache, context);
            if (inferred) {
                fields.latitude = inferred.latitude;
                fields.longitude = inferred.longitude;
                fields._locationInferred = true;
                fields._locationInferenceAddress = inferred.address;
                fields._locationInferenceDisplayName = inferred.displayName;
                fields._locationInferenceProvider = inferred.provider;
                fields._locationInferenceConfidence = inferred.confidence;
            }
        }

        normalized.push({
            id: item.id,
            ...fields,
            _sourceId: sourceId,
            _siteUrl: siteUrl,
            _listId: listId
        });
    }

    return normalized;
}

function normalizeCoordinateValue(value) {
    if (value === undefined || value === null || value === '') {
        return null;
    }
    if (typeof value === 'number' && Number.isFinite(value)) {
        return value;
    }
    const num = Number(value);
    return Number.isFinite(num) ? num : null;
}

function isValidCoordinate(value) {
    return normalizeCoordinateValue(value) !== null;
}

function extractCoordinatesCandidate(rawLocation) {
    if (!rawLocation) {
        return null;
    }

    const locationObject = typeof rawLocation === 'string' ? safeParseJson(rawLocation) : rawLocation;
    if (!locationObject || typeof locationObject !== 'object') {
        return null;
    }

    const candidates = [
        locationObject.coordinates,
        locationObject.Coordinates,
        locationObject.location,
        locationObject.Location,
        locationObject
    ];

    for (const candidate of candidates) {
        const coords = deriveCoordinates(candidate);
        if (coords) {
            return coords;
        }
    }

    return null;
}

function deriveCoordinates(candidate) {
    if (!candidate) {
        return null;
    }

    if (Array.isArray(candidate) && candidate.length >= 2) {
        const lng = normalizeCoordinateValue(candidate[0]);
        const lat = normalizeCoordinateValue(candidate[1]);
        if (lat !== null && lng !== null) {
            return { lat, lng };
        }
    }

    const latValue = candidate.latitude ?? candidate.Latitude ?? candidate.lat ?? candidate.Lat;
    const lngValue = candidate.longitude ?? candidate.Longitude ?? candidate.lng ?? candidate.Lng;
    const lat = normalizeCoordinateValue(latValue);
    const lng = normalizeCoordinateValue(lngValue);

    if (lat !== null && lng !== null) {
        return { lat, lng };
    }

    return null;
}

function safeParseJson(value) {
    try {
        return JSON.parse(value);
    } catch (error) {
        return null;
    }
}

function buildAddressString(fields = {}) {
    const parts = [];
    const push = (val) => {
        if (!val) {
            return;
        }
        const text = String(val).trim();
        if (text && !parts.includes(text)) {
            parts.push(text);
        }
    };

    const locationValue = typeof fields.Location === 'string' ? safeParseJson(fields.Location) : fields.Location;
    const locationAddress = locationValue?.address || locationValue?.Address;

    if (locationAddress) {
        push(locationAddress.street || locationAddress.Street || locationAddress.addressLine);
        push(locationAddress.city || locationAddress.City);
        push(locationAddress.state || locationAddress.State);
        push(locationAddress.postalCode || locationAddress.PostalCode);
        push(locationAddress.countryOrRegion || locationAddress.CountryOrRegion);
    }

    push(locationValue?.displayName || locationValue?.DispName);

    push(fields.Street || fields.street || fields.Address || fields.AddressLine || fields.DispName);
    push(fields.City || fields.city);
    push(fields.State || fields.state || fields.Region || fields.region);
    push(fields.PostalCode || fields.postalCode || fields.Zip || fields.zip);
    push(fields.CountryOrRegion || fields.countryOrRegion || fields.Country || fields.country);

    return parts.filter(Boolean).join(', ');
}

async function inferCoordinatesFromAddress(fields, cache, context) {
    const address = buildAddressString(fields);
    if (!address) {
        return null;
    }

    const cacheKey = address.toLowerCase();
    if (cache?.has(cacheKey)) {
        return cache.get(cacheKey);
    }

    const geocodeResult = await forwardGeocode(address, { optional: true, context });
    if (!geocodeResult?.coordinates) {
        cache?.set(cacheKey, null);
        return null;
    }

    const lat = normalizeCoordinateValue(geocodeResult.coordinates.latitude);
    const lng = normalizeCoordinateValue(geocodeResult.coordinates.longitude);
    if (lat === null || lng === null) {
        cache?.set(cacheKey, null);
        return null;
    }

    const payload = {
        latitude: lat,
        longitude: lng,
        address,
        displayName: geocodeResult.displayName || address,
        provider: 'mapbox',
        confidence: geocodeResult.feature?.relevance ?? null
    };

    cache?.set(cacheKey, payload);
    return payload;
}

