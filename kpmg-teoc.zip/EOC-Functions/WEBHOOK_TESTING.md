# SharePoint Webhook Testing Guide

This guide explains how to test the SharePoint webhook → Teams adaptive card pipeline locally or in a deployed environment.

## Overview

The webhook pipeline processes SharePoint list changes as follows:

1. **SharePoint webhook** → `webhookGateway` function receives notification
2. **Validation** → Validates clientState and resolves DataSource
3. **Graph fetch** → Fetches most recent item from SharePoint list via Microsoft Graph
4. **Deduplication** → Checks NotificationState table to avoid duplicate processing
5. **Normalization** → Maps SharePoint fields to standardized eventData format
6. **Routing** → Determines target teams using routing-service
7. **Broadcast** → Sends to SignalR groups and Teams webhooks
8. **State update** → Updates NotificationState to prevent future duplicates

## Prerequisites

### Required Configuration

Before testing, ensure the following are configured:

1. **DataSources Table** - Register your SharePoint list:
   ```json
   {
     "partitionKey": "source",
     "rowKey": "your-source-id",
     "name": "Your Source Name",
     "type": "sharepoint",
     "active": true,
     "listId": "your-list-guid",
     "siteUrl": "https://tenant.sharepoint.com/sites/site",
     "siteGraphId": "hostname,site-id,web-id",
     "teamsWebhookUrl": "https://outlook.office.com/webhook/..."
   }
   ```
   
   **How to obtain siteGraphId:**
   
   The `siteGraphId` is in the format: `hostname,site-id,web-id`
   
   To get these values, use Microsoft Graph API:
   ```bash
   # 1. Get site ID
   GET https://graph.microsoft.com/v1.0/sites/{hostname}:/sites/{site-name}
   
   # Example:
   GET https://graph.microsoft.com/v1.0/sites/contoso.sharepoint.com:/sites/operations
   
   # Response contains:
   {
     "id": "contoso.sharepoint.com,abc123,def456",
     "siteCollection": { "hostname": "contoso.sharepoint.com" },
     "id": "abc123",
     "webId": "def456"
   }
   
   # 2. Use the full "id" value as siteGraphId:
   # "contoso.sharepoint.com,abc123,def456"
   ```
   
   Or use PowerShell with PnP:
   ```powershell
   Connect-PnPOnline -Url "https://tenant.sharepoint.com/sites/site"
   $site = Get-PnPSite -Includes Id
   $web = Get-PnPWeb
   $hostname = ([System.Uri]$site.Url).Host
   $siteGraphId = "$hostname,$($site.Id),$($web.Id)"
   Write-Host "siteGraphId: $siteGraphId"
   ```

2. **WebhookSecrets Table** - Store webhook clientState:
   ```json
   {
     "partitionKey": "webhook",
     "rowKey": "your-source-id",
     "clientState": "your-secret-client-state"
   }
   ```

3. **Environment Variables**:
   ```bash
   # Storage
   AZURE_STORAGE_CONNECTION_STRING=...
   
   # SharePoint/Graph Authentication
   SHAREPOINT_TENANT_ID=...
   SHAREPOINT_CLIENT_ID=...
   SHAREPOINT_CLIENT_SECRET=...
   
   # SignalR (optional)
   SIGNALR_REST_BASE_URL=https://your-signalr.service.signalr.net
   SIGNALR_HUB_NAME=teocHub
   
   # Function URL for cards
   FUNCTION_BASE_URL=https://your-function-app.azurewebsites.net
   ```

## Local Testing

### Option 1: Using PowerShell Script (Windows/Linux/Mac)

```powershell
# Edit test-webhook.ps1 with your values
./test-webhook.ps1 `
  -FunctionUrl "http://localhost:7071/api/webhookGateway" `
  -SubscriptionId "test-sub-123" `
  -ClientState "your-secret-client-state" `
  -ListId "your-list-guid" `
  -SiteUrl "https://tenant.sharepoint.com/sites/site"
```

### Option 2: Using Bash Script (Linux/Mac)

```bash
# Set environment variables or edit test-webhook.sh
export FUNCTION_URL="http://localhost:7071/api/webhookGateway"
export CLIENT_STATE="your-secret-client-state"
export LIST_ID="your-list-guid"
export SITE_URL="https://tenant.sharepoint.com/sites/site"

./test-webhook.sh
```

### Option 3: Using curl Directly

```bash
curl -X POST http://localhost:7071/api/webhookGateway \
  -H "Content-Type: application/json" \
  -d '{
    "value": [
      {
        "subscriptionId": "test-subscription-id",
        "clientState": "your-secret-client-state",
        "expirationDateTime": "2026-01-20T00:00:00.000Z",
        "resource": "web/lists(guid'\''your-list-guid'\'')",
        "tenantId": "your-tenant-id",
        "siteUrl": "https://tenant.sharepoint.com/sites/site",
        "webId": "your-web-id"
      }
    ]
  }'
```

### Option 4: Using PowerShell Invoke-RestMethod

```powershell
$payload = @{
    value = @(
        @{
            subscriptionId = "test-subscription-id"
            clientState = "your-secret-client-state"
            expirationDateTime = (Get-Date).AddDays(7).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
            resource = "web/lists(guid'your-list-guid')"
            tenantId = "your-tenant-id"
            siteUrl = "https://tenant.sharepoint.com/sites/site"
            webId = "your-web-id"
        }
    )
}

Invoke-RestMethod -Uri "http://localhost:7071/api/webhookGateway" `
    -Method Post `
    -Body ($payload | ConvertTo-Json -Depth 10) `
    -ContentType "application/json"
```

## Expected Response

A successful webhook processing returns:

```json
{
  "success": true,
  "processed": 1,
  "total": 1
}
```

## Troubleshooting

### Common Issues

1. **"Client state mismatch"**
   - Ensure WebhookSecrets table has correct clientState for the source
   - ClientState must match exactly between webhook payload and table

2. **"No source found for list ID"**
   - Register the SharePoint list in DataSources table
   - Ensure listId matches exactly (GUID format)

3. **"Source inactive"**
   - Set `active: true` in DataSources table entry

4. **"Failed to fetch SharePoint item"**
   - Verify Graph API credentials (tenant ID, client ID, secret)
   - Ensure siteGraphId is in correct format: "hostname,site-id,web-id"
   - Check app permissions include Sites.Read.All

5. **"No routes determined for event"**
   - Check RoutingConfiguration table for active routing rules
   - Ensure event data matches routing criteria (geography, event type, etc.)

6. **SignalR broadcast fails**
   - Verify SIGNALR_REST_BASE_URL is set correctly
   - Ensure Azure Function has DefaultAzureCredential access to SignalR
   - Check that SignalR service is running

7. **Teams webhook post fails**
   - Verify teamsWebhookUrl in DataSource or routing config
   - Test webhook URL manually with a simple message
   - Check that webhook hasn't been removed from Teams channel

## Viewing Logs

### Local Development
Watch the Azure Functions Core Tools console for detailed logs.

### Azure Deployment
```bash
# View live logs
func azure functionapp logstream YourFunctionAppName

# Or use Azure CLI
az webapp log tail --name YourFunctionAppName --resource-group YourResourceGroup
```

## Testing Deduplication

To verify deduplication is working:

1. Send the same webhook payload twice
2. First call should process successfully
3. Second call should skip processing (duplicate detected)
4. Check NotificationState table to see recorded state

```bash
# Query NotificationState table
az storage entity query \
  --table-name NotificationState \
  --connection-string "..." \
  --filter "PartitionKey eq 'source'"
```

## Field Mapping Reference

SharePoint fields are mapped to eventData as follows:

| SharePoint Field | eventData Field | Notes |
|------------------|-----------------|-------|
| Title | title | Required |
| Description, MoreInformation | description | Combined if multiple present |
| ID | itemId | String format |
| Severity, ImmediateNeedsRequired | priority, severity | High if ImmediateNeedsRequired=true |
| Location (JSON) | location | Parsed to {displayName, address, coordinates} |
| EventType, EventCausedDamage, Category | eventType | First available field used |
| Status | status | Default: "New" |
| ContactName, Contact_x0020_Name | contactName | |
| ContactEmail | contactEmail | |
| ContactPhone, ContactPhoneNumber | contactPhone | |

## Next Steps

After successful local testing:

1. Deploy function app to Azure
2. Register SharePoint webhook subscriptions (see `renewWebhooks` function)
3. Monitor logs for actual SharePoint changes
4. Verify adaptive cards appear in Teams channels
5. Check SignalR updates appear in web dashboard

## Support

For issues or questions:
1. Check function logs for detailed error messages
2. Verify all configuration tables have correct data
3. Test Graph API access separately
4. Review webhook subscription status in SharePoint
