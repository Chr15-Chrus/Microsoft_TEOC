/**
 * Azure Functions v4 Entry Point
 * This file registers all HTTP-triggered functions for the TEOC application
 */
const { app } = require('@azure/functions');

// Import and register all v4 functions
require('./functions/acknowledgeForm');
require('./functions/createItem');
require('./functions/debugEnv');
require('./functions/debugForm');
require('./functions/eventHandler');
require('./functions/geocode');
require('./functions/getBotInfo');
require('./functions/getConfig');
require('./functions/getItems');
require('./functions/handleCardAction');
require('./functions/health');
require('./functions/markPending');
require('./functions/postAssessmentCard');
require('./functions/publishEvent');
require('./functions/reverseGeocode');
require('./functions/serveWebInterface');
require('./functions/serveWeb');
require('./functions/teocBot');
require('./functions/updateItem');
require('./functions/userPresence');
require('./functions/deleteSource');
require('./functions/getSource');
require('./functions/getSources');
require('./functions/negotiate');
require('./functions/registerSource');
require('./functions/renewWebhooks');
require('./functions/rootRedirect');
require('./functions/toggleSource');
require('./functions/webhookGateway');

module.exports = app;
