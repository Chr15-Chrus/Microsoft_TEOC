# Microsoft Graph API Integration for Teams Posting

## Overview

This implementation replaces Teams Incoming Webhooks with Microsoft Graph API for posting messages to Teams channels. The system uses delegated permissions (ChannelMessage.Send) and MSAL for authentication.

## Architecture Changes

### New Files Created

1. **utils/graphAuth.js**
   - Manages MSAL token cache in Azure Blob Storage
   - Uses PublicClientApplication for delegated auth
   - Acquires tokens silently from cached account
   - Automatically refreshes and persists tokens

2. **utils/teamsGraphPoster.js**
   - Parses teamId and channelId from SharePoint TeamWebURL
   - Posts messages to Teams channels via Graph API
   - Supports both adaptive cards and plain text
   - Comprehensive error handling and logging

### Modified Files

1. **functions/webhookGateway.js**
   - Replaced webhook posting with Graph API calls
   - Legacy webhook code preserved but commented out
   - Added Graph API result tracking

2. **utils/sharepoint-change-processor.js**
   - Added TeamWebURL field to eventData normalization
   - Preserves TeamWebURL from SharePoint list items

## Configuration Requirements

### Environment Variables

The following environment variables must be configured in the Azure Function App settings:

```
ENTRA_CLIENT_ID=<your-client-id>
ENTRA_TENANT_ID=<your-tenant-id>
MSAL_CACHE_BLOB_CONTAINER=msal-cache
MSAL_CACHE_BLOB_NAME=msal_cache.json
AzureWebJobsStorage=<your-storage-connection-string>
```

### Azure AD App Registration

1. **Delegated Permissions Required:**
   - ChannelMessage.Send

2. **One-Time Interactive Login:**
   - Must be completed before first use
   - Creates msal_cache.json in Azure Blob Storage
   - Token is refreshed automatically thereafter

### SharePoint List Configuration

Each incident in the SharePoint list must have a **TeamWebURL** field containing the Teams channel URL.

**Expected URL Format:**
```
https://teams.microsoft.com/l/team/{channelId}/conversations?groupId={teamId}&tenantId={tenantId}
```

**Example:**
```
https://teams.microsoft.com/l/team/19%3A1234567890abcdef1234567890abcdef%40thread.tacv2/conversations?groupId=12345678-1234-1234-1234-123456789012&tenantId=87654321-4321-4321-4321-210987654321
```

## How It Works

### Flow Diagram

```
SharePoint Change
        ↓
webhookGateway receives notification
        ↓
processSharePointChange (fetches item, normalizes data)
        ↓
eventData includes TeamWebURL
        ↓
determineRoutes (routing service - unchanged)
        ↓
broadcastEvent
        ├─→ SignalR broadcast (unchanged)
        └─→ postMessageToTeamsChannel (NEW)
                ├─→ Parse teamId/channelId from TeamWebURL
                ├─→ Get Graph access token (MSAL)
                ├─→ Create adaptive card
                └─→ POST to Graph API
```

### URL Parsing Logic

**teamId:** Extracted from `groupId=` query parameter
**channelId:** Extracted from `/l/team/{channelId}/` path segment

The channelId can be in two formats:
1. **Thread ID:** `19:xxxxx@thread.tacv2` (General channel)
2. **GUID:** `12345678-1234-1234-1234-123456789012` (other channels)

### Message Posting

Messages are posted to:
```
POST https://graph.microsoft.com/v1.0/teams/{teamId}/channels/{channelId}/messages
```

**Payload includes:**
- Adaptive card (created from eventData)
- HTML fallback for compatibility

## Logging

The implementation includes comprehensive logging at every step:

### graphAuth.js Logs
- "Loading MSAL cache from Azure Blob Storage"
- "MSAL cache loaded successfully from blob storage"
- "Using cached account: {username}"
- "Token acquired silently for Microsoft Graph"
- "Token refreshed and persisted to blob storage"
- Error logs with full stack traces

### teamsGraphPoster.js Logs
- "Processing Teams post for item {itemId}"
- "Parsed Teams identifiers: {teamId, channelId, itemId, sourceId}"
- "Posting message to Graph API: {url}"
- "Successfully posted message to Teams channel: {messageId}"
- Error logs with Graph API response details

### webhookGateway.js Logs
- "Posting to Teams via Microsoft Graph API"
- "No TeamWebURL found in eventData, skipping Teams posting"
- "Broadcast summary" with success/failure counts

## Error Handling

All Graph API calls are wrapped in try/catch blocks. Failures in Teams posting do NOT break:
- SignalR broadcasts
- Processing of other notifications
- Webhook processing flow

Errors are logged with:
- itemId
- sourceId
- teamId
- channelId
- Error code and message
- Full Graph API response (if available)

## Testing

### Manual Testing

To test the URL parsing:
```javascript
const { parseTeamWebUrl } = require('./utils/teamsGraphPoster');
const result = parseTeamWebUrl('https://teams.microsoft.com/l/team/...');
console.log(result); // { teamId: '...', channelId: '...' }
```

### Expected Behavior

When a SharePoint incident is created or updated:
1. webhookGateway receives the notification
2. eventData is normalized with TeamWebURL
3. Adaptive card is created
4. Message is posted to the incident's team channel
5. Success/failure is logged and tracked

## Rollback Plan

If needed, the legacy webhook code can be restored by:
1. Uncommenting the webhook posting code in webhookGateway.js
2. Commenting out the Graph API posting code
3. No other changes needed (files remain compatible)

## Troubleshooting

### "MSAL cache not found"
- Ensure one-time interactive login is completed
- Verify MSAL_CACHE_BLOB_CONTAINER and MSAL_CACHE_BLOB_NAME settings
- Check that msal_cache.json exists in blob storage

### "Failed to parse TeamWebURL"
- Verify TeamWebURL field exists in SharePoint list item
- Ensure URL format matches expected pattern
- Check URL encoding is correct

### "Graph API returned 403 Forbidden"
- Verify ChannelMessage.Send permission is granted
- Ensure admin consent is provided
- Check that user has access to the team/channel

### "No teamId/channelId found"
- Verify TeamWebURL contains groupId query parameter
- Ensure URL path includes /l/team/{channelId}/
- Check for URL encoding issues

## Security Considerations

1. **Delegated Permissions:** Uses user context, not application-only
2. **Token Caching:** Tokens stored securely in Azure Blob Storage
3. **No Secrets in Code:** All credentials from environment variables
4. **Graceful Failures:** Errors logged but don't expose sensitive data

## Maintenance

### Token Cache Refresh
- Handled automatically by MSAL
- Token refreshed silently when needed
- Cache persisted back to blob storage

### Monitoring
- Check Function App logs for errors
- Monitor Graph API call success rates
- Track result.teams metrics in broadcast summary

## Future Enhancements

Potential improvements:
1. Support for @mentions in messages
2. Reaction support for posted messages
3. Threading support for updates
4. Custom channel selection per incident type
5. Retry logic for transient Graph API failures
