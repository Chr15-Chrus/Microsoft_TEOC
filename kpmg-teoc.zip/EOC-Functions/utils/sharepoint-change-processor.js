/**
 * SharePoint Change Processor
 * Processes SharePoint webhook notifications:
 * 1. Fetches most recent item from SharePoint list via Graph API
 * 2. Normalizes item to eventData format
 * 3. Checks deduplication state
 * 4. Returns normalized event data for routing and broadcasting
 */

const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { getSharePointAccessToken } = require('./sharepoint-auth');
const { isItemProcessed, updateLastProcessedState } = require('./notification-state');

/**
 * Fetch most recent item from SharePoint list using Graph API
 * @param {string} siteGraphId - SharePoint site Graph ID (hostname,site-id,web-id)
 * @param {string} listId - SharePoint list GUID
 * @param {string} accessToken - Graph API access token
 * @param {Object} context - Function context for logging
 * @returns {Promise<Object|null>} Most recent item or null if none found
 */
async function fetchMostRecentItem(siteGraphId, listId, accessToken, context) {
    try {
        // Query for most recently modified item (descending order, top 1)
        const graphUrl = `https://graph.microsoft.com/v1.0/sites/${siteGraphId}/lists/${listId}/items`;
        const params = {
            $expand: 'fields',
            $orderby: 'lastModifiedDateTime desc',
            $top: 1
        };
        
        context?.log?.(`Fetching most recent item from SharePoint: ${graphUrl}`);
        
        const response = await axios.get(graphUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            },
            params
        });
        
        const items = response.data.value || [];
        
        if (items.length === 0) {
            context?.warn?.('No items found in SharePoint list');
            return null;
        }
        
        const item = items[0];
        context?.log?.(`Fetched item ${item.id} (modified: ${item.lastModifiedDateTime})`);
        
        return {
            id: item.id,
            etag: item.eTag,
            lastModifiedDateTime: item.lastModifiedDateTime,
            createdDateTime: item.createdDateTime,
            fields: item.fields || {}
        };
        
    } catch (error) {
        context?.error?.('Error fetching SharePoint item:', error.response?.data || error.message);
        throw new Error(`Failed to fetch SharePoint item: ${error.message}`);
    }
}

/**
 * Parse coordinates from different location field formats
 * @param {Object} locationData - Location data object
 * @returns {Object|undefined} Coordinates {lat, lon} or undefined
 */
function parseCoordinates(locationData) {
    if (!locationData) return undefined;
    
    // Check for Coordinates property (various formats)
    if (locationData.Coordinates || locationData.coordinates) {
        const coords = locationData.Coordinates || locationData.coordinates;
        if (coords.Latitude && coords.Longitude) {
            return {
                lat: parseFloat(coords.Latitude),
                lon: parseFloat(coords.Longitude)
            };
        } else if (coords.latitude && coords.longitude) {
            return {
                lat: parseFloat(coords.latitude),
                lon: parseFloat(coords.longitude)
            };
        }
    }
    
    return undefined;
}

/**
 * Parse location from SharePoint field (JSON or string format)
 * @param {Object} fields - SharePoint item fields
 * @returns {Object|undefined} Parsed location object
 */
function parseLocation(fields) {
    let locationData = null;
    
    // Try to parse Location field (could be JSON string or object)
    if (fields.Location) {
        try {
            locationData = typeof fields.Location === 'string' 
                ? JSON.parse(fields.Location) 
                : fields.Location;
        } catch (e) {
            // If not JSON, treat as simple string address
            return {
                displayName: fields.Location,
                address: fields.Location
            };
        }
    }
    
    // If we have structured location data
    if (locationData) {
        const location = {
            displayName: locationData.DisplayName || locationData.displayName || ''
        };
        
        // Parse address
        if (locationData.Address || locationData.address) {
            const addr = locationData.Address || locationData.address;
            location.address = {
                street: addr.Street || addr.street || '',
                city: addr.City || addr.city || '',
                state: addr.State || addr.state || addr.StateOrProvince || addr.stateOrProvince || '',
                postalCode: addr.PostalCode || addr.postalCode || addr.ZipCode || addr.zipCode || '',
                country: addr.CountryOrRegion || addr.countryOrRegion || addr.Country || addr.country || ''
            };
        }
        
        // Parse coordinates using helper function
        const coords = parseCoordinates(locationData);
        if (coords) {
            location.coordinates = coords;
        }
        
        return location;
    }
    
    // Fallback: try individual fields
    const location = {};
    if (fields.City || fields.State || fields.Country) {
        location.address = {
            city: fields.City || '',
            state: fields.State || '',
            country: fields.Country || ''
        };
    }
    
    if (fields.Latitude && fields.Longitude) {
        location.coordinates = {
            lat: parseFloat(fields.Latitude),
            lon: parseFloat(fields.Longitude)
        };
    }
    
    return Object.keys(location).length > 0 ? location : undefined;
}

/**
 * Map SharePoint item fields to normalized eventData format
 * @param {Object} item - SharePoint item with fields
 * @param {Object} source - DataSource entity
 * @returns {Object} Normalized eventData
 */
function normalizeSharePointItem(item, source) {
    const fields = item.fields;
    
    // Determine priority/severity
    let priority = 'medium';
    let severity = fields.Severity || fields.severity;
    
    if (fields.ImmediateNeedsRequired === true || fields.ImmediateNeedsRequired === 'Yes') {
        priority = 'high';
        severity = severity || 'High';
    } else if (severity) {
        // Map severity to priority
        const sev = String(severity).toLowerCase();
        if (sev.includes('critical') || sev.includes('urgent')) {
            priority = 'critical';
        } else if (sev.includes('high')) {
            priority = 'high';
        } else if (sev.includes('low')) {
            priority = 'low';
        }
    }
    
    // Parse location
    const location = parseLocation(fields);
    
    // Build normalized event data
    const eventData = {
        // Core identification
        itemId: String(item.id),
        sourceId: source.rowKey,
        sourceName: source.name,
        sourceType: source.type || 'sharepoint',
        sourceListId: source.listId,
        siteUrl: source.siteUrl,
        listId: source.listId, // Alias for compatibility
        
        // Content
        title: fields.Title || 'Untitled Item',
        description: fields.Description || fields.MoreInformation || fields.AdditionalInfo || '',
        
        // Classification
        eventType: fields.EventType || fields.EventCausedDamage || fields.Category || 'General',
        priority: priority,
        severity: severity,
        status: fields.Status || 'New',
        
        // Location (parsed with coordinates if available)
        location: location,
        
        // Contact information
        contactName: fields.ContactName || fields.Contact_x0020_Name || fields.ContactPerson,
        contactEmail: fields.ContactEmail || fields.Email,
        contactPhone: fields.ContactPhone || fields.ContactPhoneNumber || fields.Phone,
        
        // Teams channel URL for Graph API posting
        TeamWebURL: fields.TeamWebURL || fields.teamWebUrl || fields.TeamWeb,
        
        // Timestamps
        createdDate: item.createdDateTime,
        modifiedDate: item.lastModifiedDateTime,
        
        // Metadata
        etag: item.etag,
        acknowledgedBy: fields.Acknowledged || fields.AcknowledgedBy,
        
        // CloudEvents standard fields for compatibility
        id: uuidv4(),
        source: `sharepoint://${new URL(source.siteUrl).host}/lists/${source.listId}`,
        type: 'TEOC.Item.Updated',
        time: item.lastModifiedDateTime || new Date().toISOString(),
        subject: `/items/${item.id}`
    };
    
    return eventData;
}

/**
 * Process a SharePoint webhook notification
 * Fetches item, checks deduplication, normalizes to eventData
 * @param {Object} source - DataSource entity from DataSources table
 * @param {Object} notification - Webhook notification data
 * @param {Object} context - Function context for logging
 * @returns {Promise<Object|null>} Normalized eventData or null if duplicate/error
 */
async function processSharePointChange(source, notification, context) {
    try {
        context?.log?.(`Processing SharePoint change for source: ${source.rowKey} (${source.name})`);
        
        // Get Graph access token
        const accessToken = await getSharePointAccessToken();
        
        // Fetch most recent item from list
        const item = await fetchMostRecentItem(
            source.siteGraphId,
            source.listId,
            accessToken,
            context
        );
        
        if (!item) {
            context?.warn?.(`No items found in list for source ${source.rowKey}`);
            return null;
        }
        
        // Check if this item was already processed (deduplication)
        const isDuplicate = await isItemProcessed(
            source.rowKey,
            item.id,
            item.etag,
            context
        );
        
        if (isDuplicate) {
            context?.log?.(`Skipping duplicate notification for item ${item.id}`);
            return null;
        }
        
        // Normalize SharePoint item to eventData format
        const eventData = normalizeSharePointItem(item, source);
        
        context?.log?.('Normalized eventData:', {
            itemId: eventData.itemId,
            title: eventData.title,
            priority: eventData.priority,
            hasLocation: !!eventData.location,
            hasCoordinates: !!(eventData.location?.coordinates)
        });
        
        // Update deduplication state
        await updateLastProcessedState(
            source.rowKey,
            item.id,
            item.etag,
            context
        );
        
        return eventData;
        
    } catch (error) {
        context?.error?.(`Error processing SharePoint change for source ${source.rowKey}:`, error);
        throw error;
    }
}

module.exports = {
    processSharePointChange,
    fetchMostRecentItem,
    normalizeSharePointItem,
    parseLocation
};
