const axios = require('axios');
const { getSecretValue } = require('./secretProvider');

/**
 * Gets Microsoft Graph access token using Azure AD client credentials (app-only)
 * ⚠️ WARNING: This grants access to ALL SharePoint data regardless of user permissions.
 * Only use for admin operations like webhook registration.
 * For data access, use getUserGraphToken() with user's token.
 * @returns {Promise<string>} Access token
 */
async function getSharePointAccessToken() {
    const tenantId = await getSecretValue(['SHAREPOINT_TENANT_ID', 'ENTRA_TENANT_ID'], { optional: true });
    const clientId = await getSecretValue(['SHAREPOINT_CLIENT_ID', 'ENTRA_CLIENT_ID'], { optional: true });
    const clientSecret = await getSecretValue(['SHAREPOINT_CLIENT_SECRET', 'ENTRA_CLIENT_SECRET'], { optional: true });

    if (!tenantId || !clientId || !clientSecret) {
        throw new Error('SharePoint authentication not configured');
    }

    // Use Microsoft Graph API with Azure AD v2.0 endpoint
    const tokenEndpoint = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;

    const params = new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: clientId,
        client_secret: clientSecret,
        scope: 'https://graph.microsoft.com/.default'
    });

    try {
        const response = await axios.post(tokenEndpoint, params, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        return response.data.access_token;
    } catch (error) {
        console.error('Error getting Graph token:', error.response?.data || error.message);
        throw new Error(`Failed to authenticate with Microsoft Graph: ${error.response?.data?.error_description || error.message}`);
    }
}

/**
 * Exchanges user's Entra ID token for Microsoft Graph token using On-Behalf-Of flow
 * This ensures SharePoint API calls respect user's permissions
 * @param {string} userToken - User's bearer token from Authorization header
 * @returns {Promise<string>} Graph access token with user's delegated permissions
 * @throws {Error} If token is invalid or OBO flow fails
 */
async function getUserGraphToken(userToken) {
    // Validate input token
    if (!userToken || typeof userToken !== 'string' || userToken.trim() === '') {
        throw new Error('Invalid user token: token is required and must be a non-empty string');
    }

    const tenantId = await getSecretValue(['ENTRA_TENANT_ID', 'SHAREPOINT_TENANT_ID'], { optional: true });
    const clientId = await getSecretValue(['ENTRA_CLIENT_ID', 'SHAREPOINT_CLIENT_ID'], { optional: true });
    const clientSecret = await getSecretValue(['ENTRA_CLIENT_SECRET', 'SHAREPOINT_CLIENT_SECRET'], { optional: true });

    if (!tenantId || !clientId || !clientSecret) {
        throw new Error('Entra ID authentication not configured');
    }

    // Remove 'Bearer ' prefix if present
    const cleanToken = userToken.replace(/^Bearer\s+/i, '').trim();
    
    if (cleanToken === '') {
        throw new Error('Invalid user token: token is empty after removing Bearer prefix');
    }

    const tokenEndpoint = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;

    const params = new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        client_id: clientId,
        client_secret: clientSecret,
        assertion: cleanToken,
        requested_token_use: 'on_behalf_of',
        scope: 'https://graph.microsoft.com/Sites.Read.All https://graph.microsoft.com/Sites.ReadWrite.All'
    });

    try {
        const response = await axios.post(tokenEndpoint, params, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        return response.data.access_token;
    } catch (error) {
        console.error('Error getting user Graph token (OBO):', error.response?.data || error.message);
        throw new Error(`Failed to exchange token for Graph access: ${error.response?.data?.error_description || error.message}`);
    }
}

module.exports = { 
    getSharePointAccessToken,
    getUserGraphToken
};
