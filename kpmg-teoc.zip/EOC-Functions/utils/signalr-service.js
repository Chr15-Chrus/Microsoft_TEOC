/**
 * SignalR Service Utility
 * Provides SignalR connection token generation using REST API
 * This is more reliable than Azure Functions SignalR bindings in v4
 */

const crypto = require('crypto');

// Configuration constants
const MIN_ACCESS_KEY_LENGTH = 20; // Azure SignalR keys are base64-encoded, typically 40+ chars
const DEFAULT_TOKEN_EXPIRATION_SECONDS = 3600; // 1 hour

/**
 * Parse SignalR connection string into components
 * @param {string} connectionString - SignalR connection string
 * @returns {Object} Parsed connection info
 */
function parseConnectionString(connectionString) {
    if (!connectionString) {
        throw new Error('SignalR connection string is required');
    }

    const parts = {};
    connectionString.split(';').forEach(part => {
        const [key, ...valueParts] = part.split('=');
        if (key && valueParts.length > 0) {
            parts[key.trim()] = valueParts.join('=').trim();
        }
    });

    if (!parts.Endpoint) {
        throw new Error('Invalid SignalR connection string: missing Endpoint');
    }
    if (!parts.AccessKey) {
        throw new Error('Invalid SignalR connection string: missing AccessKey');
    }

    // Validate endpoint format
    const endpoint = parts.Endpoint.replace(/\/$/, ''); // Remove trailing slash
    if (!endpoint.startsWith('https://')) {
        throw new Error('Invalid SignalR endpoint: must use HTTPS protocol');
    }

    // Validate access key has reasonable length
    if (parts.AccessKey.length < MIN_ACCESS_KEY_LENGTH) {
        throw new Error('Invalid SignalR access key: key appears too short');
    }

    return {
        endpoint,
        accessKey: parts.AccessKey,
        version: parts.Version || '1.0'
    };
}

/**
 * Generate JWT token for SignalR client connection
 * @param {string} endpoint - SignalR endpoint URL
 * @param {string} accessKey - SignalR access key
 * @param {string} hubName - Hub name
 * @param {string} userId - Optional user ID
 * @param {number} expiresInSeconds - Token expiration time in seconds
 * @returns {string} JWT token
 */
function generateAccessToken(endpoint, accessKey, hubName, userId = null, expiresInSeconds = DEFAULT_TOKEN_EXPIRATION_SECONDS) {
    const audience = `${endpoint}/client/?hub=${hubName}`;
    const expiration = Math.floor(Date.now() / 1000) + expiresInSeconds;

    // Create JWT payload
    const payload = {
        aud: audience,
        exp: expiration
    };

    // Add user ID if provided
    if (userId) {
        payload.sub = userId;
    }

    // Create JWT header
    const header = {
        typ: 'JWT',
        alg: 'HS256'
    };

    // Encode header and payload
    const encodedHeader = base64UrlEncode(JSON.stringify(header));
    const encodedPayload = base64UrlEncode(JSON.stringify(payload));

    // Create signature
    const signatureInput = `${encodedHeader}.${encodedPayload}`;
    const signature = crypto
        .createHmac('sha256', accessKey)
        .update(signatureInput)
        .digest('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');

    // Combine into JWT
    return `${signatureInput}.${signature}`;
}

/**
 * Base64 URL encode a string
 * @param {string} str - String to encode
 * @returns {string} Base64 URL encoded string
 */
function base64UrlEncode(str) {
    return Buffer.from(str)
        .toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');
}

/**
 * Generate SignalR connection info for client
 * @param {string} connectionString - SignalR connection string from environment
 * @param {string} hubName - Hub name
 * @param {string} userId - Optional user ID for user-specific connections
 * @param {number} tokenExpirationSeconds - Optional token expiration time
 * @returns {Object} Connection info object { url, accessToken }
 */
function getConnectionInfo(connectionString, hubName, userId = null, tokenExpirationSeconds = DEFAULT_TOKEN_EXPIRATION_SECONDS) {
    try {
        // Parse connection string
        const { endpoint, accessKey } = parseConnectionString(connectionString);

        // Generate access token
        const accessToken = generateAccessToken(endpoint, accessKey, hubName, userId, tokenExpirationSeconds);

        // Construct client URL
        const url = `${endpoint}/client/?hub=${hubName}`;

        return {
            url,
            accessToken
        };
    } catch (error) {
        console.error('[SignalR] Error generating connection info:', error);
        throw new Error(`Failed to generate SignalR connection info: ${error.message}`);
    }
}

module.exports = {
    getConnectionInfo,
    parseConnectionString,
    generateAccessToken
};
