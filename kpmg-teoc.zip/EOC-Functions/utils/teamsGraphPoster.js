/**
 * Teams Graph API Poster
 *
 * Posts messages to Microsoft Teams channels using Microsoft Graph API
 * given a TeamWebURL from SharePoint.
 *
 * Parsing rules (intentionally simple and robust):
 * - channelId = substring between "/l/team/" and "/conversations"
 * - teamId    = value of "groupId" query param
 *
 * No regex validation. Microsoft Graph is the source of truth.
 */

const axios = require('axios');
const { getGraphAccessToken } = require('./graphAuth');

/**
 * Parse teamId and channelId from TeamWebURL
 */
function parseTeamWebUrl(teamWebUrl) {
    try {
        if (!teamWebUrl || typeof teamWebUrl !== 'string') {
            throw new Error('TeamWebURL is missing or not a string');
        }

        // Extract channelId
        const teamPathMarker = '/l/team/';
        const convoMarker = '/conversations';

        const teamPathStart = teamWebUrl.indexOf(teamPathMarker);
        const convoStart = teamWebUrl.indexOf(convoMarker);

        if (teamPathStart === -1 || convoStart === -1) {
            throw new Error('TeamWebURL does not contain expected path segments');
        }

        const rawChannelId = teamWebUrl.substring(
            teamPathStart + teamPathMarker.length,
            convoStart
        );

        const channelId = decodeURIComponent(rawChannelId);

        // Extract teamId from query string
        const url = new URL(teamWebUrl);
        const teamId = url.searchParams.get('groupId');

        if (!teamId) {
            throw new Error('groupId not found in TeamWebURL');
        }

        const parsed = {
            teamId,
            channelId
        };

        console.log('Parsed TeamWebURL', { teamId, channelId });
        return parsed;

    } catch (err) {
        console.error('Failed to parse TeamWebURL', {
            teamWebUrl,
            error: err.message
        });
        return null;
    }
}

const MAX_DESCRIPTION_LENGTH = 200;

/**
 * Escape HTML special characters to prevent XSS
 */
function escapeHtml(text) {
    if (!text) return text;
    const str = String(text);
    const htmlEscapeMap = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    };
    return str.replace(/[&<>"']/g, (match) => htmlEscapeMap[match]);
}

function buildTextSummaryContent(eventData) {
    const title = escapeHtml(eventData.title || 'New TEOC Event');
    const rawPriority = eventData.priority || 'N/A';
    const priority = escapeHtml(rawPriority);
    const itemId = escapeHtml(eventData.itemId || eventData.id || 'Unknown');
    
    // Location handling
    let locationHtml = '';
    if (eventData.location) {
        const displayName = escapeHtml(eventData.location.displayName || '');
        const city = escapeHtml(eventData.location.address?.city || '');
        const state = escapeHtml(eventData.location.address?.state || '');
        const country = escapeHtml(eventData.location.address?.countryOrRegion || '');
        
        const locationParts = [displayName, city, state, country].filter(Boolean);
        const locationString = locationParts.join(', ') || 'Location not specified';
        
        locationHtml = `<p><strong>📍 Location:</strong> ${locationString}</p>`;
        
        // Add coordinates if available
        if (eventData.location.coordinates) {
            const lat = eventData.location.coordinates.lat;
            const lon = eventData.location.coordinates.lon;
            if (typeof lat === 'number' && typeof lon === 'number') {
                locationHtml += `<p><em>Coordinates: ${lat.toFixed(6)}, ${lon.toFixed(6)}</em></p>`;
            }
        }
    } else {
        locationHtml = `<p><strong>📍 Location:</strong> Not specified</p>`;
    }
    
    // Priority with emoji indicator
    const priorityEmoji = {
        'critical': '🔴',
        'high': '🟠',
        'medium': '🟡',
        'low': '🟢'
    }[rawPriority.toLowerCase()] || '⚪';
    
    // Event type
    const eventType = escapeHtml(eventData.eventType || eventData.EventCausedDamage || 'General Event');
    
    // Status
    const status = escapeHtml(eventData.status || 'New');
    
    // Contact information
    let contactHtml = '';
    if (eventData.contactName || eventData.ContactName || eventData.Contact_x0020_Name) {
        const contactName = escapeHtml(eventData.contactName || eventData.ContactName || eventData.Contact_x0020_Name);
        contactHtml = `<p><strong>👤 Contact:</strong> ${contactName}</p>`;
    }
    
    // Description/Details
    let descriptionHtml = '';
    if (eventData.description || eventData.Description) {
        const desc = eventData.description || eventData.Description;
        const truncatedDesc = desc.length > MAX_DESCRIPTION_LENGTH ? desc.substring(0, MAX_DESCRIPTION_LENGTH) + '...' : desc;
        descriptionHtml = `<p><strong>Details:</strong> ${escapeHtml(truncatedDesc)}</p>`;
    }
    
    // Timestamp
    const timestamp = eventData.timestamp || eventData.Created || new Date().toISOString();
    let formattedTime;
    try {
        const date = new Date(timestamp);
        if (!isNaN(date.getTime())) {
            formattedTime = date.toLocaleString('en-US', {
                dateStyle: 'medium',
                timeStyle: 'short'
            });
        } else {
            formattedTime = timestamp;
        }
    } catch (err) {
        formattedTime = timestamp;
    }
    formattedTime = escapeHtml(formattedTime);
    
    // Build the complete HTML
    return `
        <h2>🚨 ${title}</h2>
        <hr/>
        <p><strong>${priorityEmoji} Priority:</strong> <span style="text-transform: uppercase;">${priority}</span></p>
        <p><strong>📋 Event Type:</strong> ${eventType}</p>
        <p><strong>📊 Status:</strong> ${status}</p>
        ${locationHtml}
        ${contactHtml}
        ${descriptionHtml}
        <hr/>
        <p><em>📅 ${formattedTime} | Item ID: ${itemId}</em></p>
    `.trim();
}

function normalizeAdaptiveCard(adaptiveCard) {
    if (!adaptiveCard || typeof adaptiveCard !== 'object') {
        return null;
    }

    // Incoming Webhook wrapper format: { type: "message", attachments: [ { content: { ...card... } } ] }
    if (adaptiveCard.type === 'message' && Array.isArray(adaptiveCard.attachments)) {
        const wrapped = adaptiveCard.attachments[0]?.content;
        if (wrapped && typeof wrapped === 'object') {
            return wrapped;
        }
    }

    // Graph-style or generic wrapper: { content: { ...card... } }
    if (adaptiveCard.content && typeof adaptiveCard.content === 'object') {
        return adaptiveCard.content;
    }

    return adaptiveCard;
}

function logGraphPayloadDetails(context, payload, label) {
    const content = payload?.body?.content;
    const attachments = payload?.attachments || [];
    const snippet = typeof content === 'string' ? content.slice(0, 200) : '';
    context.log(`Teams Graph payload [${label}] details`, {
        contentType: typeof content,
        contentSnippet: snippet,
        hasAttachments: attachments.length > 0,
        firstAttachmentContentType: attachments[0]?.contentType,
        firstAttachmentContentTypeOfContent: typeof attachments[0]?.content
    });
}

function redactGraphPayload(payload) {
    if (!payload || typeof payload !== 'object') {
        return payload;
    }
    const copy = JSON.parse(JSON.stringify(payload));
    if (copy.attachments?.[0]?.content) {
        copy.attachments[0].content = '[redacted]';
    }
    if (typeof copy.body?.content === 'string' && copy.body.content.length > 200) {
        copy.body.content = `${copy.body.content.slice(0, 200)}...`;
    }
    return copy;
}

async function postGraphMessage(graphUrl, accessToken, payload, context, label) {
    logGraphPayloadDetails(context, payload, label);
    return axios.post(graphUrl, payload, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
        }
    });
}

/**
 * Post message to Teams channel via Graph API
 */
async function postMessageToTeamsChannel(eventData, context) {
    const result = {
        success: false,
        teamId: null,
        channelId: null,
        error: null,
        cardError: null
    };

    try {
        const teamWebUrl = eventData.TeamWebURL;
        if (!teamWebUrl) {
            throw new Error('Event data does not contain TeamWebURL');
        }

        context.log('Processing Teams post for item', eventData.itemId);

        const parsed = parseTeamWebUrl(teamWebUrl);
        if (!parsed) {
            throw new Error('TeamWebURL parsing failed');
        }

        const { teamId, channelId } = parsed;
        result.teamId = teamId;
        result.channelId = channelId;

        const graphUrl = `https://graph.microsoft.com/v1.0/teams/${teamId}/channels/${encodeURIComponent(channelId)}/messages`;

        context.log('Posting to Graph URL:', graphUrl);

        const accessToken = await getGraphAccessToken();

        // 1) Always post a simple HTML summary first (must succeed)
        const textPayload = {
            body: {
                contentType: 'html',
                content: buildTextSummaryContent(eventData)
            }
        };

        try {
            await postGraphMessage(graphUrl, accessToken, textPayload, context, 'text');
            result.success = true;
        } catch (err) {
            context.error('Teams Graph text post failed', {
                status: err.response?.status,
                data: err.response?.data,
                payload: redactGraphPayload(textPayload)
            });
            result.error = err.message;
            return result;
        }

        // 2) Best-effort adaptive card post
        const adaptiveCard = normalizeAdaptiveCard(eventData.adaptiveCard);
        if (adaptiveCard) {
            const cardPayload = {
                body: {
                    contentType: 'text',
                    content: '' // Empty text body when using attachments
                },
                attachments: [
                    {
                        contentType: 'application/vnd.microsoft.card.adaptive',
                        content: adaptiveCard
                    }
                ]
            };

            try {
                await postGraphMessage(graphUrl, accessToken, cardPayload, context, 'card');
            } catch (err) {
                context.error('Teams Graph adaptive card post failed', {
                    status: err.response?.status,
                    data: err.response?.data,
                    payload: redactGraphPayload(cardPayload)
                });
                result.cardError = err.message;
            }
        } else {
            context.log('No adaptive card to post for item', eventData.itemId);
        }

        return result;

    } catch (err) {
        context.error('Teams Graph post failed', {
            itemId: eventData.itemId,
            error: err.response?.data || err.message
        });

        result.error = err.message;
        return result;
    }
}

module.exports = {
    postMessageToTeamsChannel,
    parseTeamWebUrl
};
