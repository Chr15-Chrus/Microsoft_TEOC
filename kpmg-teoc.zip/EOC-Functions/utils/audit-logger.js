const { TableClient } = require('@azure/data-tables');
const { resolveStorageConnectionString } = require('./data-sources');
const crypto = require('crypto');

const AUDIT_TABLE = 'AuditLog';

/**
 * Log an audit event to Table Storage
 * @param {Object} event - Audit event details
 * @param {string} event.action - Action performed (e.g., 'CREATE_SOURCE', 'UPDATE_SOURCE', 'DELETE_SOURCE')
 * @param {string} event.userId - User ID who performed the action
 * @param {string} event.userEmail - User email
 * @param {string} event.resourceType - Type of resource (e.g., 'DataSource', 'Webhook')
 * @param {string} event.resourceId - ID of the resource
 * @param {Object} event.details - Additional details about the action
 * @param {Object} context - Azure Function context for logging
 */
async function logAuditEvent(event, context) {
    try {
        const connectionString = await resolveStorageConnectionString({ optional: true });
        if (!connectionString) {
            context?.warn?.('Storage connection not configured, skipping audit log');
            return;
        }

        const tableClient = TableClient.fromConnectionString(connectionString, AUDIT_TABLE);
        
        // Ensure table exists
        try {
            await tableClient.createTable();
        } catch (error) {
            // Ignore if table already exists
            if (error.statusCode !== 409 && error.code !== 'TableAlreadyExists') {
                throw error;
            }
        }

        const timestamp = new Date().toISOString();
        // Use random suffix to prevent collisions when multiple actions occur in same millisecond
        const uniqueSuffix = crypto.randomBytes(4).toString('hex');
        const auditEntry = {
            partitionKey: event.resourceType || 'Unknown',
            rowKey: `${timestamp}_${event.userId || 'system'}_${uniqueSuffix}`,
            action: event.action,
            userId: event.userId || 'system',
            userEmail: event.userEmail || 'N/A',
            resourceType: event.resourceType,
            resourceId: event.resourceId,
            timestamp: timestamp,
            details: JSON.stringify(event.details || {})
        };

        await tableClient.createEntity(auditEntry);
        context?.log?.(`Audit log recorded: ${event.action} on ${event.resourceType}/${event.resourceId}`);
    } catch (error) {
        // Don't fail the operation if audit logging fails, just log the error
        context?.error?.('Failed to write audit log:', error.message);
    }
}

/**
 * Query audit logs for a specific resource
 * @param {string} resourceType - Type of resource
 * @param {string} resourceId - ID of the resource
 * @param {Object} context - Azure Function context
 * @returns {Array} Array of audit entries
 */
async function getAuditLogs(resourceType, resourceId, context) {
    try {
        const connectionString = await resolveStorageConnectionString({ optional: true });
        if (!connectionString) {
            return [];
        }

        const tableClient = TableClient.fromConnectionString(connectionString, AUDIT_TABLE);
        const escapedType = String(resourceType).replace(/'/g, "''");
        const escapedId = resourceId !== undefined && resourceId !== null ? String(resourceId).replace(/'/g, "''") : undefined;
        const filter = resourceId 
            ? `PartitionKey eq '${escapedType}' and resourceId eq '${escapedId}'`
            : `PartitionKey eq '${escapedType}'`;

        const entities = tableClient.listEntities({ queryOptions: { filter } });
        const results = [];
        
        for await (const entity of entities) {
            results.push({
                action: entity.action,
                userId: entity.userId,
                userEmail: entity.userEmail,
                resourceId: entity.resourceId,
                timestamp: entity.timestamp,
                details: JSON.parse(entity.details || '{}')
            });
        }

        return results.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    } catch (error) {
        context?.error?.('Failed to retrieve audit logs:', error.message);
        return [];
    }
}

module.exports = {
    logAuditEvent,
    getAuditLogs,
    AUDIT_TABLE
};
