const axios = require('axios');
const { getSecretValue } = require('./secretProvider');

function extractAddressComponents(feature = {}) {
    const components = {
        Street: '',
        City: '',
        State: '',
        CountryOrRegion: '',
        PostalCode: ''
    };

    const contextEntries = Array.isArray(feature.context) ? feature.context : [];
    contextEntries.forEach((entry) => {
        if (!entry?.id) {
            return;
        }
        if (entry.id.startsWith('place')) {
            components.City = components.City || entry.text || entry.place_name || '';
        } else if (entry.id.startsWith('region')) {
            components.State = components.State || entry.text || '';
        } else if (entry.id.startsWith('country')) {
            components.CountryOrRegion = components.CountryOrRegion || entry.text || '';
        } else if (entry.id.startsWith('postcode')) {
            components.PostalCode = components.PostalCode || entry.text || '';
        }
    });

    const featureProps = feature.properties || {};
    if (featureProps.address) {
        components.Street = components.Street || featureProps.address;
    }

    if (!components.Street && feature.address && feature.text) {
        components.Street = `${feature.address} ${feature.text}`.trim();
    }

    if (!components.Street && Array.isArray(feature.place_type) && feature.place_type.includes('address')) {
        components.Street = feature.text || '';
    }

    if (!components.Street && feature.place_name) {
        components.Street = feature.place_name;
    }

    return components;
}

/**
 * Forward geocode an address using Mapbox.
 * Returns null when no coordinates can be determined (or when optional=true and token/result missing).
 * @param {string} address - Free-form address text
 * @param {object} [options]
 * @param {boolean} [options.optional=true] - When true, suppresses thrown errors for missing config or no results
 * @param {number} [options.limit=1] - How many results Mapbox should return
 * @param {string} [options.language] - Language hint for Mapbox
 * @param {object} [options.context] - Azure Functions context for logging
 * @returns {Promise<object|null>} Geocode payload matching geocode function output or null when not found
 */
async function forwardGeocode(address, options = {}) {
    const trimmed = (address || '').trim();
    if (!trimmed) {
        return null;
    }

    const optional = options.optional !== undefined ? options.optional : true;
    const context = options.context;

    const mapboxToken = await getSecretValue('MAPBOX_API_KEY', { optional });
    if (!mapboxToken) {
        if (!optional) {
            throw new Error('Mapbox API key not configured');
        }
        return null;
    }

    const params = new URLSearchParams({ access_token: mapboxToken });
    if (options.limit) {
        params.set('limit', String(options.limit));
    }
    if (options.language) {
        params.set('language', options.language);
    }

    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(trimmed)}.json?${params.toString()}`;

    if (context?.log) {
        context.log(`[mapbox-geocode] Forward geocoding "${trimmed}"`);
    }

    try {
        const response = await axios.get(url);
        const feature = response.data?.features?.[0];
        if (!feature || !Array.isArray(response.data?.features) || response.data.features.length === 0) {
            if (context?.warn) {
                context.warn(`[mapbox-geocode] No results for "${trimmed}"`);
            }
            return null;
        }

        const coords = feature.center || [];
        if (!Array.isArray(coords) || coords.length < 2) {
            return null;
        }

        return {
            displayName: feature.place_name || trimmed,
            address: extractAddressComponents(feature),
            locationUri: feature.properties?.wikidata || feature.id || '',
            coordinates: {
                latitude: coords[1],
                longitude: coords[0]
            },
            feature
        };
    } catch (error) {
        const status = error.response?.status;
        const message = error.response?.data?.message || error.message;
        if (context?.error) {
            context.error(`[mapbox-geocode] Error (${status || 'n/a'}) for "${trimmed}": ${message}`);
        }

        if (status === 401) {
            throw new Error('Invalid Mapbox API key');
        }

        if (optional) {
            return null;
        }

        throw new Error(`Mapbox geocoding failed: ${message}`);
    }
}

module.exports = {
    forwardGeocode
};
