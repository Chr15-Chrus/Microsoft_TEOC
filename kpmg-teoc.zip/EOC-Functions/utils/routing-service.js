// Routing service - determines which teams should receive events
const { TableClient } = require('@azure/data-tables');
const { resolveStorageConnectionString } = require('./data-sources');

class RoutingService {
  constructor() {
    this.tableName = process.env.ROUTING_CONFIG_TABLE || 'RoutingConfiguration';
    this.cache = null;
    this.cacheExpiry = null;
    this.CACHE_TTL = 5 * 60 * 1000; // 5 minutes
    this.tableClientPromise = null;
  }

  async getTableClient() {
    if (this.tableClientPromise) {
      return this.tableClientPromise;
    }

    this.tableClientPromise = (async () => {
      const connectionString = await resolveStorageConnectionString();
      if (!connectionString) {
        throw new Error('Storage connection string not configured. Set AZURE_STORAGE_CONNECTION_STRING or AzureWebJobsStorage.');
      }
      return TableClient.fromConnectionString(connectionString, this.tableName);
    })();

    try {
      const client = await this.tableClientPromise;
      return client;
    } catch (error) {
      this.tableClientPromise = null;
      throw error;
    }
  }

  /**
   * Load routing configuration from Azure Table Storage
   */
  async loadRoutingConfig() {
    // Check cache first
    if (this.cache && this.cacheExpiry > Date.now()) {
      return this.cache;
    }

    try {
      const client = await this.getTableClient();

      // Load main configuration
      let mainConfig;
      try {
        mainConfig = await client.getEntity('config', 'main');
      } catch (error) {
        console.warn('Main configuration not found, using defaults');
        mainConfig = this.getDefaultConfig();
      }

      // Load event teams
      const eventTeams = await this.loadEventTeams(client);

      // Load organizational teams
      const orgTeams = await this.loadOrgTeams(client);

      // Combine into complete configuration
      const config = {
        version: mainConfig.version || '1.0',
        lastUpdated: mainConfig.lastUpdated || new Date().toISOString(),
        defaultTeam: mainConfig.defaultTeam ? JSON.parse(mainConfig.defaultTeam) : this.getDefaultTeam(),
        eventTeams: eventTeams,
        organizationalTeams: orgTeams,
        routingRules: mainConfig.routingRules ? JSON.parse(mainConfig.routingRules) : this.getDefaultRoutingRules()
      };

      // Update cache
      this.cache = config;
      this.cacheExpiry = Date.now() + this.CACHE_TTL;

      return config;
    } catch (error) {
      console.error('Failed to load configuration:', error);

      // Return cached config if available
      if (this.cache) {
        console.warn('Using stale cached configuration');
        return this.cache;
      }

      // Return minimal default configuration
      return this.getMinimalConfig();
    }
  }

  /**
   * Load event teams from storage
   */
  async loadEventTeams(client) {
    const teams = [];
    try {
      const entities = client.listEntities({
        queryOptions: { filter: `PartitionKey eq 'event-team'` }
      });

      for await (const entity of entities) {
        try {
          teams.push({
            eventId: entity.rowKey,
            name: entity.name,
            active: entity.active === true,
            priority: entity.priority || 90,
            dateRange: JSON.parse(entity.dateRange || '{}'),
            geography: JSON.parse(entity.geography || '{}'),
            triggers: JSON.parse(entity.triggers || '{}'),
            signalRGroup: entity.signalRGroup,
            teams: JSON.parse(entity.teams || '[]'),
            metadata: entity.metadata ? JSON.parse(entity.metadata) : {}
          });
        } catch (err) {
          console.error(`Error parsing event team ${entity.rowKey}:`, err);
        }
      }
    } catch (error) {
      console.error('Error loading event teams:', error);
    }

    return teams;
  }

  /**
   * Load organizational teams from storage
   */
  async loadOrgTeams(client) {
    const teams = [];
    try {
      const entities = client.listEntities({
        queryOptions: { filter: `PartitionKey eq 'org-team'` }
      });

      for await (const entity of entities) {
        try {
          teams.push({
            orgUnitId: entity.rowKey,
            name: entity.name,
            active: entity.active === true,
            priority: entity.priority || 50,
            hierarchy: JSON.parse(entity.hierarchy || '{}'),
            geography: JSON.parse(entity.geography || '{}'),
            responsibilities: JSON.parse(entity.responsibilities || '{}'),
            signalRGroup: entity.signalRGroup,
            teams: JSON.parse(entity.teams || '[]'),
            escalation: entity.escalation ? JSON.parse(entity.escalation) : null,
            metadata: entity.metadata ? JSON.parse(entity.metadata) : {}
          });
        } catch (err) {
          console.error(`Error parsing org team ${entity.rowKey}:`, err);
        }
      }
    } catch (error) {
      console.error('Error loading organizational teams:', error);
    }

    return teams;
  }

  /**
   * Determine routing for an item
   */
  async determineRoutes(itemData) {
    const config = await this.loadRoutingConfig();
    const routes = [];

    // 1. Check for explicit routing
    if (itemData.targetTeamId) {
      const explicitRoute = this.findTeamById(itemData.targetTeamId, config);
      if (explicitRoute) {
        return [{
          ...explicitRoute,
          reason: 'explicit-assignment',
          priority: 100
        }];
      }
    }

    // 2. Evaluate active event teams
    const eventRoutes = await this.evaluateEventTeams(itemData, config.eventTeams);
    routes.push(...eventRoutes);

    // 3. Evaluate BAU organizational teams (only if no event routes found)
    if (routes.length === 0 || config.routingRules.multiTeamRouting?.enabled) {
      const orgRoutes = await this.evaluateOrgTeams(itemData, config.organizationalTeams);
      routes.push(...orgRoutes);
    }

    // 4. Apply multi-team routing rules
    const finalRoutes = this.applyMultiTeamRules(routes, config.routingRules);

    // 5. Fallback if no routes found
    if (finalRoutes.length === 0 && config.defaultTeam) {
      return [{
        teamId: 'default',
        teamName: config.defaultTeam.teamName || 'Default Operations',
        signalRGroup: config.defaultTeam.signalRGroup || 'team-default',
        reason: 'fallback',
        priority: 10
      }];
    }

    return finalRoutes;
  }

  /**
   * Evaluate event team rules
   */
  async evaluateEventTeams(itemData, eventTeams) {
    const routes = [];
    const now = new Date();

    for (const event of eventTeams) {
      if (!event.active) continue;

      // Check date range
      if (event.dateRange.start && event.dateRange.end) {
        const inDateRange = now >= new Date(event.dateRange.start) &&
          now <= new Date(event.dateRange.end);
        if (!inDateRange) continue;
      }

      // Check geography
      if (event.geography && itemData.location) {
        const matchesGeography = this.checkGeographyMatch(itemData.location, event.geography);
        if (!matchesGeography) continue;
      }

      // Check triggers
      if (event.triggers) {
        const matchesTriggers = this.checkTriggers(itemData, event.triggers);
        if (!matchesTriggers) continue;
      }

      // Add route for this event
      routes.push({
        teamId: event.eventId,
        teamName: event.name,
        signalRGroup: event.signalRGroup,
        teamsWebhooks: this.extractWebhookUrls(event.teams),
        reason: `event:${event.eventId}`,
        priority: event.priority || 90,
        context: {
          eventName: event.name,
          eventType: 'special-event'
        }
      });
    }

    return routes;
  }

  /**
   * Evaluate organizational team rules
   */
  async evaluateOrgTeams(itemData, orgTeams) {
    const routes = [];

    for (const org of orgTeams) {
      if (!org.active) continue;

      let matchScore = 0;

      // Check geography match
      if (org.geography && itemData.location) {
        if (this.checkGeographyMatch(itemData.location, org.geography)) {
          matchScore += 30;
        }
      }

      // Check responsibility match
      if (org.responsibilities?.eventTypes) {
        if (org.responsibilities.eventTypes.includes(itemData.eventType)) {
          matchScore += 40;
        }
      }

      // Check explicit assignment
      if (itemData.assignedOrgUnit === org.orgUnitId) {
        matchScore += 50;
      }

      // Threshold for BAU routing (30 = geography match minimum)
      if (matchScore >= 30) {
        routes.push({
          teamId: org.orgUnitId,
          teamName: org.name,
          signalRGroup: org.signalRGroup,
          teamsWebhooks: this.extractWebhookUrls(org.teams),
          reason: `org:${org.orgUnitId}`,
          priority: org.priority || 50,
          matchScore: matchScore,
          context: {
            orgName: org.name,
            eventType: 'bau'
          }
        });
      }
    }

    return routes.sort((a, b) => b.matchScore - a.matchScore);
  }

  /**
   * Check if location matches geography criteria
   */
  checkGeographyMatch(location, geography) {
    if (!location || !geography) return false;

    // Check region names
    if (geography.regions && Array.isArray(geography.regions)) {
      const matchesRegion = geography.regions.some(region => {
        const regionLower = region.toLowerCase();
        return (
          location.city?.toLowerCase().includes(regionLower) ||
          location.address?.toLowerCase().includes(regionLower) ||
          location.state?.toLowerCase().includes(regionLower)
        );
      });
      if (matchesRegion) return true;
    }

    // Check radius from center
    if (geography.type === 'radius' && geography.center && location.coordinates) {
      const distance = this.calculateDistance(
        location.coordinates.lat,
        location.coordinates.lon,
        geography.center.lat,
        geography.center.lon
      );
      return distance <= (geography.radiusKm || 50);
    }

    // Check state/province
    if (geography.states && Array.isArray(geography.states)) {
      return geography.states.some(state =>
        location.state?.toLowerCase().includes(state.toLowerCase())
      );
    }

    return false;
  }

  /**
   * Check if item matches event triggers
   */
  checkTriggers(itemData, triggers) {
    let matches = false;

    // Check event types
    if (triggers.eventTypes && Array.isArray(triggers.eventTypes)) {
      if (triggers.eventTypes.includes(itemData.eventType)) {
        matches = true;
      }
    }

    // Check keywords
    if (triggers.keywords && Array.isArray(triggers.keywords)) {
      const text = `${itemData.title} ${itemData.description}`.toLowerCase();
      const keywordMatch = triggers.keywords.some(keyword =>
        text.includes(keyword.toLowerCase())
      );
      if (keywordMatch) matches = true;
    }

    // Check priority threshold
    if (triggers.priorityMin || triggers.severityMin) {
      // If no event type or keyword match, priority alone isn't enough
      if (!matches) return false;
      
      // Validate priority meets minimum
      const priorityLevels = { low: 1, medium: 2, high: 3, critical: 4 };
      const itemPriorityLevel = priorityLevels[itemData.priority] || 2;
      const minPriorityLevel = priorityLevels[triggers.priorityMin] || 1;
      
      if (itemPriorityLevel < minPriorityLevel) {
        matches = false;
      }
    }

    return matches;
  }

  /**
   * Calculate distance between two coordinates (Haversine formula)
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  toRad(degrees) {
    return degrees * Math.PI / 180;
  }

  /**
   * Apply multi-team routing rules
   */
  applyMultiTeamRules(routes, routingRules) {
    if (!routingRules.multiTeamRouting?.enabled) {
      // Return only highest priority route
      return routes.length > 0 ? [routes[0]] : [];
    }

    const maxTeams = routingRules.multiTeamRouting.maxTeams || 3;
    const priorityThreshold = routingRules.multiTeamRouting.priorityThreshold || 70;

    // Filter by priority threshold and limit count
    return routes
      .filter(r => r.priority >= priorityThreshold)
      .slice(0, maxTeams);
  }

  /**
   * Find team by ID across all team types
   */
  findTeamById(teamId, config) {
    // Check event teams
    const eventTeam = config.eventTeams.find(t => t.eventId === teamId);
    if (eventTeam) {
      return {
        teamId: eventTeam.eventId,
        teamName: eventTeam.name,
        signalRGroup: eventTeam.signalRGroup
      };
    }

    // Check org teams
    const orgTeam = config.organizationalTeams.find(t => t.orgUnitId === teamId);
    if (orgTeam) {
      return {
        teamId: orgTeam.orgUnitId,
        teamName: orgTeam.name,
        signalRGroup: orgTeam.signalRGroup
      };
    }

    return null;
  }

  /**
   * Clear configuration cache (for admin operations)
   */
  clearCache() {
    this.cache = null;
    this.cacheExpiry = null;
  }

  /**
   * Get default configuration
   */
  getDefaultConfig() {
    return {
      version: '1.0',
      lastUpdated: new Date().toISOString(),
      defaultTeam: JSON.stringify(this.getDefaultTeam()),
      routingRules: JSON.stringify(this.getDefaultRoutingRules())
    };
  }

  /**
   * Get default team configuration
   */
  getDefaultTeam() {
    return {
      teamId: 'default-operations',
      teamName: 'Default Operations',
      signalRGroup: 'team-default',
      alertAdminOnUse: true
    };
  }

  /**
   * Get default routing rules
   */
  getDefaultRoutingRules() {
    return {
      evaluationOrder: ['explicit', 'event', 'organizational', 'default'],
      multiTeamRouting: {
        enabled: false,
        maxTeams: 1
      },
      inference: {
        enabled: true,
        dateBasedEvents: true,
        locationBasedRouting: true
      },
      fallback: {
        useDefaultTeam: true,
        alertAdministrator: true
      }
    };
  }

  /**
   * Get minimal configuration for emergency fallback
   */
  getMinimalConfig() {
    return {
      version: '1.0',
      lastUpdated: new Date().toISOString(),
      defaultTeam: this.getDefaultTeam(),
      eventTeams: [],
      organizationalTeams: [],
      routingRules: this.getDefaultRoutingRules()
    };
  }

  /**
   * Extract webhook URLs from teams array
   * @param {Array} teams - Array of team configuration objects
   * @returns {Array<string>} Array of webhook URLs
   */
  extractWebhookUrls(teams) {
    if (!teams || !Array.isArray(teams)) {
      return [];
    }
    
    return teams
      .filter(team => team.webhookUrl) // Only teams with webhook URLs
      .map(team => team.webhookUrl);
  }
}

// Export singleton instance
module.exports = new RoutingService();
