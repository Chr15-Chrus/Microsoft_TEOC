const { DefaultAzureCredential } = require('@azure/identity');
const { SecretClient } = require('@azure/keyvault-secrets');

const KEYVAULT_REFERENCE_REGEX = /^@microsoft.keyvault\(/i;
const SECRET_URI_CAPTURE_REGEX = /SecretUri\s*=\s*([^\s)]+)/i;
const secretCache = new Map();
const secretPromises = new Map();
const clientCache = new Map();

let credential;

function getKeyVaultUri() {
    const uri = process.env.KEY_VAULT_URI || process.env.KEY_VAULT_URL || '';
    return uri ? uri.replace(/\/?$/, '/') : '';
}

function ensureClient(vaultUri) {
    const targetVault = (vaultUri || getKeyVaultUri() || '').replace(/\/?$/, '/');
    if (!targetVault) {
        throw new Error('KEY_VAULT_URI environment variable is not configured. Set KEY_VAULT_URI to your vault URL.');
    }

    const cacheKey = targetVault.toLowerCase();
    if (clientCache.has(cacheKey)) {
        console.log(`[secretProvider] Using cached Key Vault client for: ${targetVault}`);
        return clientCache.get(cacheKey);
    }

    console.log(`[secretProvider] Creating new Key Vault client for: ${targetVault}`);
    credential = credential || new DefaultAzureCredential();
    const client = new SecretClient(targetVault, credential);
    clientCache.set(cacheKey, client);
    return client;
}

function deriveSecretName(envName = '') {
    return envName.toLowerCase().replace(/[^a-z0-9-]/g, '-');
}

function buildSecretCacheKey(vaultUri, secretName, version) {
    return `${(vaultUri || '').toLowerCase()}|${secretName.toLowerCase()}|${version || ''}`;
}

async function fetchSecretFromVault(secretName, options = {}) {
    const vaultUri = options.vaultUri || getKeyVaultUri();
    if (!vaultUri) {
        throw new Error('Key Vault URI is not configured. Set KEY_VAULT_URI or use an app setting Key Vault reference.');
    }
    const version = options.version;
    const cacheKey = buildSecretCacheKey(vaultUri, secretName, version);

    console.log(`[secretProvider] fetchSecretFromVault: secretName='${secretName}', vaultUri='${vaultUri}', version='${version || 'latest'}'`);

    if (secretCache.has(cacheKey)) {
        console.log(`[secretProvider] Returning cached secret for key: ${cacheKey}`);
        return secretCache.get(cacheKey);
    }
    if (secretPromises.has(cacheKey)) {
        console.log(`[secretProvider] Returning in-flight promise for key: ${cacheKey}`);
        return secretPromises.get(cacheKey);
    }

    const client = ensureClient(vaultUri);
    const promise = client.getSecret(secretName, version ? { version } : undefined)
        .then(secret => {
            console.log(`[secretProvider] ✓ Successfully fetched secret '${secretName}' from vault`);
            secretCache.set(cacheKey, secret.value);
            secretPromises.delete(cacheKey);
            return secret.value;
        })
        .catch(error => {
            console.error(`[secretProvider] ✗ Failed to fetch secret '${secretName}' from vault:`, error.message);
            secretPromises.delete(cacheKey);
            throw error;
        });

    secretPromises.set(cacheKey, promise);
    return promise;
}

function parseKeyVaultReference(rawValue) {
    if (!rawValue || !KEYVAULT_REFERENCE_REGEX.test(rawValue)) {
        return null;
    }
    const match = rawValue.match(SECRET_URI_CAPTURE_REGEX);
    if (!match) {
        return null;
    }
    const secretUri = match[1].replace(/['"]/g, '');
    try {
        const url = new URL(secretUri);
        const parts = url.pathname.split('/').filter(Boolean);
        if (!parts.length || parts[0].toLowerCase() !== 'secrets') {
            return null;
        }
        const secretName = decodeURIComponent(parts[1] || '');
        if (!secretName) {
            return null;
        }
        const secretVersion = parts[2] ? decodeURIComponent(parts[2]) : undefined;
        return {
            vaultUri: `${url.origin}/`,
            secretName,
            secretVersion
        };
    } catch (err) {
        return null;
    }
}

/**
 * Resolves a configuration value by checking environment variables first, then falling back to Key Vault.
 * 
 * Resolution order:
 * 1. Check if env var exists:
 *    a. If it's a plain value (not a Key Vault reference) → return it
 *    b. If it's an unresolved Key Vault reference → Azure automatic resolution failed, try manual fetch
 * 2. If no env var and KEY_VAULT_URI is set → directly fetch from Key Vault using derived secret name
 * 3. If all attempts fail and optional=false → throw error
 * 
 * @param {string|string[]} envNames - Primary environment variable name or array of names to try.
 * @param {object} options
 * @param {string} [options.secretName] - Explicit secret name in Key Vault.
 * @param {Record<string,string>} [options.secretNames] - Map of env name to secret name overrides.
 * @param {boolean} [options.optional=false] - When true, return undefined instead of throwing if not found.
 * @returns {Promise<string|undefined>}
 */
async function getSecretValue(envNames, options = {}) {
    const names = Array.isArray(envNames) ? envNames : [envNames];
    const secretNameOverrides = options.secretNames || {};

    console.log(`[secretProvider] getSecretValue called for: ${names.join(', ')}, optional: ${!!options.optional}`);

    // Check if KEY_VAULT_URI is configured upfront for fallback
    const vaultUri = getKeyVaultUri();
    if (vaultUri) {
        console.log(`[secretProvider] KEY_VAULT_URI configured: ${vaultUri}`);
    }

    for (const name of names) {
        if (!name) {
            continue;
        }

        // Check if environment variable exists
        const rawValue = process.env[name];
        console.log(`[secretProvider] Checking env var '${name}': ${rawValue ? 'EXISTS' : 'NOT FOUND'} (length: ${rawValue ? rawValue.length : 0})`);
        
        if (rawValue) {
            // Check if it's an unresolved Key Vault reference
            // This happens when Azure's automatic resolution fails
            if (KEYVAULT_REFERENCE_REGEX.test(rawValue)) {
                console.log(`[secretProvider] ⚠️ Env var '${name}' contains unresolved Key Vault reference`);
                console.log(`[secretProvider] Azure automatic resolution failed. Attempting manual fetch...`);
                
                // Try to parse the reference and fetch manually
                const reference = parseKeyVaultReference(rawValue);
                if (reference) {
                    console.log(`[secretProvider] Parsed reference: vault=${reference.vaultUri}, secret=${reference.secretName}, version=${reference.secretVersion || 'latest'}`);
                    try {
                        const secretValue = await fetchSecretFromVault(reference.secretName, {
                            vaultUri: reference.vaultUri,
                            version: reference.secretVersion
                        });
                        if (secretValue) {
                            console.log(`[secretProvider] ✓ Successfully fetched secret '${reference.secretName}' via manual resolution`);
                            // Cache the resolved value in process.env for subsequent calls
                            process.env[name] = secretValue;
                            return secretValue;
                        }
                    } catch (error) {
                        const statusCode = error.statusCode || error.code;
                        console.error(`[secretProvider] ✗ Manual fetch failed for '${reference.secretName}':`, error.message, `(status: ${statusCode})`);
                        
                        // If manual fetch fails and this is not optional, we should try the next env name
                        // or fall through to direct Key Vault lookup
                        if (!options.optional && statusCode !== 404) {
                            throw new Error(`Failed to resolve Key Vault reference for ${name}: ${error.message}. Check managed identity permissions.`);
                        }
                    }
                } else {
                    console.warn(`[secretProvider] Failed to parse Key Vault reference format for '${name}'`);
                }
                
                // If we couldn't resolve the reference, fall through to try direct Key Vault lookup
            } else {
                // Plain text value - Azure resolved it successfully OR it's a local dev value
                console.log(`[secretProvider] ✓ Returning resolved value for '${name}' (length: ${rawValue.length})`);
                return rawValue;
            }
        }

        // Fallback: Attempt direct Key Vault lookup using derived secret name
        if (!vaultUri) {
            console.log(`[secretProvider] No KEY_VAULT_URI configured, cannot attempt direct Key Vault lookup for '${name}'`);
            continue;
        }

        // Derive the secret name from the environment variable name
        // e.g., MAPBOX_API_KEY → mapbox-api-key
        const secretName = secretNameOverrides[name] || options.secretName || deriveSecretName(name);
        console.log(`[secretProvider] Attempting direct Key Vault lookup: secret='${secretName}' for env var='${name}'`);
        
        try {
            const secretValue = await fetchSecretFromVault(secretName, { vaultUri });
            if (secretValue) {
                console.log(`[secretProvider] ✓ Successfully retrieved secret '${secretName}' from Key Vault (direct lookup)`);
                // Cache the value in process.env for subsequent calls
                process.env[name] = secretValue;
                return secretValue;
            }
        } catch (error) {
            const statusCode = error.statusCode || error.code;
            console.error(`[secretProvider] ✗ Direct Key Vault lookup failed for '${secretName}':`, error.message, `(status: ${statusCode})`);
            
            if (statusCode === 404) {
                console.log(`[secretProvider] Secret '${secretName}' not found in vault (404), trying next env name...`);
                continue;
            }
            
            if (options.optional) {
                console.log(`[secretProvider] Error ignored because optional=true`);
                continue;
            }
            
            throw new Error(`Failed to retrieve secret '${secretName}' for ${name}: ${error.message}`);
        }
    }

    console.warn(`[secretProvider] ✗ No value found for any of: ${names.join(', ')}`);
    
    if (options.optional) {
        console.log(`[secretProvider] Returning undefined (optional=true)`);
        return undefined;
    }

    const errorMsg = vaultUri 
        ? `Configuration value not found for environment variables: ${names.join(', ')}. Ensure secrets exist in Key Vault or app settings are configured with Key Vault references.`
        : `Configuration value not found for environment variables: ${names.join(', ')}. Set KEY_VAULT_URI or configure app settings with values/Key Vault references.`;
    
    throw new Error(errorMsg);
}

module.exports = {
    getSecretValue
};
