/**
 * Adaptive Card Templates
 * Generates standardized adaptive card JSON for TEOC events
 * Used by both server-side (Teams integration) and client-side (web UI notification cards)
 */

/**
 * Creates an adaptive card for a TEOC event/item
 * @param {Object} eventData - Event data in CloudEvents format or legacy format
 * @param {Object} options - Optional configuration
 * @param {string} options.functionBaseUrl - Base URL for action callbacks (for Teams)
 * @param {boolean} options.includeActions - Whether to include action buttons (default: true)
 * @param {boolean} options.compact - Use compact layout (default: false)
 * @returns {Object} Adaptive card JSON
 */
function createEventNotificationCard(eventData, options = {}) {
    const {
        functionBaseUrl = '',
        includeActions = true,
        compact = false
    } = options;

    // Handle CloudEvents format - extract data from .data property
    const itemData = eventData.data || eventData;
    
    // Extract event details with safe defaults
    const title = itemData.title || itemData.Title || 'Untitled Item';
    const description = itemData.description || itemData.additionalInfo || itemData.MoreInformation || '';
    const eventType = itemData.eventType || itemData.EventCausedDamage || 'Unknown';
    const priority = itemData.priority || itemData.Priority || 'Medium';
    const status = itemData.status || itemData.Status || 'New';
    const location = itemData.location || {};
    const itemId = itemData.itemId || itemData.ID || itemData.id || eventData.subject?.split('/').pop();
    const sourceType = itemData.sourceType || eventData.source?.split('://')[0] || 'unknown';
    
    // Determine priority color
    const priorityColor = (priority === 'High' || itemData.ImmediateNeedsRequired === true) ? 'Attention' : 
                          priority === 'Medium' ? 'Warning' : 'Good';

    // Format location string
    let locationString = 'Location not specified';
    let coordinates = null;
    
    if (location.coordinates) {
        coordinates = location.coordinates;
        locationString = location.displayName || 
                        (location.address ? 
                            [location.address.city, location.address.state, location.address.country]
                                .filter(x => x).join(', ') : 
                            `${coordinates.lat.toFixed(6)}, ${coordinates.lon.toFixed(6)}`);
    } else if (location.displayName) {
        locationString = location.displayName;
    }

    // Build card body
    const cardBody = [];

    if (!compact) {
        // Full header with priority indicator
        cardBody.push({
            type: "Container",
            style: "emphasis",
            items: [
                {
                    type: "ColumnSet",
                    columns: [
                        {
                            type: "Column",
                            width: "stretch",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: "🔔 New TEOC Event",
                                    weight: "Bolder",
                                    size: "Large",
                                    color: priorityColor
                                }
                            ]
                        },
                        {
                            type: "Column",
                            width: "auto",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: `${priority} Priority`,
                                    weight: "Bolder",
                                    color: priorityColor,
                                    horizontalAlignment: "Right"
                                }
                            ]
                        }
                    ]
                }
            ]
        });
    }

    // Title (always included)
    cardBody.push({
        type: "TextBlock",
        text: title,
        weight: "Bolder",
        size: compact ? "Medium" : "Large",
        wrap: true,
        spacing: compact ? "Small" : "Medium"
    });

    // Description (if provided and not compact)
    if (description && !compact) {
        cardBody.push({
            type: "TextBlock",
            text: description,
            wrap: true,
            spacing: "Small",
            isSubtle: true,
            maxLines: 3
        });
    }

    // Location section
    if (coordinates || locationString !== 'Location not specified') {
        cardBody.push({
            type: "Container",
            spacing: "Medium",
            separator: !compact,
            items: [
                {
                    type: "ColumnSet",
                    columns: [
                        {
                            type: "Column",
                            width: "auto",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: "📍",
                                    size: "Large"
                                }
                            ]
                        },
                        {
                            type: "Column",
                            width: "stretch",
                            items: [
                                {
                                    type: "TextBlock",
                                    text: locationString,
                                    wrap: true,
                                    weight: "Bolder"
                                },
                                ...(coordinates ? [{
                                    type: "TextBlock",
                                    text: `${coordinates.lat.toFixed(6)}, ${coordinates.lon.toFixed(6)}`,
                                    size: "Small",
                                    isSubtle: true,
                                    spacing: "Small"
                                }] : [])
                            ]
                        }
                    ]
                }
            ]
        });
    }

    // Event details (compact fact set)
    if (!compact) {
        const facts = [
            { title: "Event Type:", value: eventType },
            { title: "Status:", value: status }
        ];

        if (itemData.contactName || itemData.ContactName || itemData.Contact_x0020_Name) {
            facts.push({
                title: "Contact:",
                value: itemData.contactName || itemData.ContactName || itemData.Contact_x0020_Name
            });
        }

        cardBody.push({
            type: "Container",
            spacing: "Medium",
            separator: true,
            items: [
                {
                    type: "FactSet",
                    facts: facts
                }
            ]
        });
    }

    // Build actions array
    const actions = [];
    
    if (includeActions) {
        // Show Location action (client-side will handle this)
        if (coordinates) {
            actions.push({
                type: "Action.Submit",
                title: "📍 Show Location",
                data: {
                    action: "showLocation",
                    itemId: itemId,
                    coordinates: coordinates
                }
            });
        }

        // Dismiss action
        actions.push({
            type: "Action.Submit",
            title: "✖ Dismiss",
            data: {
                action: "dismiss",
                itemId: itemId
            }
        });

        // For Teams, add additional actions with URLs
        if (functionBaseUrl) {
            actions.push({
                type: "Action.OpenUrl",
                title: "📋 View Details",
                url: `${functionBaseUrl}/web/?itemId=${itemId}`
            });
        }
    }

    // Return complete adaptive card
    return {
        type: "AdaptiveCard",
        version: "1.4",
        $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
        body: cardBody,
        actions: actions
    };
}

/**
 * Creates a Teams-specific wrapper for the adaptive card
 * @param {Object} cardJson - Adaptive card JSON
 * @returns {Object} Teams message format with adaptive card attachment
 */
function wrapCardForTeams(cardJson) {
    return {
        type: "message",
        attachments: [
            {
                contentType: "application/vnd.microsoft.card.adaptive",
                contentUrl: null,
                content: cardJson
            }
        ]
    };
}

// Export for use in both Node.js (server) and browser (client)
if (typeof module !== 'undefined' && module.exports) {
    // Node.js environment
    module.exports = {
        createEventNotificationCard,
        wrapCardForTeams
    };
} else {
    // Browser environment
    window.AdaptiveCardTemplates = {
        createEventNotificationCard,
        wrapCardForTeams
    };
}
