/**
 * Microsoft Graph Authentication using MSAL with Delegated Permissions
 * 
 * This module handles:
 * - Loading MSAL token cache from Azure Blob Storage
 * - Acquiring tokens silently using cached account
 * - Persisting refreshed cache back to Blob Storage
 * 
 * Pre-requisites:
 * - One-time interactive login completed
 * - msal_cache.json exists in Azure Blob Storage
 * - Delegated permissions (ChannelMessage.Send) granted
 * - Environment variables configured:
 *   - ENTRA_CLIENT_ID
 *   - ENTRA_TENANT_ID
 *   - MSAL_CACHE_BLOB_CONTAINER
 *   - MSAL_CACHE_BLOB_NAME
 *   - AzureWebJobsStorage
 */

const { BlobServiceClient } = require('@azure/storage-blob');
const { PublicClientApplication } = require('@azure/msal-node');
const { resolveStorageConnectionString } = require('./data-sources');

// Cache the token in memory to avoid repeated blob reads
let tokenCache = {
    token: null,
    expiresOn: null
};

/**
 * Load MSAL cache from Azure Blob Storage
 * @returns {Promise<string|null>} Cache data as JSON string or null if not found
 */
async function loadMsalCacheFromBlob() {
    try {
        console.log('Loading MSAL cache from Azure Blob Storage');
        
        const connectionString = await resolveStorageConnectionString();
        if (!connectionString) {
            throw new Error('Azure Storage connection string not configured');
        }

        const containerName = process.env.MSAL_CACHE_BLOB_CONTAINER || 'msal-cache';
        const blobName = process.env.MSAL_CACHE_BLOB_NAME || 'msal_cache.json';

        const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
        const containerClient = blobServiceClient.getContainerClient(containerName);
        const blobClient = containerClient.getBlobClient(blobName);

        // Check if blob exists
        const exists = await blobClient.exists();
        if (!exists) {
            console.warn(`MSAL cache blob not found: ${containerName}/${blobName}`);
            return null;
        }

        // Download blob content
        const downloadResponse = await blobClient.download(0);
        const cacheData = await streamToString(downloadResponse.readableStreamBody);
        
        console.log('MSAL cache loaded successfully from blob storage');
        return cacheData;
    } catch (error) {
        console.error('Error loading MSAL cache from blob:', error.message);
        if (error.stack) {
            console.error('Stack trace:', error.stack);
        }
        throw error;
    }
}

/**
 * Save MSAL cache to Azure Blob Storage
 * @param {string} cacheData - Cache data as JSON string
 */
async function saveMsalCacheToBlob(cacheData) {
    try {
        console.log('Persisting MSAL cache to Azure Blob Storage');
        
        const connectionString = await resolveStorageConnectionString();
        if (!connectionString) {
            throw new Error('Azure Storage connection string not configured');
        }

        const containerName = process.env.MSAL_CACHE_BLOB_CONTAINER || 'msal-cache';
        const blobName = process.env.MSAL_CACHE_BLOB_NAME || 'msal_cache.json';

        const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
        const containerClient = blobServiceClient.getContainerClient(containerName);
        const blobClient = containerClient.getBlockBlobClient(blobName);

        // Upload cache data
        await blobClient.upload(cacheData, cacheData.length, {
            blobHTTPHeaders: { blobContentType: 'application/json' }
        });
        
        console.log('Token refreshed and persisted to blob storage');
    } catch (error) {
        console.error('Error saving MSAL cache to blob:', error.message);
        if (error.stack) {
            console.error('Stack trace:', error.stack);
        }
        // Don't throw - this is a non-critical failure
    }
}

/**
 * Helper function to convert stream to string
 * @param {Stream} readableStream - Readable stream
 * @returns {Promise<string>} Stream content as string
 */
async function streamToString(readableStream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        readableStream.on('data', (data) => {
            chunks.push(data.toString());
        });
        readableStream.on('end', () => {
            resolve(chunks.join(''));
        });
        readableStream.on('error', reject);
    });
}

/**
 * Get Microsoft Graph access token using delegated permissions
 * Uses PublicClientApplication with cached account for silent token acquisition
 * 
 * @returns {Promise<string>} Access token for Microsoft Graph API
 * @throws {Error} If token acquisition fails
 */
async function getGraphAccessToken() {
    try {
        // Check memory cache first
        if (tokenCache.token && tokenCache.expiresOn) {
            const now = new Date();
            const expiresOn = new Date(tokenCache.expiresOn);
            // Use cached token if it has at least 5 minutes left
            if (expiresOn.getTime() - now.getTime() > 5 * 60 * 1000) {
                console.log('Using cached Graph access token from memory');
                return tokenCache.token;
            }
        }

        // Validate environment variables
        const clientId = process.env.ENTRA_CLIENT_ID;
        const tenantId = process.env.ENTRA_TENANT_ID;
        
        if (!clientId) {
            throw new Error('ENTRA_CLIENT_ID environment variable not configured');
        }
        if (!tenantId) {
            throw new Error('ENTRA_TENANT_ID environment variable not configured');
        }

        // Load cache from blob storage
        const cacheData = await loadMsalCacheFromBlob();
        if (!cacheData) {
            throw new Error('MSAL cache not found. Please complete one-time interactive login first.');
        }

        // Configure MSAL with cache plugin
        const cachePlugin = {
            beforeCacheAccess: async (cacheContext) => {
                cacheContext.tokenCache.deserialize(cacheData);
            },
            afterCacheAccess: async (cacheContext) => {
                if (cacheContext.cacheHasChanged) {
                    const serializedCache = cacheContext.tokenCache.serialize();
                    await saveMsalCacheToBlob(serializedCache);
                }
            }
        };

        const msalConfig = {
            auth: {
                clientId: clientId,
                authority: `https://login.microsoftonline.com/${tenantId}`
            },
            cache: {
                cachePlugin
            }
        };

        const pca = new PublicClientApplication(msalConfig);
        
        // Get cached accounts (cache is loaded via plugin in beforeCacheAccess)
        const accounts = await pca.getTokenCache().getAllAccounts();
        
        if (!accounts || accounts.length === 0) {
            throw new Error('No cached accounts found. Please complete interactive login first.');
        }

        // Use the first account (assumes single-user scenario)
        const account = accounts[0];
        console.log(`Using cached account: ${account.username}`);

        // Acquire token silently
        const tokenRequest = {
            account: account,
            scopes: ['ChannelMessage.Send']
        };

        const response = await pca.acquireTokenSilent(tokenRequest);
        
        if (!response || !response.accessToken) {
            throw new Error('Failed to acquire access token silently');
        }

        console.log('Token acquired silently for Microsoft Graph');
        console.log('Graph Token acquired for user:', account.username);
        console.log('Scopes requested', tokenRequest.scopes);
        console.log('Token expires on', response.expiresOn);
        
        // Cache in memory
        tokenCache.token = response.accessToken;
        tokenCache.expiresOn = response.expiresOn;
        
        return response.accessToken;
        
    } catch (error) {
        console.error('Error acquiring Graph access token:', error.message);
        if (error.stack) {
            console.error('Stack trace:', error.stack);
        }
        
        // Provide helpful error messages
        if (error.errorCode === 'interaction_required') {
            throw new Error('Interactive login required. Token cache may be expired. Please re-authenticate.');
        }
        
        throw error;
    }
}

module.exports = {
    getGraphAccessToken,
    loadMsalCacheFromBlob,
    saveMsalCacheToBlob
};
