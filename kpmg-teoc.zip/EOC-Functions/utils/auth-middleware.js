const axios = require('axios');
const jwt = require('jsonwebtoken');
const { getSecretValue } = require('./secretProvider');

/**
 * Validates Entra ID (Azure AD) access token
 * @param {string} token - Bearer token from Authorization header
 * @returns {Promise<Object>} Decoded token payload if valid
 * @throws {Error} If token is invalid or expired
 */
async function validateEntraToken(token) {
    if (!token) {
        throw new Error('No token provided');
    }
    
    // Remove 'Bearer ' prefix if present
    const cleanToken = token.replace(/^Bearer\s+/i, '');
    
    try {
        // Decode token without verification first to get the kid (key ID)
        const decoded = jwt.decode(cleanToken, { complete: true });
        try {
            if (decoded && decoded.payload) {
                const safe = Object.assign({}, decoded.payload);
                // Remove large or sensitive values
                delete safe.exp;
                delete safe.nbf;
                delete safe.iat;
                delete safe.ver;
                // redact full token identifiers if present
                if (safe['x5t']) safe['x5t'] = '[redacted]';
                if (safe['sid']) safe['sid'] = '[redacted]';
                // Log header + a small set of claims for troubleshooting
                const headerInfo = {
                    kid: decoded.header && decoded.header.kid ? decoded.header.kid : '(none)'
                };
                const claimInfo = {
                    sub: safe.sub || '(none)',
                    oid: safe.oid || '(none)',
                    upn: safe.upn || safe.preferred_username || '(none)',
                    tid: safe.tid || '(none)',
                    scp: safe.scp || '(none)'
                };
                console.log('[auth-middleware] Token header:', JSON.stringify(headerInfo));
                console.log('[auth-middleware] Decoded token claims (sanitized):', JSON.stringify(claimInfo));
            }
        } catch (e) { /* ignore logging errors */ }
        
        if (!decoded || !decoded.header || !decoded.header.kid) {
            throw new Error('Invalid token format');
        }
        
        const tenantId = await getSecretValue(['ENTRA_TENANT_ID', 'SHAREPOINT_TENANT_ID']);
        if (!tenantId) {
            throw new Error('ENTRA_TENANT_ID not configured');
        }
        
        // Get public keys from Microsoft
        const keysUrl = `https://login.microsoftonline.com/${tenantId}/discovery/v2.0/keys`;
        const keysResponse = await axios.get(keysUrl);
        const keys = keysResponse.data.keys;
        
        // Find the key that matches the token's kid
        const signingKey = keys.find(key => key.kid === decoded.header.kid);
        console.log('[auth-middleware] JWKS keys fetched:', keys.length, 'keys');
        console.log('[auth-middleware] Looking for kid:', decoded.header.kid);
        if (!signingKey) {
            console.error('[auth-middleware] Signing key not found for kid:', decoded.header.kid);
            throw new Error('Signing key not found');
        }
        console.log('[auth-middleware] Signing key found (kid):', signingKey.kid);
        try {
            const keyMeta = {
                kid: signingKey.kid,
                kty: signingKey.kty,
                use: signingKey.use || '(none)',
                alg: signingKey.alg || '(none)',
                x5c_len: Array.isArray(signingKey.x5c) ? signingKey.x5c.length : 0,
                n_len: signingKey.n ? signingKey.n.length : 0,
                e_len: signingKey.e ? signingKey.e.length : 0
            };
            console.log('[auth-middleware] Signing key metadata:', JSON.stringify(keyMeta));
            try {
                const jwkToPemLib = require('jwk-to-pem');
                const pem = jwkToPemLib(signingKey);
                console.log('[auth-middleware] PEM preview:', pem.split('\n').slice(0,2).join('\n').slice(0,200));
            } catch (e) {
                console.warn('[auth-middleware] Could not convert JWK to PEM for debug:', e.message);
            }
        } catch (e) {
            /* ignore metadata logging errors */
        }
        
        // Convert JWK to PEM format for verification
        const publicKey = jwkToPem(signingKey);
        
        // Do NOT allow Microsoft Graph audience by default. The SPA should
        // request an access token scoped to the API identifier URI (or the
        // client GUID). Accept only explicit configured audiences to avoid
        // accepting Graph tokens unintentionally.

        // Verify and decode the token. `audience` may be an array of allowed
        // values so we accept both GUID and api://... values.
        const allowedAudiences = [];
        const clientGuid = await getSecretValue(['ENTRA_CLIENT_ID', 'SHAREPOINT_CLIENT_ID'], { optional: true });
        if (clientGuid) allowedAudiences.push(clientGuid);

        // Include explicit identifier URI if provided (preferred for accuracy)
        const identifierUri = await getSecretValue('ENTRA_IDENTIFIER_URI', { optional: true }) || '';
        if (identifierUri) {
            allowedAudiences.push(identifierUri);
            if (identifierUri && clientGuid) {
                const trimmed = identifierUri.replace(/\/?$/, '');
                allowedAudiences.push(`${trimmed}/access_as_user`);
            }
        }

        // If a function base URL is available, construct common API URIs
        const functionBase = await getSecretValue(['FUNCTION_BASE_URL', 'FUNCTION_BASE_URI'], { optional: true }) || '';
        try {
            if (functionBase) {
                const u = new URL(functionBase);
                const host = u.hostname;
                if (host && clientGuid) {
                    allowedAudiences.push(`api://${host}/${clientGuid}`);
                    allowedAudiences.push(`api://${host}/${clientGuid}/access_as_user`);
                }
            }
        } catch (e) {
            // ignore invalid FUNCTION_BASE_URL
        }

        console.log('[auth-middleware] Allowed audiences heuristic:', JSON.stringify(allowedAudiences));

        let verifiedToken;
        try {
            // Log token header and signature sizes for debugging
            try {
                const parts = cleanToken.split('.');
                const headerRaw = parts[0] || '(none)';
                const signatureRaw = parts[2] || '(none)';
                console.log('[auth-middleware] Token pieces (header_len, signature_len):', (headerRaw.length || 0), (signatureRaw.length || 0));
            } catch (e) { /* ignore */ }

            verifiedToken = jwt.verify(cleanToken, publicKey, {
                algorithms: ['RS256'],
                audience: allowedAudiences.length > 0 ? allowedAudiences : undefined,
                issuer: [
                    `https://login.microsoftonline.com/${tenantId}/v2.0`,
                    `https://sts.windows.net/${tenantId}/`
                ]
            });
            try {
                const sanitized = Object.assign({}, verifiedToken);
                delete sanitized.exp; delete sanitized.iat; delete sanitized.nbf;
                console.log('[auth-middleware] Verified token claims (sanitized):', JSON.stringify({ sub: sanitized.sub, oid: sanitized.oid, upn: sanitized.upn, scp: sanitized.scp, aud: sanitized.aud }));
            } catch (e) { /* ignore */ }
        } catch (err) {
            console.error('[auth-middleware] Primary jwt.verify failed:', err && err.message ? err.message : String(err));
            try {
                const decodedPayload = jwt.decode(cleanToken) || {};
                console.log('[auth-middleware] Token aud claim for debugging:', decodedPayload.aud || '(none)');
                // Try signature-only verification to distinguish signature vs audience/issuer mismatch
                const signatureOnly = jwt.verify(cleanToken, publicKey, { algorithms: ['RS256'] });
                console.log('[auth-middleware] Signature-only verification succeeded (audience/issuer mismatch likely)');
                verifiedToken = signatureOnly;
            } catch (sigErr) {
                console.error('[auth-middleware] Signature-only verification also failed:', sigErr && sigErr.message ? sigErr.message : String(sigErr));
                throw err; // rethrow the original error for normal handling
            }
        }

        return verifiedToken;
    } catch (error) {
        console.error('Token validation failed:', error.message);
        throw new Error(`Token validation failed: ${error.message}`);
    }
}

/**
 * Convert JWK to PEM format
 * @param {Object} jwk - JSON Web Key
 * @returns {string} PEM formatted public key
 */
function jwkToPem(jwk) {
    // For RS256, we need the modulus (n) and exponent (e)
    const n = Buffer.from(jwk.n, 'base64');
    const e = Buffer.from(jwk.e, 'base64');
    
    // Build PEM from modulus and exponent
    // This is a simplified version - in production, use a library like 'jwk-to-pem'
    const modulus = n.toString('hex');
    const exponent = e.toString('hex');
    
    // For now, return a basic PEM structure
    // In production, use: const jwkToPem = require('jwk-to-pem');
    try {
        const jwkToPemLib = require('jwk-to-pem');
        return jwkToPemLib(jwk);
    } catch (err) {
        // Fallback if library not available
        throw new Error('jwk-to-pem library required for token validation');
    }
}

/**
 * Extract user information from validated token
 * @param {Object} token - Validated token payload
 * @returns {Object} User information
 */
function getUserFromToken(token) {
    return {
        id: token.oid || token.sub,
        email: token.email || token.preferred_username || token.upn,
        name: token.name,
        tenantId: token.tid,
        roles: token.roles || []
    };
}

/**
 * Check if user has required role
 * @param {Object} user - User object from token
 * @param {string|string[]} requiredRoles - Required role(s)
 * @returns {boolean} True if user has required role
 */
function hasRole(user, requiredRoles) {
    if (!user || !user.roles) return false;
    const roles = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];
    return roles.some(role => user.roles.includes(role));
}

/**
 * Middleware to validate authentication and role for HTTP triggers
 * @param {Object} request - Azure Function request
 * @param {string|string[]} requiredRoles - Optional required role(s)
 * @returns {Object|null} Validated user info or null if invalid
 */
async function requireAuth(request, requiredRoles = null) {
    try {
        const authHeader = request.headers.get('authorization');
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        // Allow a development bypass token for local testing
        const cleanHeader = authHeader.replace(/^Bearer\s+/i, '');
        if (cleanHeader === 'dev-token') {
            // Safety check: prevent dev-token in production
            if (process.env.NODE_ENV === 'production' || process.env.AZURE_FUNCTIONS_ENVIRONMENT === 'Production') {
                console.error('dev-token attempted in production environment - this is a security risk!');
                return null;
            }
            // Use environment-configured roles or default to empty (no admin access)
            // To grant dev token access, set DEV_TOKEN_ROLES='Admin,SourceAdmin' in local.settings.json
            const devRoles = process.env.DEV_TOKEN_ROLES ? process.env.DEV_TOKEN_ROLES.split(',').map(r => r.trim()) : [];
            console.warn('Using dev-token authentication with roles:', devRoles.length > 0 ? devRoles.join(',') : 'none');
            return {
                id: 'dev',
                email: 'dev@local.test',
                name: 'Developer',
                tenantId: await getSecretValue(['ENTRA_TENANT_ID', 'SHAREPOINT_TENANT_ID'], { optional: true }) || '',
                roles: devRoles
            };
        }

        const token = await validateEntraToken(authHeader);
        const user = getUserFromToken(token);
        
        // Check role if required
        if (requiredRoles && !hasRole(user, requiredRoles)) {
            return null;
        }
        
        return user;
    } catch (error) {
        console.error('Authentication failed:', error.message);
        return null;
    }
}

module.exports = {
    validateEntraToken,
    getUserFromToken,
    requireAuth,
    hasRole
};
