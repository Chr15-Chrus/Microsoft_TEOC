const { TableClient } = require('@azure/data-tables');
const { getSecretValue } = require('./secretProvider');

const DATA_SOURCES_TABLE = 'DataSources';
const DEFAULT_SOURCE_ID = process.env.DEFAULT_SOURCE_ID || 'default-sharepoint';

async function resolveStorageConnectionString(options = {}) {
    const names = [
        'AZURE_STORAGE_CONNECTION_STRING',
        'AzureWebJobsStorage',
        'DEPLOYMENT_STORAGE_CONNECTION_STRING',
        'AZURE_STORAGE_CONNECTION_STRING_FALLBACK'
    ];
    const connectionString = await getSecretValue(names, { optional: options.optional ?? false });
    return connectionString || '';
}

function createTableClient(connectionString) {
    if (!connectionString) {
        throw new Error('Storage connection string not configured. Set AZURE_STORAGE_CONNECTION_STRING or AzureWebJobsStorage.');
    }
    return TableClient.fromConnectionString(connectionString, DATA_SOURCES_TABLE);
}

async function ensureTable(client, context) {
    try {
        await client.createTable();
        context?.log?.('DataSources table created');
    } catch (error) {
        if ((error.statusCode || error.status || error.code) === 409 || error.code === 'TableAlreadyExists') {
            return;
        }
        if (error.code === 'EntityAlreadyExists') {
            return;
        }
        throw error;
    }
}

async function getDataSourcesTableClient(context, options = {}) {
    const connectionString = await resolveStorageConnectionString();
    const client = createTableClient(connectionString);
    if (options.ensureTable !== false) {
        await ensureTable(client, context);
    }
    return client;
}

async function getSourceById(sourceId, context) {
    const client = await getDataSourcesTableClient(context);
    return client.getEntity('source', sourceId);
}

async function listSources(context, { includeInactive = false } = {}) {
    const client = await getDataSourcesTableClient(context);
    const filter = includeInactive ? `PartitionKey eq 'source'` : `PartitionKey eq 'source' and active eq true`;
    const entities = client.listEntities({ queryOptions: { filter } });
    const results = [];
    for await (const entity of entities) {
        results.push(entity);
    }
    return results;
}

async function findSourceByListId(listId, context) {
    if (!listId) return null;
    const client = await getDataSourcesTableClient(context);
    const escapedId = String(listId).replace(/'/g, "''");
    const filter = `PartitionKey eq 'source' and listId eq '${escapedId}'`;
    const iterator = client.listEntities({ queryOptions: { filter } });
    for await (const entity of iterator) {
        return entity;
    }
    return null;
}

module.exports = {
    DATA_SOURCES_TABLE,
    DEFAULT_SOURCE_ID,
    resolveStorageConnectionString,
    getDataSourcesTableClient,
    getSourceById,
    listSources,
    findSourceByListId
};
