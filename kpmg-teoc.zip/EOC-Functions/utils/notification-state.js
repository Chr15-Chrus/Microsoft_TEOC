/**
 * NotificationState Table Helper
 * Manages deduplication state for SharePoint webhook notifications
 * Prevents duplicate posts when multiple webhooks fire for the same item
 */

const { TableClient } = require('@azure/data-tables');
const { resolveStorageConnectionString } = require('./data-sources');

const NOTIFICATION_STATE_TABLE = 'NotificationState';

/**
 * Get NotificationState table client
 * @returns {Promise<TableClient>}
 */
async function getNotificationStateClient() {
    const connectionString = await resolveStorageConnectionString();
    if (!connectionString) {
        throw new Error('Storage connection string not configured');
    }
    
    const client = TableClient.fromConnectionString(connectionString, NOTIFICATION_STATE_TABLE);
    
    // Ensure table exists
    try {
        await client.createTable();
    } catch (error) {
        // Ignore if table already exists
        if (error.statusCode !== 409 && error.code !== 'TableAlreadyExists') {
            throw error;
        }
    }
    
    return client;
}

/**
 * Get last processed notification state for a source
 * @param {string} sourceId - DataSource ID
 * @param {Object} context - Function context for logging
 * @returns {Promise<Object|null>} Last processed state or null
 */
async function getLastProcessedState(sourceId, context) {
    try {
        const client = await getNotificationStateClient();
        const entity = await client.getEntity('source', sourceId);
        
        return {
            sourceId: entity.rowKey,
            lastProcessedItemId: entity.lastProcessedItemId,
            etag: entity.etag,
            itemEtag: entity.itemEtag,
            lastProcessedTime: entity.lastProcessedTime,
            lastModifiedTime: entity.timestamp
        };
    } catch (error) {
        if (error.statusCode === 404 || error.code === 'ResourceNotFound') {
            // No previous state
            context?.log?.(`No previous notification state for source: ${sourceId}`);
            return null;
        }
        context?.error?.('Error retrieving notification state:', error);
        throw error;
    }
}

/**
 * Update last processed notification state for a source
 * @param {string} sourceId - DataSource ID
 * @param {string} itemId - SharePoint item ID that was processed
 * @param {string} itemEtag - Item etag from SharePoint
 * @param {Object} context - Function context for logging
 * @returns {Promise<void>}
 */
async function updateLastProcessedState(sourceId, itemId, itemEtag, context) {
    try {
        const client = await getNotificationStateClient();
        
        const entity = {
            partitionKey: 'source',
            rowKey: sourceId,
            lastProcessedItemId: String(itemId),
            itemEtag: itemEtag || '',
            lastProcessedTime: new Date().toISOString()
        };
        
        // Use upsert to create or update
        await client.upsertEntity(entity, 'Replace');
        
        context?.log?.(`Updated notification state for source ${sourceId}: itemId=${itemId}, etag=${itemEtag}`);
    } catch (error) {
        context?.error?.('Error updating notification state:', error);
        throw error;
    }
}

/**
 * Check if an item has already been processed (deduplication)
 * @param {string} sourceId - DataSource ID
 * @param {string} itemId - SharePoint item ID to check
 * @param {string} itemEtag - Item etag from SharePoint
 * @param {Object} context - Function context for logging
 * @returns {Promise<boolean>} True if already processed, false if new
 */
async function isItemProcessed(sourceId, itemId, itemEtag, context) {
    const lastState = await getLastProcessedState(sourceId, context);
    
    if (!lastState) {
        // No previous state, item is new
        return false;
    }
    
    // Check if same item ID and etag
    const isDuplicate = 
        lastState.lastProcessedItemId === String(itemId) &&
        lastState.itemEtag === itemEtag;
    
    if (isDuplicate) {
        context?.log?.(
            `Duplicate notification detected for source ${sourceId}: ` +
            `itemId=${itemId}, etag=${itemEtag} (last processed: ${lastState.lastProcessedTime})`
        );
    }
    
    return isDuplicate;
}

/**
 * Clear notification state for a source (for testing/maintenance)
 * @param {string} sourceId - DataSource ID
 * @param {Object} context - Function context for logging
 * @returns {Promise<void>}
 */
async function clearNotificationState(sourceId, context) {
    try {
        const client = await getNotificationStateClient();
        await client.deleteEntity('source', sourceId);
        context?.log?.(`Cleared notification state for source: ${sourceId}`);
    } catch (error) {
        if (error.statusCode === 404 || error.code === 'ResourceNotFound') {
            // Already doesn't exist
            return;
        }
        context?.error?.('Error clearing notification state:', error);
        throw error;
    }
}

module.exports = {
    getNotificationStateClient,
    getLastProcessedState,
    updateLastProcessedState,
    isItemProcessed,
    clearNotificationState
};
