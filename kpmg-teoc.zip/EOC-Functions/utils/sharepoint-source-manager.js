const { TableClient } = require('@azure/data-tables');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { getDataSourcesTableClient, resolveStorageConnectionString } = require('./data-sources');
const { getSecretValue } = require('./secretProvider');

const GRAPH_BASE_URL = 'https://graph.microsoft.com/v1.0';
const GRAPH_SCOPE = 'https://graph.microsoft.com/.default';

async function getSharePointCredentialSet() {
    const tenantId = await getSecretValue(['SHAREPOINT_TENANT_ID', 'ENTRA_TENANT_ID']);
    const clientId = await getSecretValue(['SHAREPOINT_CLIENT_ID', 'ENTRA_CLIENT_ID']);
    const clientSecret = await getSecretValue(['SHAREPOINT_CLIENT_SECRET', 'ENTRA_CLIENT_SECRET']);
    return { tenantId, clientId, clientSecret };
}

function buildWebhookUrl() {
    const explicitBase = process.env.FUNCTION_BASE_URL;
    const hostname = process.env.WEBSITE_HOSTNAME;
    const base = explicitBase || (hostname ? `https://${hostname}` : null);
    if (!base) {
        throw new Error('FUNCTION_BASE_URL or WEBSITE_HOSTNAME must be set to register SharePoint webhooks');
    }
    const route = process.env.SHAREPOINT_WEBHOOK_ROUTE || '/webhookGateway';
    return `${base.replace(/\/?$/, '')}${route.startsWith('/') ? '' : '/'}${route}`;
}

async function getClientCredentialToken(scope) {
    const { tenantId, clientId, clientSecret } = await getSharePointCredentialSet();
    const body = new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        scope,
        grant_type: 'client_credentials'
    });
    const response = await fetch(`https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body
    });
    if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to acquire token (${scope}): ${error}`);
    }
    const json = await response.json();
    return json.access_token;
}

async function getGraphAccessToken() {
    return getClientCredentialToken(GRAPH_SCOPE);
}

function normalizePathSegments(pathname = '') {
    const trimmed = pathname.replace(/\/+/g, '/').replace(/^\/|\/$/g, '');
    if (!trimmed) return '';
    return trimmed
        .split('/')
        .filter(Boolean)
        .map(segment => encodeURIComponent(segment))
        .join('/');
}

function normalizeServerRelativeUrl(value) {
    if (!value) return null;
    let candidate = value;
    try {
        if (value.startsWith('http')) {
            const url = new URL(value);
            candidate = url.pathname;
        }
    } catch (err) {
        candidate = value;
    }
    candidate = candidate.replace(/\/+/g, '/').replace(/\/index\.aspx$/i, '');
    candidate = candidate.replace(/^\/*/, '/').replace(/\/*$/, '');
    return candidate.toLowerCase();
}

function deriveListName(listUrl) {
    if (!listUrl) return null;
    try {
        let segments;
        if (listUrl.startsWith('http')) {
            const u = new URL(listUrl);
            segments = u.pathname.split('/').filter(Boolean);
        } else {
            segments = listUrl.split('/').filter(Boolean);
        }
        const listsIndex = segments.findIndex(p => p.toLowerCase() === 'lists');
        if (listsIndex !== -1 && segments.length > listsIndex + 1) {
            return decodeURIComponent(segments[listsIndex + 1]).replace(/\.aspx$/i, '');
        }
        return decodeURIComponent(segments[segments.length - 1] || '').replace(/\.aspx$/i, '');
    } catch (err) {
        return listUrl;
    }
}

async function callGraph(endpoint, accessToken, options = {}, context, label = 'Graph request') {
    const {
        method = 'GET',
        body,
        headers = {},
        allowNotFound = false
    } = options;

    const payload = typeof body === 'string' || body === undefined ? body : JSON.stringify(body);
    const response = await fetch(endpoint, {
        method,
        headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
            ...(payload ? { 'Content-Type': 'application/json' } : {}),
            ...headers
        },
        body: payload
    });

    if (response.status === 404 && allowNotFound) {
        return response;
    }

    if (response.status === 403) {
        const text = await response.text();
        throw new Error(`${label} denied (403). Ensure the TEOC Operations app has Sites.Selected access to the target site. Response: ${text}`);
    }

    if (!response.ok) {
        const text = await response.text();
        throw new Error(`${label} failed (${response.status}): ${text}`);
    }

    return response;
}

async function resolveGraphSite(siteUrl, accessToken, context) {
    const parsed = new URL(siteUrl);
    const encodedPath = normalizePathSegments(parsed.pathname);
    const pathSegment = encodedPath ? `:/${encodedPath}` : '';
    const endpoint = `${GRAPH_BASE_URL}/sites/${parsed.host}${pathSegment}?$select=id,displayName,webUrl`;
    context?.log?.(`Resolving SharePoint site via Graph: ${endpoint}`);
    const response = await callGraph(endpoint, accessToken, {}, context, 'Resolve SharePoint site');
    return await response.json();
}

async function fetchListById(siteGraphId, listId, accessToken, context) {
    if (!listId) return null;
    const endpoint = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(siteGraphId)}/lists/${listId}?$select=id,displayName,webUrl`;
    const response = await callGraph(endpoint, accessToken, { allowNotFound: true }, context, 'Fetch list by id');
    if (response.status === 404) {
        return null;
    }
    return await response.json();
}

async function findListByDisplayName(siteGraphId, listName, accessToken, context) {
    if (!listName) return null;
    const safeName = listName.replace(/'/g, "''");
    const params = new URLSearchParams({
        '$filter': `displayName eq '${safeName}'`,
        '$select': 'id,displayName,webUrl'
    });
    const endpoint = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(siteGraphId)}/lists?${params.toString()}`;
    const response = await callGraph(endpoint, accessToken, {}, context, `Find list '${listName}'`);
    const data = await response.json();
    return Array.isArray(data.value) && data.value.length > 0 ? data.value[0] : null;
}

async function findListByUrl(siteGraphId, listUrl, accessToken, context) {
    const normalizedTarget = normalizeServerRelativeUrl(listUrl);
    if (!normalizedTarget) return null;

    let nextLink = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(siteGraphId)}/lists?$select=id,displayName,webUrl&$top=200`;
    while (nextLink) {
        const response = await callGraph(nextLink, accessToken, {}, context, 'Enumerate site lists');
        const data = await response.json();
        const match = Array.isArray(data.value)
            ? data.value.find(item => normalizeServerRelativeUrl(item.webUrl) === normalizedTarget)
            : null;
        if (match) {
            return match;
        }
        nextLink = data['@odata.nextLink'] || null;
    }

    return null;
}

async function resolveSharePointListMetadata({ siteUrl, listUrl, listId }, context) {
    if (!siteUrl) {
        throw new Error('siteUrl is required to resolve SharePoint list metadata');
    }

    const accessToken = await getGraphAccessToken();
    const siteInfo = await resolveGraphSite(siteUrl, accessToken, context);

    let targetList = await fetchListById(siteInfo.id, listId, accessToken, context);
    if (!targetList) {
        const derivedName = deriveListName(listUrl);
        targetList = await findListByDisplayName(siteInfo.id, derivedName, accessToken, context);
    }
    if (!targetList && listUrl) {
        targetList = await findListByUrl(siteInfo.id, listUrl, accessToken, context);
    }

    if (!targetList) {
        throw new Error(`Unable to locate SharePoint list (${listUrl || listId || 'unspecified'}) on site ${siteUrl}. Ensure the list exists and the TEOC Operations app has access to this site.`);
    }

    return {
        listId: targetList.id,
        listName: targetList.displayName,
        listWebUrl: targetList.webUrl,
        siteGraphId: siteInfo.id,
        siteWebUrl: siteInfo.webUrl
    };
}

async function fetchSharePointListId(siteUrl, listUrl, context) {
    const metadata = await resolveSharePointListMetadata({ siteUrl, listUrl }, context);
    return metadata.listId;
}

async function registerSharePointWebhook({ siteUrl, siteGraphId, listId, sourceId }, context) {
    if (!listId) {
        throw new Error('Cannot register webhook without listId');
    }

    const accessToken = await getGraphAccessToken();
    let resolvedSiteGraphId = siteGraphId;
    if (!resolvedSiteGraphId) {
        if (!siteUrl) {
            throw new Error('siteUrl is required when siteGraphId is not provided');
        }
        const siteInfo = await resolveGraphSite(siteUrl, accessToken, context);
        resolvedSiteGraphId = siteInfo.id;
    }

    const webhookUrl = buildWebhookUrl();
    const ttlMinutes = parseInt(process.env.SHAREPOINT_WEBHOOK_TTL_MINUTES || '', 10);
    const lifetimeMinutes = Number.isFinite(ttlMinutes) && ttlMinutes >= 60 && ttlMinutes <= 4320 ? ttlMinutes : 60 * 24 * 2;
    const expirationDate = new Date(Date.now() + lifetimeMinutes * 60 * 1000);
    const clientState = crypto.randomUUID();

    const endpoint = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(resolvedSiteGraphId)}/lists/${listId}/subscriptions`;
    const response = await callGraph(
        endpoint,
        accessToken,
        {
            method: 'POST',
            body: {
                changeType: 'updated',
                notificationUrl: webhookUrl,
                expirationDateTime: expirationDate.toISOString(),
                clientState
            }
        },
        context,
        'Register SharePoint webhook'
    );

    const subscription = await response.json();
    await storeWebhookClientState(sourceId, clientState);

    return {
        id: subscription.id,
        url: webhookUrl,
        clientState,
        expirationDateTime: subscription.expirationDateTime,
        siteGraphId: resolvedSiteGraphId
    };
}

async function unregisterSharePointWebhook({ siteUrl, siteGraphId, listId, webhookId }, context) {
    if (!listId || !webhookId) {
        throw new Error('listId and webhookId are required to unregister a SharePoint webhook');
    }

    const accessToken = await getGraphAccessToken();
    let resolvedSiteGraphId = siteGraphId;
    if (!resolvedSiteGraphId) {
        if (!siteUrl) {
            throw new Error('siteUrl is required when siteGraphId is not provided');
        }
        const siteInfo = await resolveGraphSite(siteUrl, accessToken, context);
        resolvedSiteGraphId = siteInfo.id;
    }

    const endpoint = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(resolvedSiteGraphId)}/lists/${listId}/subscriptions/${webhookId}`;
    const response = await fetch(endpoint, {
        method: 'DELETE',
        headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json'
        }
    });

    if (response.status === 404) {
        context?.log?.(`Webhook ${webhookId} already removed (404)`);
        return;
    }

    if (response.status === 403) {
        const text = await response.text();
        throw new Error(`Unregister SharePoint webhook denied (403): ${text}`);
    }

    if (!response.ok) {
        const text = await response.text();
        throw new Error(`Failed to unregister SharePoint webhook: ${text}`);
    }
}

async function storeWebhookClientState(sourceId, clientState) {
    const connectionString = await resolveStorageConnectionString();
    if (!connectionString) {
        throw new Error('Storage connection string not configured');
    }
    const tableClient = TableClient.fromConnectionString(connectionString, 'WebhookSecrets');
    await tableClient.createTable().catch(() => {});
    let createdDate;
    try {
        const existing = await tableClient.getEntity('webhook', sourceId);
        createdDate = existing.createdDate;
    } catch (err) {
        // If not found, set createdDate to now
        createdDate = new Date().toISOString();
    }
    await tableClient.upsertEntity({
        partitionKey: 'webhook',
        rowKey: sourceId,
        clientState,
        createdDate,
        modifiedDate: new Date().toISOString()
    }, 'Merge');
}


/**
 * Update/renew an existing SharePoint webhook subscription
 * Uses PATCH to extend expiration of existing subscription
 */
async function updateSharePointWebhook({ siteGraphId, listId, webhookId, sourceId }, context) {
    if (!listId || !webhookId) {
        throw new Error('Cannot update webhook without listId and webhookId');
    }

    const accessToken = await getGraphAccessToken();
    
    const ttlMinutes = parseInt(process.env.SHAREPOINT_WEBHOOK_TTL_MINUTES || '', 10);
    const lifetimeMinutes = Number.isFinite(ttlMinutes) && ttlMinutes >= 60 && ttlMinutes <= 4320 ? ttlMinutes : 60 * 24 * 2;
    const newExpirationDate = new Date(Date.now() + lifetimeMinutes * 60 * 1000);

    const endpoint = `${GRAPH_BASE_URL}/sites/${encodeURIComponent(siteGraphId)}/lists/${listId}/subscriptions/${webhookId}`;
    
    try {
        const response = await callGraph(
            endpoint,
            accessToken,
            {
                method: 'PATCH',
                body: {
                    expirationDateTime: newExpirationDate.toISOString()
                }
            },
            context,
            'Update SharePoint webhook'
        );

        const subscription = await response.json();
        
        return {
            id: subscription.id,
            expirationDateTime: subscription.expirationDateTime,
            siteGraphId
        };
    } catch (error) {
        context.warn(`PATCH update failed for webhook ${webhookId}: ${error.message}`);
        // If PATCH fails (e.g., webhook expired or deleted), fall back to creating new one
        context.log('Falling back to creating a new webhook subscription');
        throw error; // Let caller handle fallback
    }
}

async function createSharePointSource({
    sourceId,
    name,
    description = '',
    siteUrl,
    listUrl,
    listId,
    autoConfigure = true
}, context) {
    if (!siteUrl) {
        throw new Error('siteUrl is required to register a SharePoint source');
    }

    const listMetadata = await resolveSharePointListMetadata({ siteUrl, listUrl, listId }, context);

    const tableClient = await getDataSourcesTableClient(context);
    const newSource = {
        partitionKey: 'source',
        rowKey: sourceId || crypto.randomUUID(),
        type: 'sharepoint',
        name,
        description,
        siteUrl,
        listUrl,
        listWebUrl: listMetadata.listWebUrl,
        siteGraphId: listMetadata.siteGraphId,
        listId: listMetadata.listId,
        active: true,
        createdDate: new Date().toISOString(),
        modifiedDate: new Date().toISOString()
    };

    let webhookInfo = null;
    if (autoConfigure) {
        webhookInfo = await registerSharePointWebhook({
            siteUrl,
            siteGraphId: listMetadata.siteGraphId,
            listId: listMetadata.listId,
            sourceId: newSource.rowKey
        }, context);
        newSource.webhookId = webhookInfo.id;
        newSource.webhookUrl = webhookInfo.url;
        newSource.webhookExpiration = webhookInfo.expirationDateTime;
        newSource.siteGraphId = newSource.siteGraphId || webhookInfo.siteGraphId;
    }

    await tableClient.upsertEntity(newSource, 'Replace');
    context?.log?.(`SharePoint source '${newSource.rowKey}' configured.`);
    return { source: newSource, webhook: webhookInfo };
}

module.exports = {
    createSharePointSource,
    registerSharePointWebhook,
    updateSharePointWebhook,  // ADD THIS
    unregisterSharePointWebhook,
    resolveSharePointListMetadata,
    fetchSharePointListId,
    storeWebhookClientState
};
