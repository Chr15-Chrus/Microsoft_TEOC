// Event mapping service - maps events from different sources to common TEOC format
const { v4: uuidv4 } = require('uuid');

/**
 * Maps SharePoint list item to common TEOC event format
 * @param {Object} sharePointItem - SharePoint list item data
 * @param {string} listId - SharePoint list GUID
 * @param {string} siteUrl - SharePoint site URL
 * @returns {Object} - TEOC event in CloudEvents format
 */
function mapSharePointToCommonFormat(sharePointItem, listId, siteUrl) {
  const now = new Date().toISOString();
  
  return {
    // CloudEvents standard fields
    id: uuidv4(),
    source: `sharepoint://${new URL(siteUrl).host}/lists/${listId}`,
    specversion: '1.0',
    type: sharePointItem.isNew ? 'TEOC.Item.Created' : 'TEOC.Item.Updated',
    datacontenttype: 'application/json',
    time: sharePointItem.Modified || now,
    subject: `/items/${sharePointItem.ID || sharePointItem.Id}`,
    
    // TEOC event data
    data: {
      // Core identification
      itemId: String(sharePointItem.ID || sharePointItem.Id),
      sourceType: 'sharepoint',
      sourceListId: listId,
      
      // Content
      title: sharePointItem.Title || '',
      description: sharePointItem.Description || '',
      additionalInfo: sharePointItem.AdditionalInfo || sharePointItem.Notes,
      
      // Location
      location: parseLocation(sharePointItem),
      
      // Classification
      eventType: sharePointItem.EventType || sharePointItem.Category || 'Unknown',
      eventSubType: sharePointItem.SubType,
      priority: mapPriority(sharePointItem.Priority),
      severity: sharePointItem.Severity,
      
      // Assignment
      assignedTo: sharePointItem.AssignedTo?.Title || sharePointItem.AssignedTo,
      assignedTeam: sharePointItem.Team,
      assignedOrgUnit: sharePointItem.OrgUnit,
      targetTeamId: sharePointItem.TargetTeam,
      
      // Status
      status: sharePointItem.Status || 'Active',
      state: mapState(sharePointItem.Status),
      acknowledged: sharePointItem.Acknowledged === true || sharePointItem.Acknowledged === 'Yes',
      acknowledgedBy: sharePointItem.AcknowledgedBy?.Title || sharePointItem.AcknowledgedBy,
      acknowledgedAt: sharePointItem.AcknowledgedDate,
      
      // Contact
      contactName: sharePointItem.ContactName,
      contactEmail: sharePointItem.ContactEmail,
      contactPhone: sharePointItem.ContactPhone,
      
      // Timestamps
      createdDate: sharePointItem.Created || now,
      modifiedDate: sharePointItem.Modified || now,
      resolvedDate: sharePointItem.ResolvedDate,
      
      // Metadata
      metadata: {
        eventContext: sharePointItem.EventContext,
        tags: parseArray(sharePointItem.Tags),
        customFields: extractCustomFields(sharePointItem)
      }
    }
  };
}

/**
 * Maps Dynamics 365 incident/entity to common TEOC event format
 * @param {Object} dynamicsEntity - Dynamics entity data
 * @param {string} entityType - Entity type (incidents, events, jobs)
 * @returns {Object} - TEOC event in CloudEvents format
 */
function mapDynamicsToCommonFormat(dynamicsEntity, entityType = 'incidents') {
  const now = new Date().toISOString();
  const entityId = dynamicsEntity.incidentid || dynamicsEntity.id;
  
  return {
    // CloudEvents standard fields
    id: uuidv4(),
    source: `dynamics://${process.env.DYNAMICS_INSTANCE_URL}/${entityType}`,
    specversion: '1.0',
    type: dynamicsEntity.isNew ? 'TEOC.Item.Created' : 'TEOC.Item.Updated',
    datacontenttype: 'application/json',
    time: dynamicsEntity.modifiedon || now,
    subject: `/${entityType}/${entityId}`,
    
    // TEOC event data
    data: {
      // Core identification
      itemId: entityId,
      sourceType: 'dynamics',
      sourceListId: entityType,
      
      // Content
      title: dynamicsEntity.title || dynamicsEntity.name || '',
      description: dynamicsEntity.description || '',
      additionalInfo: dynamicsEntity.notes,
      
      // Location
      location: parseDynamicsLocation(dynamicsEntity),
      
      // Classification
      eventType: mapDynamicsCategory(dynamicsEntity.categorycode),
      eventSubType: mapDynamicsSubCategory(dynamicsEntity.subcategorycode),
      priority: mapDynamicsPriority(dynamicsEntity.prioritycode),
      severity: dynamicsEntity.severitycode,
      
      // Assignment
      assignedTo: dynamicsEntity.ownerid_name || dynamicsEntity._ownerid_value,
      assignedTeam: dynamicsEntity.owningteam_name,
      assignedOrgUnit: dynamicsEntity.owningbusinessunit_name,
      targetTeamId: dynamicsEntity.targetteamid,
      
      // Status
      status: mapDynamicsStatus(dynamicsEntity.statuscode),
      state: mapDynamicsState(dynamicsEntity.statecode),
      acknowledged: dynamicsEntity.acknowledged === true,
      acknowledgedBy: dynamicsEntity.acknowledgedby_name,
      acknowledgedAt: dynamicsEntity.acknowledgedon,
      
      // Contact
      contactName: dynamicsEntity.customerid_name,
      contactEmail: dynamicsEntity.emailaddress,
      contactPhone: dynamicsEntity.telephone1,
      
      // Timestamps
      createdDate: dynamicsEntity.createdon || now,
      modifiedDate: dynamicsEntity.modifiedon || now,
      resolvedDate: dynamicsEntity.resolvedon,
      
      // Metadata
      metadata: {
        eventContext: dynamicsEntity.eventcontext,
        tags: parseArray(dynamicsEntity.tags),
        customFields: extractDynamicsCustomFields(dynamicsEntity)
      }
    }
  };
}

/**
 * Parse location from SharePoint item
 */
function parseLocation(item) {
  const location = {};
  
  // Try different location field formats
  if (item.Location) {
    if (typeof item.Location === 'string') {
      location.address = item.Location;
    } else if (item.Location.Address) {
      location.address = item.Location.Address;
      location.city = item.Location.City;
      location.state = item.Location.State;
    }
  }
  
  // City and state
  if (item.City) location.city = item.City;
  if (item.State) location.state = item.State;
  if (item.Country) location.country = item.Country;
  
  // Coordinates
  if (item.Latitude && item.Longitude) {
    location.coordinates = {
      lat: parseFloat(item.Latitude),
      lon: parseFloat(item.Longitude)
    };
  } else if (item.GeoLocation) {
    // SharePoint geolocation field
    location.coordinates = {
      lat: item.GeoLocation.Latitude,
      lon: item.GeoLocation.Longitude
    };
  }
  
  return Object.keys(location).length > 0 ? location : undefined;
}

/**
 * Parse location from Dynamics entity
 */
function parseDynamicsLocation(entity) {
  const location = {};
  
  // Address fields
  if (entity.address1_composite) {
    location.address = entity.address1_composite;
  } else if (entity.address1_line1) {
    location.address = entity.address1_line1;
  }
  
  if (entity.address1_city) location.city = entity.address1_city;
  if (entity.address1_stateorprovince) location.state = entity.address1_stateorprovince;
  if (entity.address1_country) location.country = entity.address1_country;
  
  // Coordinates
  if (entity.address1_latitude && entity.address1_longitude) {
    location.coordinates = {
      lat: parseFloat(entity.address1_latitude),
      lon: parseFloat(entity.address1_longitude)
    };
  }
  
  return Object.keys(location).length > 0 ? location : undefined;
}

/**
 * Map priority values to standard format
 */
function mapPriority(priority) {
  if (!priority) return 'medium';
  
  const p = String(priority).toLowerCase();
  if (p.includes('critical') || p === '1' || p === 'urgent') return 'critical';
  if (p.includes('high') || p === '2') return 'high';
  if (p.includes('low') || p === '4' || p === '5') return 'low';
  return 'medium';
}

/**
 * Map status to state
 */
function mapState(status) {
  if (!status) return 'active';
  
  const s = String(status).toLowerCase();
  if (s.includes('resolved') || s.includes('completed') || s.includes('closed')) {
    return 'resolved';
  }
  if (s.includes('cancel')) {
    return 'cancelled';
  }
  return 'active';
}

/**
 * Map Dynamics priority code to standard format
 */
function mapDynamicsPriority(code) {
  const priorityMap = {
    1: 'critical',
    2: 'high',
    3: 'medium',
    4: 'low',
    5: 'low'
  };
  return priorityMap[code] || 'medium';
}

/**
 * Map Dynamics category code to event type
 * 
 * IMPORTANT: Customize these mappings based on your Dynamics 365 configuration
 * To find your category codes:
 * 1. In Dynamics, go to Settings → Customizations → Customize the System
 * 2. Expand Entities → Incident → Fields → Category
 * 3. View the option set values
 * 4. Update the mapping below with your specific codes
 * 
 * Alternative: Query via Web API:
 *   GET /api/data/v9.2/EntityDefinitions(LogicalName='incident')/Attributes(LogicalName='categorycode')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?$select=LogicalName&$expand=OptionSet
 */
function mapDynamicsCategory(code) {
  // Default mapping - CUSTOMIZE BASED ON YOUR DYNAMICS CONFIGURATION
  const categoryMap = {
    1: 'Infrastructure',
    2: 'Crowd Management',
    3: 'Public Safety',
    4: 'Medical Emergency',
    5: 'Security Incident',
    6: 'Maintenance',
    7: 'Traffic Management'
  };
  return categoryMap[code] || 'Unknown';
}

/**
 * Map Dynamics sub-category code
 * 
 * IMPORTANT: Customize based on your Dynamics 365 configuration
 * Follow same process as mapDynamicsCategory above but for subcategorycode field
 */
function mapDynamicsSubCategory(code) {
  // Customize based on your configuration
  return code ? `SubType-${code}` : undefined;
}

/**
 * Map Dynamics status code to readable status
 */
function mapDynamicsStatus(code) {
  const statusMap = {
    1: 'Active',
    2: 'In Progress',
    3: 'Waiting',
    4: 'Resolved',
    5: 'Cancelled'
  };
  return statusMap[code] || 'Active';
}

/**
 * Map Dynamics state code to standard state
 */
function mapDynamicsState(code) {
  const stateMap = {
    0: 'active',
    1: 'resolved',
    2: 'cancelled'
  };
  return stateMap[code] || 'active';
}

/**
 * Parse array field (comma-separated or actual array)
 */
function parseArray(value) {
  if (!value) return undefined;
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    return value.split(',').map(s => s.trim()).filter(s => s);
  }
  return undefined;
}

/**
 * Extract custom fields that aren't standard
 */
function extractCustomFields(item) {
  const standardFields = [
    'ID', 'Id', 'Title', 'Description', 'AdditionalInfo', 'Notes',
    'Location', 'City', 'State', 'Country', 'Latitude', 'Longitude', 'GeoLocation',
    'EventType', 'Category', 'SubType', 'Priority', 'Severity',
    'AssignedTo', 'Team', 'OrgUnit', 'TargetTeam',
    'Status', 'Acknowledged', 'AcknowledgedBy', 'AcknowledgedDate',
    'ContactName', 'ContactEmail', 'ContactPhone',
    'Created', 'Modified', 'ResolvedDate', 'EventContext', 'Tags',
    // SharePoint metadata fields
    'Author', 'Editor', 'ContentType', 'FileSystemObjectType', 'ServerRedirectedEmbedUrl'
  ];
  
  const customFields = {};
  for (const [key, value] of Object.entries(item)) {
    if (!standardFields.includes(key) && value !== null && value !== undefined) {
      customFields[key] = value;
    }
  }
  
  return Object.keys(customFields).length > 0 ? customFields : undefined;
}

/**
 * Extract Dynamics custom fields
 */
function extractDynamicsCustomFields(entity) {
  const standardFields = [
    'incidentid', 'id', 'title', 'name', 'description', 'notes',
    'address1_composite', 'address1_line1', 'address1_city', 'address1_stateorprovince',
    'address1_country', 'address1_latitude', 'address1_longitude',
    'categorycode', 'subcategorycode', 'prioritycode', 'severitycode',
    'ownerid', '_ownerid_value', 'ownerid_name', 'owningteam', 'owningteam_name',
    'owningbusinessunit', 'owningbusinessunit_name', 'targetteamid',
    'statuscode', 'statecode', 'acknowledged', 'acknowledgedby_name', 'acknowledgedon',
    'customerid', 'customerid_name', 'emailaddress', 'telephone1',
    'createdon', 'modifiedon', 'resolvedon', 'eventcontext', 'tags'
  ];
  
  const customFields = {};
  for (const [key, value] of Object.entries(entity)) {
    if (!standardFields.includes(key) && 
        !key.startsWith('@') && 
        !key.endsWith('_name') && 
        !key.endsWith('_value') &&
        value !== null && 
        value !== undefined) {
      customFields[key] = value;
    }
  }
  
  return Object.keys(customFields).length > 0 ? customFields : undefined;
}

/**
 * Validate TEOC event format
 */
function validateEvent(event) {
  const errors = [];
  
  // Check required CloudEvents fields
  if (!event.id) errors.push('Missing required field: id');
  if (!event.source) errors.push('Missing required field: source');
  if (!event.type) errors.push('Missing required field: type');
  if (!event.time) errors.push('Missing required field: time');
  
  // Check required data fields
  if (!event.data) {
    errors.push('Missing required field: data');
  } else {
    if (!event.data.itemId) errors.push('Missing required field: data.itemId');
    if (!event.data.title) errors.push('Missing required field: data.title');
    if (!event.data.eventType) errors.push('Missing required field: data.eventType');
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

module.exports = {
  mapSharePointToCommonFormat,
  mapDynamicsToCommonFormat,
  validateEvent
};
