/**
 * Utility functions for handling geographic coordinates
 */

/**
 * Validate and parse coordinates from item data
 * @param {Object} itemData - Item data containing latitude and longitude
 * @returns {Object|null} Validated coordinates { lat, lng } or null if invalid
 */
function validateAndParseCoordinates(itemData) {
    // Check if coordinates are provided
    if (itemData.latitude === null || itemData.latitude === undefined ||
        itemData.longitude === null || itemData.longitude === undefined) {
        return null;
    }
    
    // Convert to numbers and validate
    const lat = Number(itemData.latitude);
    const lng = Number(itemData.longitude);
    
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        return null;
    }
    
    return { lat, lng };
}

/**
 * Format coordinates for SharePoint Location field
 * @param {number} lat - Latitude
 * @param {number} lng - Longitude
 * @returns {Object} SharePoint-compatible Location object with capitalized field names
 */
function formatLocationForSharePoint(lat, lng) {
    // SharePoint Location field is a complex object that often contains a Coordinates property
    // Use the Coordinates container to match stored Location objects seen in the list
    return {
        Coordinates: {
            Latitude: lat,
            Longitude: lng
        }
    };
}

module.exports = {
    validateAndParseCoordinates,
    formatLocationForSharePoint
};
