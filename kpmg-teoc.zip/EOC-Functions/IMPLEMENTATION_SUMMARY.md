# SharePoint Webhook Pipeline Implementation Summary

## Overview

This implementation provides a complete end-to-end pipeline for processing SharePoint webhook notifications without relying on Azure Event Grid at runtime. The pipeline fetches SharePoint list items via Microsoft Graph API, normalizes them, applies routing rules, and broadcasts to SignalR groups and Teams channels.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      SharePoint List Changes                        │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   SharePoint Webhook Notification                   │
│                    (POST to webhookGateway)                         │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      webhookGateway Function                        │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ 1. Validate clientState from WebhookSecrets table           │  │
│  │ 2. Resolve DataSource from DataSources table by listId      │  │
│  │ 3. Check source is active                                   │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│              processSharePointChange (per notification)             │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ 1. Get Graph API access token                               │  │
│  │ 2. Fetch most recent item (orderby: lastModifiedDateTime)   │  │
│  │ 3. Check NotificationState table for deduplication          │  │
│  │ 4. Normalize SharePoint fields to eventData format          │  │
│  │ 5. Update NotificationState with itemId + etag              │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    routingService.determineRoutes                   │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ 1. Check for explicit routing (targetTeamId)                │  │
│  │ 2. Evaluate active event teams (date range, geography)      │  │
│  │ 3. Evaluate organizational teams (geography, event type)    │  │
│  │ 4. Apply multi-team routing rules                           │  │
│  │ 5. Fallback to default team if no routes found              │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         broadcastEvent                              │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ SignalR Broadcast:                                           │  │
│  │  1. Get DefaultAzureCredential token                         │  │
│  │  2. POST to SignalR groups for each route                    │  │
│  │  3. Track success/failure per group                          │  │
│  │                                                               │  │
│  │ Teams Webhook Posting:                                       │  │
│  │  1. Collect unique webhook URLs (source + routes)            │  │
│  │  2. Generate adaptive card with coordinates                  │  │
│  │  3. POST to each Teams webhook                               │  │
│  │  4. Track success/failure per webhook                        │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                 Web Dashboard + Teams Notifications                 │
└─────────────────────────────────────────────────────────────────────┘
```

## Key Components

### 1. NotificationState Table Helper (`utils/notification-state.js`)

**Purpose**: Prevent duplicate processing when multiple webhooks fire for the same change.

**Functions**:
- `getLastProcessedState(sourceId)` - Retrieve last processed item state
- `updateLastProcessedState(sourceId, itemId, etag)` - Update after processing
- `isItemProcessed(sourceId, itemId, etag)` - Check for duplicates
- `clearNotificationState(sourceId)` - Clear state (maintenance)

**Table Schema**:
```
NotificationState Table
├─ PartitionKey: "source"
├─ RowKey: sourceId (from DataSources)
├─ lastProcessedItemId: SharePoint item ID
├─ itemEtag: Item's etag from SharePoint
├─ lastProcessedTime: ISO timestamp
└─ timestamp: Table timestamp
```

### 2. SharePoint Change Processor (`utils/sharepoint-change-processor.js`)

**Purpose**: Fetch SharePoint items via Graph API and normalize to eventData format.

**Key Functions**:
- `processSharePointChange(source, notification, context)` - Main processor
- `fetchMostRecentItem(siteGraphId, listId, token, context)` - Graph API query
- `normalizeSharePointItem(item, source)` - Field mapping
- `parseLocation(fields)` - Location with coordinates extraction
- `parseCoordinates(locationData)` - Coordinate helper

**Field Mapping**:
```javascript
SharePoint Field        → eventData Field
─────────────────────────────────────────
Title                   → title
Description/MoreInfo    → description
ID                      → itemId
Severity/ImmediateNeeds → priority/severity
Location (JSON)         → location { displayName, address, coordinates }
EventType/Category      → eventType
Status                  → status
ContactName             → contactName
ContactEmail            → contactEmail
ContactPhone            → contactPhone
```

**Location Parsing**:
Handles multiple formats:
- JSON string with DisplayName, Address, Coordinates
- Individual fields (City, State, Latitude, Longitude)
- Returns: `{ displayName, address: {...}, coordinates: { lat, lon } }`

### 3. Enhanced webhookGateway (`functions/webhookGateway.js`)

**Purpose**: Receive webhooks, orchestrate processing, and broadcast results.

**Flow**:
1. **Validation** - Handle SharePoint validation requests
2. **Parse** - Extract notifications from payload
3. **Per-Notification Processing**:
   - Validate clientState
   - Resolve DataSource
   - Check active status
   - Call processSharePointChange
   - Determine routes
   - Broadcast event
4. **Response** - Return 200 quickly with summary

**Error Handling**:
- Per-notification error handling (single failure doesn't fail batch)
- Structured error logging with context
- Graceful fallback if SignalR token fails
- Continue to Teams posting even if SignalR fails

### 4. Routing Integration

**Uses**: Existing `utils/routing-service.js`

**Routing Logic**:
1. Explicit assignment (targetTeamId)
2. Event teams (date range, geography, triggers)
3. Organizational teams (geography, responsibilities)
4. Default team (fallback)

**Returns**: Array of routes with:
```javascript
{
  teamId: "event-123",
  teamName: "Hurricane Response",
  signalRGroup: "event-hurricane",
  teamsWebhooks: ["https://..."],
  reason: "event:hurricane-2024",
  priority: 90
}
```

### 5. SignalR Broadcasting

**Implementation**: Similar to existing `eventHandler.js`

**Process**:
1. Get Azure AD token (DefaultAzureCredential)
2. For each route, POST to SignalR group:
   ```
   POST {signalRBase}/api/v1/hubs/{hubName}/groups/{groupName}/:send
   Headers: Authorization: Bearer {token}
   Body: { target: "newItem", arguments: [eventData] }
   ```
3. Track success/failure per group

### 6. Teams Webhook Posting

**Implementation**: Similar to existing `eventHandler.js`

**Process**:
1. Collect unique webhook URLs:
   - Source default webhook (`source.teamsWebhookUrl`)
   - Route-based webhooks (`route.teamsWebhooks[]`)
2. Generate adaptive card:
   ```javascript
   createEventNotificationCard(eventData, {
     functionBaseUrl: process.env.FUNCTION_BASE_URL,
     includeActions: true,
     compact: false
   })
   ```
3. Wrap for Teams: `wrapCardForTeams(cardJson)`
4. POST to each webhook
5. Track success/failure per webhook

## Configuration Requirements

### DataSources Table
```javascript
{
  partitionKey: "source",
  rowKey: "emergency-reports",
  name: "Emergency Reports",
  type: "sharepoint",
  active: true,
  listId: "abc-123-def-456",
  siteUrl: "https://contoso.sharepoint.com/sites/emergency",
  siteGraphId: "contoso.sharepoint.com,site-id,web-id",
  teamsWebhookUrl: "https://outlook.office.com/webhook/..." // optional
}
```

### WebhookSecrets Table
```javascript
{
  partitionKey: "webhook",
  rowKey: "emergency-reports",  // matches DataSource.rowKey
  clientState: "your-secret-client-state"
}
```

### Environment Variables
```
# Storage
AZURE_STORAGE_CONNECTION_STRING=...

# Graph API / SharePoint
SHAREPOINT_TENANT_ID=...
SHAREPOINT_CLIENT_ID=...
SHAREPOINT_CLIENT_SECRET=...

# SignalR (optional)
SIGNALR_REST_BASE_URL=https://your-signalr.service.signalr.net
SIGNALR_HUB_NAME=teocHub

# Function URL (for cards)
FUNCTION_BASE_URL=https://your-function-app.azurewebsites.net
```

## Testing

### Local Testing
1. Start Azure Functions locally:
   ```bash
   cd EOC-Functions
   npm install
   func start
   ```

2. Run test script:
   ```bash
   # PowerShell
   ./test-webhook.ps1 -ClientState "your-secret" -ListId "your-guid"
   
   # Bash
   export CLIENT_STATE="your-secret"
   export LIST_ID="your-guid"
   ./test-webhook.sh
   ```

3. Check logs for:
   - Notification validation
   - Item fetched from SharePoint
   - Deduplication check
   - Routing results
   - SignalR broadcast results
   - Teams posting results

### Expected Logs
```
SharePoint webhook notification received
Valid notification for source: emergency-reports (Emergency Reports)
Processing SharePoint change for source: emergency-reports
Fetched item 123 (modified: 2026-01-13T05:00:00Z)
Normalized eventData: itemId=123, title=Power Outage, hasCoordinates=true
Routing determined: routes=2
Broadcast summary: signalR={successful: 2, failed: 0}, teams={successful: 3, failed: 0}
```

## Deduplication Strategy

**Problem**: SharePoint can send multiple webhook notifications for a single change.

**Solution**: Track last processed item per source in NotificationState table.

**Implementation**:
1. After fetching item, check: `isItemProcessed(sourceId, itemId, etag)`
2. If duplicate (same itemId + etag), skip processing
3. If new, process and update: `updateLastProcessedState(sourceId, itemId, etag)`

**Benefits**:
- Prevents duplicate Teams posts
- Prevents duplicate SignalR broadcasts
- Based on etag, so only actual changes trigger processing

## Monitoring & Observability

### Structured Logging
All key operations log structured data:

```javascript
// Notification received
{ sourceId, sourceName, listId, subscriptionId }

// Item fetched
{ itemId, modified, etag }

// Routing determined
{ itemId, routeCount, routes: [{ teamId, teamName, reason }] }

// Broadcast results
{
  itemId,
  signalR: { total, successful, failed },
  teams: { total, successful, failed }
}

// Errors
{
  error, stack,
  sourceId, sourceName,
  listId, subscriptionId
}
```

### Key Metrics to Monitor
- Webhook notifications received per source
- Processing time per notification
- Deduplication hit rate
- SignalR broadcast success rate
- Teams posting success rate
- Error rate per source

## Error Handling

### Per-Notification Error Isolation
Each notification is processed independently. If one fails, others continue.

### Graceful Degradation
- If SignalR token fails, continue to Teams posting
- If one Teams webhook fails, continue to others
- If routing fails, continue processing other notifications

### Error Context
All errors include full context for debugging:
```javascript
{
  error: error.message,
  stack: error.stack,
  sourceId: "emergency-reports",
  sourceName: "Emergency Reports",
  listId: "abc-123",
  subscriptionId: "sub-456"
}
```

## Comparison with Event Grid Approach

### Previous (Event Grid):
```
webhookGateway → Event Grid → eventHandler → Routing/Broadcasting
```
**Drawbacks**:
- Additional Azure service dependency
- Additional latency
- Separate monitoring required
- More complex debugging

### Current (Direct):
```
webhookGateway → Processing → Routing/Broadcasting
```
**Benefits**:
- Single Azure Function
- Lower latency
- Simpler debugging
- Less infrastructure
- Lower cost

### Legacy Compatibility
Event Grid functions remain available:
- `publishEvent.js` - For manual event publishing
- `eventHandler.js` - For Event Grid-triggered workflows
- Can coexist with new pipeline

## Security Considerations

### Authentication
- **Graph API**: Uses client credentials (app-only) with Sites.Read.All permission
- **SignalR**: Uses DefaultAzureCredential (managed identity or local development)
- **Webhook Validation**: Validates clientState from WebhookSecrets table

### Secrets Management
- All secrets stored in Azure Key Vault or Azure Storage Table
- Local secrets in `local.settings.json` (gitignored)
- No secrets in code or configuration files

### Access Control
- Webhook endpoint is anonymous but validates clientState
- DataSource must be marked active for processing
- Source must exist in DataSources table

## Performance Considerations

### Graph API Rate Limits
- Query limited to top 1 item
- Uses efficient orderby clause
- Consider caching access tokens (handled by library)

### Concurrent Processing
- Multiple notifications processed in parallel within single invocation
- Each notification isolated with try-catch
- Batch response returned quickly (HTTP 200)

### Deduplication Performance
- Single table lookup per notification
- Indexed by partitionKey + rowKey
- Fast comparison (itemId + etag)

## Future Enhancements

### Potential Improvements
1. **Batch Graph Queries** - Fetch multiple items if webhook indicates batch change
2. **Delta Queries** - Use Graph delta queries for more efficient change detection
3. **Priority Queue** - Process high-priority items first
4. **Retry Logic** - Automatic retry for failed broadcasts
5. **Metrics Dashboard** - Real-time monitoring of pipeline health
6. **Alert Rules** - Azure Monitor alerts for high error rates

### Scalability
- Current implementation handles per-notification processing
- Can scale horizontally (multiple function instances)
- NotificationState table handles concurrent updates
- Consider adding queue for very high volume scenarios

## Troubleshooting Guide

See `WEBHOOK_TESTING.md` for comprehensive troubleshooting:
- Client state mismatch
- Source not found
- Graph API errors
- Routing issues
- SignalR failures
- Teams webhook failures

## Files Reference

### New Files
- `utils/notification-state.js` - Deduplication helper
- `utils/sharepoint-change-processor.js` - Change processor
- `test-webhook.ps1` - PowerShell test script
- `test-webhook.sh` - Bash test script
- `WEBHOOK_TESTING.md` - Testing guide
- `local.settings.json.example` - Config template
- `IMPLEMENTATION_SUMMARY.md` - This file

### Modified Files
- `functions/webhookGateway.js` - Integrated pipeline

### Unchanged Files
- `functions/postAssessmentCard.js` - Legacy function
- `functions/publishEvent.js` - Legacy function
- `functions/eventHandler.js` - Legacy function
- `functions/renewWebhooks.js` - Timer function
- `functions/getItems.js` - Data retrieval
- All map UI and client files

## Conclusion

This implementation provides a robust, scalable, and maintainable pipeline for processing SharePoint webhook notifications. It eliminates the Event Grid dependency while maintaining backward compatibility with legacy functions. The comprehensive error handling, structured logging, and deduplication ensure reliable operation in production.
