#!/bin/bash
# Test script for simulating SharePoint webhook notifications
# This script sends a test webhook payload to the webhookGateway function

# Default values
FUNCTION_URL="${FUNCTION_URL:-http://localhost:7071/api/webhookGateway}"
SUBSCRIPTION_ID="${SUBSCRIPTION_ID:-test-subscription-id}"
CLIENT_STATE="${CLIENT_STATE:-test-client-state}"
LIST_ID="${LIST_ID:-your-list-guid-here}"
SITE_URL="${SITE_URL:-https://your-tenant.sharepoint.com/sites/yoursite}"

echo "SharePoint Webhook Test Script"
echo "================================"
echo ""

# Construct webhook notification payload
PAYLOAD=$(cat <<EOF
{
  "value": [
    {
      "subscriptionId": "${SUBSCRIPTION_ID}",
      "clientState": "${CLIENT_STATE}",
      "expirationDateTime": "$(date -u -d '+7 days' '+%Y-%m-%dT%H:%M:%S.000Z' 2>/dev/null || date -u -v+7d '+%Y-%m-%dT%H:%M:%S.000Z')",
      "resource": "web/lists(guid'${LIST_ID}')",
      "tenantId": "your-tenant-id",
      "siteUrl": "${SITE_URL}",
      "webId": "your-web-id"
    }
  ]
}
EOF
)

echo "Payload:"
echo "$PAYLOAD" | jq '.' 2>/dev/null || echo "$PAYLOAD"
echo ""

echo "Sending POST request to: $FUNCTION_URL"
echo ""

# Send the request
RESPONSE=$(curl -s -w "\nHTTP_STATUS:%{http_code}" \
  -X POST \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  "$FUNCTION_URL")

# Extract HTTP status and body
HTTP_BODY=$(echo "$RESPONSE" | sed -e 's/HTTP_STATUS\:.*//g')
HTTP_STATUS=$(echo "$RESPONSE" | tr -d '\n' | sed -e 's/.*HTTP_STATUS://')

echo "Response (Status: $HTTP_STATUS):"
echo "$HTTP_BODY" | jq '.' 2>/dev/null || echo "$HTTP_BODY"
echo ""

if [ "$HTTP_STATUS" -ge 200 ] && [ "$HTTP_STATUS" -lt 300 ]; then
    echo "✓ Test completed successfully"
    echo ""
    echo "Notes:"
    echo "- Make sure your Azure Function is running locally or deployed"
    echo "- Update the environment variables with actual values from your SharePoint setup:"
    echo "    FUNCTION_URL, SUBSCRIPTION_ID, CLIENT_STATE, LIST_ID, SITE_URL"
    echo "- Ensure the DataSource is registered in the DataSources table"
    echo "- Ensure the WebhookSecrets table has the correct clientState"
    exit 0
else
    echo "✗ Test failed with status code: $HTTP_STATUS"
    exit 1
fi
