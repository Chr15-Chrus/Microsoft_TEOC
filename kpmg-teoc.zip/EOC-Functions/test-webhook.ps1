#!/usr/bin/env pwsh
# Test script for simulating SharePoint webhook notifications
# This script sends a test webhook payload to the webhookGateway function

param(
    [Parameter(Mandatory=$false)]
    [string]$FunctionUrl = "http://localhost:7071/api/webhookGateway",
    
    [Parameter(Mandatory=$false)]
    [string]$SubscriptionId = "test-subscription-id",
    
    [Parameter(Mandatory=$false)]
    [string]$ClientState = "test-client-state",
    
    [Parameter(Mandatory=$false)]
    [string]$ListId = "your-list-guid-here",
    
    [Parameter(Mandatory=$false)]
    [string]$SiteUrl = "https://your-tenant.sharepoint.com/sites/yoursite"
)

Write-Host "SharePoint Webhook Test Script" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Construct webhook notification payload
# This matches the format SharePoint sends
$webhookPayload = @{
    value = @(
        @{
            subscriptionId = $SubscriptionId
            clientState = $ClientState
            expirationDateTime = (Get-Date).AddDays(7).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
            resource = "web/lists(guid'$ListId')"
            tenantId = "your-tenant-id"
            siteUrl = $SiteUrl
            webId = "your-web-id"
        }
    )
} | ConvertTo-Json -Depth 10

Write-Host "Payload:" -ForegroundColor Yellow
Write-Host $webhookPayload
Write-Host ""

Write-Host "Sending POST request to: $FunctionUrl" -ForegroundColor Green

try {
    $response = Invoke-RestMethod -Uri $FunctionUrl `
        -Method Post `
        -Body $webhookPayload `
        -ContentType "application/json" `
        -ErrorAction Stop
    
    Write-Host ""
    Write-Host "Response received:" -ForegroundColor Green
    Write-Host ($response | ConvertTo-Json -Depth 10)
    Write-Host ""
    Write-Host "✓ Test completed successfully" -ForegroundColor Green
    
} catch {
    Write-Host ""
    Write-Host "✗ Error occurred:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host ""
        Write-Host "Response body:" -ForegroundColor Yellow
        Write-Host $responseBody
    }
    
    exit 1
}

Write-Host ""
Write-Host "Notes:" -ForegroundColor Cyan
Write-Host "- Make sure your Azure Function is running locally or deployed"
Write-Host "- Update the parameters with actual values from your SharePoint setup"
Write-Host "- Ensure the DataSource is registered in the DataSources table"
Write-Host "- Ensure the WebhookSecrets table has the correct clientState"
